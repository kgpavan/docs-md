# Prices of State-Contingent Claims Implicit in Option Prices

**Authors:** Douglas T. Breeden and Robert H. Litzenberger  
**Publication:** *The Journal of Business*, Vol. 51, No. 4 (October 1978), pp. 621–651  
**Source PDF:** `Options_BreedenLitzenberger_1978.pdf` (Drive id `0B-6kBz0I0dMsYW5sckhyYkgtSTA`)  
**Summary prepared:** 2026-09-26 (Scholar batch_2026-09-26_2)  
**OCR:** Not required; clean `pdftotext` extract (~11,793 words of source; JSTOR scan)

---

## 1. Problem and Motivation

Arrow–Debreu complete-markets pricing says every contingent claim is a portfolio of elementary (state) securities paying \$1 in one state and 0 otherwise. In practice those state prices are not quoted. Breeden–Litzenberger show that **European call prices across strikes**, for a fixed maturity, **span** the elementary claims on the underlying’s terminal level: a butterfly (second difference of calls) replicates a state payoff, and in the continuum the state-price density is the discounted second strike derivative of the call surface,
$$
p(K,T) = e^{-rT}\frac{\partial^2 C}{\partial K^2}(K,T)
$$
(in modern risk-neutral notation; the paper works with undiscounted/relative formulations and discrete steps first).

This is the foundational “options imply state prices / risk-neutral densities” result. Everything from Dupire local vol through Jackwerth–Rubinstein implied PDFs through VIX-style variance contracts sits on this butterfly identity.

The paper then embeds the construction in an intertemporal economy: under time-additive utility and complete markets, only state prices contingent on **aggregate consumption** (or a one-to-one transform such as the market portfolio) are needed to value primitive securities; theorems on diversification, valuation, and constant relative risk aversion (CRRA) + options on consumption follow.

---

## 2. Elementary Claims from Calls: Discrete Construction

**Definition.** An elementary claim on a portfolio paying \$1 if the portfolio’s value equals $M$ at horizon $T$, else 0. Price denoted $P(M,T)$.

**Assumptions for spanning.** Unlimited short sales, no transaction costs/taxes, borrowing at riskless rates. Calls are European on the underlying portfolio (“the market” / aggregate wealth in the leading case; method works for any underlying).

**Butterfly replication.** With discrete support $M\in\{\Delta M, 2\Delta M, \ldots\}$ and calls $c(X,T)$:

- $c(X,T)-c(X+\Delta M,T)$ pays $\Delta M$ in all states with $M\ge X+\Delta M$.
- Second difference isolates a single state.

The portfolio that pays \$1 iff $M$ occurs is
$$
\frac{1}{\Delta M}\Big\{\big[c(M-\Delta M,T)-c(M,T)\big]-\big[c(M,T)-c(M+\Delta M,T)\big]\Big\}
$$
i.e. $+1/\Delta M$ at strikes $M\pm\Delta M$ and $-2/\Delta M$ at strike $M$. Cost:
$$
\frac{P(M,T;\Delta M)}{\Delta M}
= \frac{c(M-\Delta M,T)-2c(M,T)+c(M+\Delta M,T)}{(\Delta M)^2}.
$$

**Numerical example in the paper.** Calls $c(0)=1.7$, $c(1)=0.8$, $c(2)=0.1$ ⇒ state prices $P(1)=0.2$, $P(2)=0.6$, $P(3)=0.1$; bond $=0.9$.

**Continuum limit.** As $\Delta M\to 0$,
$$
\lim_{\Delta M\to 0}\frac{P(M,T;\Delta M)}{\Delta M}=\frac{\partial^2 c(X,T)}{\partial X^2}\Big|_{X=M}.
$$
With a continuous distribution the probability of an exact $M$ is zero; $P(M,T)$ behaves as a **state-price density** (Arrow–Debreu density). Integrating against any payoff $g(M)$ prices the claim.

**Puts.** Put–call parity implies the same second derivative for puts: $\partial^2 P_{\mathrm{put}}/\partial K^2=\partial^2 C/\partial K^2$ for European options on the same underlying (modern statement). Butterflies can be built from puts equally well.

---

## 3. From State Prices to Risk-Neutral Densities (Modern Dictionary)

If $C(K,T)=e^{-rT}\int_K^\infty (S-K)q(S)\,\mathrm{d}S$ with risk-neutral density $q$, then Breeden–Litzenberger is exactly
$$
q(K)=e^{rT}\frac{\partial^2 C}{\partial K^2}.
$$
The paper’s $P(M,T)$ is the **state price** (pricing kernel × physical density × discount), not the risk-neutral density alone; in complete markets under the risk-neutral measure the two coincide up to the discount factor. For practitioners recovering $q$ from option smiles, the operational object is the butterfly.

**No dynamic model required.** Unlike Black–Scholes, one does not assume GBM. Any arbitrage-free call surface with positive butterflies ($\partial_{KK}C>0$) and sensible calendar structure yields a positive density. That model-free character is why the result dominates empirical option research.

---

## 4. Economy: Preferences, Aggregation, and Why Consumption States Suffice

### 4.1 Setup (Sections III–V)

Individuals have time-additive utilities over consumption. Markets span time-state contingent claims. Pareto-optimal allocations solve a weighted social planner problem.

### 4.2 Theorem 1 — Intertemporal diversification

Under standard preference assumptions (Al: time-additive von Neumann–Morgenstern; completeness; etc.), Pareto-optimal allocations of time-state contingent consumption have each individual’s contingent wealth depending on **aggregate** consumption (and calendar time), not on idiosyncratic labels of states that share the same aggregate. Intuition: only aggregate risk needs to be shared; idiosyncratic risk is diversified away in the optimum.

**Corollary.** State prices for valuation can be indexed by aggregate consumption levels (and time), not by fine-grained personal states.

### 4.3 Theorem 2 — Valuation

In a capital market spanning the relevant contingent-claim space, the price of any security is the sum (integral) of its state-contingent payoffs times the corresponding elementary claim prices. If aggregate consumption maps one-to-one to the market portfolio level, elementary claims on the market—**recoverable from index options**—are sufficient statistics for pricing.

### 4.4 Theorem 3 — CRRA and options on consumption

With identical constant relative risk aversion across agents (or a representative agent with CRRA), pricing functionals take power forms in aggregate consumption. Options on aggregate consumption (or the market, under the 1–1 map) become natural instruments for completing markets and implementing optimal sharing. The paper discusses approximation quality when CRRA holds and when consumption–market mapping is imperfect.

---

## 5. Pricing Kernel Link

State price density $\pi(M,T)$ embeds both discounting and risk adjustment:
$$
\pi(M,T) \propto e^{-rT}\xi(M)\,q_{\mathrm{phys}}(M)
$$
in modern notation with pricing kernel $\xi$. Breeden–Litzenberger recovers $\pi$ (or $q_{\mathrm{RN}}$) from options; separating $\xi$ from physical $q_{\mathrm{phys}}$ needs additional assumptions or historical returns (Jackwerth 2000 “pricing kernel puzzle,” Rosenberg–Engle, etc.—later literature).

For this 1978 paper the punchline stops at: **options reveal state prices**; those state prices are the right inputs for Arrow–Debreu valuation when states are consumption/market indexed.

---

## 6. Implementation Notes for Quant Work

1. **Smooth the call surface** before differentiating twice—raw quotes are sparse and noisy. Use arbitrage-free interpolators (e.g., SVI, spline with convexity constraints, or Jackwerth–Rubinstein smoothness QP).
2. **Discrete butterfly** with strike step $\Delta K$:
   $$
   \hat q(K)\approx e^{rT}\frac{C(K-\Delta K)-2C(K)+C(K+\Delta K)}{(\Delta K)^2}.
   $$
3. **Check** $\hat q\ge 0$ and integrates to $e^{-rT}$ (or 1 if working with undiscounted Digitals carefully). Violations ⇒ quote junk or American/early-exercise contamination.
4. **European index options** are the cleanest empirics (as Jackwerth–Rubinstein emphasize); single-name Americans need care.
5. **Interest rates and dividends** enter the forward and discounting; put–call parity should be imposed before butterflies.
6. **Deep OTM wings** are illiquid—density tails are the least reliable and the most decision-relevant for crash risk (again JR 1996).

---

## 7. Relation to Adjacent Classics

| Paper | Role relative to BL 1978 |
|-------|---------------------------|
| Arrow (1964), Debreu (1959) | State-preference foundation |
| Black–Scholes (1973) | Parametric special case; BL is model-free |
| Banz–Miller (1978) | Concurrent state-price estimates |
| Brennan (1977) | Related aggregation under random-walk consumption |
| Dupire (1994) | Local vol from $\partial_T C / \partial_{KK}C$—needs BL density as ingredient |
| Jackwerth–Rubinstein (1996) | Nonparametric density recovery; crash probabilities |
| VIX / variance swaps | Integrated contracts priced from continuum of strikes via BL |

---

## 8. Limitations and Caveats

- **Completeness / spanning.** Needs a rich strike continuum; discrete strikes approximate.
- **European payoff assumption.** Early exercise premium biases second differences.
- **Consumption ↔ market mapping.** Theorem 2’s convenience assumes 1–1 link; empirically imperfect (labor income, housing, etc.).
- **No dynamics.** BL gives terminal-date state prices, not a stochastic process; Dupire/Heston/etc. add dynamics.
- **Pricing kernel identification.** Options alone give risk-neutral (or state-price) objects; physical probabilities and risk aversion need more.
- **Transaction costs / short-sale constraints** assumed away—the replication is idealized.
- **JSTOR OCR noise** in some equations; reconstruct from the butterfly logic above rather than garbled symbols.

---

## 9. Worked Micro-Example (Discrete)

Strikes $K\in\{90,100,110\}$, $\Delta K=10$, maturity $T$, discount $e^{-rT}=0.95$. Suppose mid call prices $C(90)=12.0$, $C(100)=5.0$, $C(110)=1.5$. Then
$$
\frac{\partial^2 C}{\partial K^2}\approx\frac{12-2\cdot5+1.5}{100}=0.035,
$$
$$
\hat q(100)\approx e^{rT}\times 0.035 \approx 0.035/0.95\approx 0.0368
$$
per \$10 bucket (rescale by \$1/\Delta K$ carefully depending on whether you want a density in \$1 units). The corresponding butterfly (long 1/10 of 90 and 110, short 2/10 of 100) costs \$0.035 before discount conventions—the state price mass in that bucket.

---

## 10. Paleologo-Facing Takeaways

1. **Butterfly = state security.** Second strike difference of European calls (puts) prices an Arrow–Debreu payoff on $S_T=K$.
2. **Continuum:** $e^{-rT}\partial_{KK}C$ is the risk-neutral density (state-price density up to discount).
3. **Model-free:** no GBM required; only no-arbitrage call surface.
4. **Aggregation theorems:** under standard preferences, consumption-indexed (or market-indexed) state prices suffice for valuation—motivating index options as the natural empirical object.
5. **Downstream:** every implied-PDF, local-vol, and variance-swap calculation is an elaboration of this identity; numerical care in the second derivative is the whole game.

**Replication note.** From a smooth European call strip, compute discrete butterflies across strikes; verify nonnegativity and integral constraints; compare to a lognormal benchmark with matched ATM forward and variance—the gap is the smile’s state-price content (JR 1996 quantifies post-crash left-tail fattening).


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.


### Additional discussion: strikes, forwards, and measure changes

Operational density recovery always works on the **forward** measure or with explicit discounting. Define $F=S_0 e^{(r-q)T}$ and call prices as functions of $K$. Changing numeraire does not alter the butterfly logic; it rescales probabilities. When quoting in Black implied vols $\sigma(K)$, one can convert to $C(K)$ via Black’s formula then differentiate, or use analytic Jacobians $\partial_{KK}C$ in terms of $n(d_2)$ and digamma-type smile terms (the “implied density from smile” formulas used on desks). Those formulas are BL plus chain rule—nothing deeper.

For variance and higher moment swaps, integrating $C(K)/K^2$ over strikes is again BL in integrated form (Carr–Madan, Bakshi–Kapadia–Madan). The 1978 paper does not discuss variance swaps, but any quant deriving them is applying Breeden–Litzenberger under the integral sign.

When the mapping from aggregate consumption to the market index fails, options on the index still recover **index** state prices; pricing claims that depend on non-traded consumption then requires a projection or basis risk adjustment. That is the practical content of the paper’s caution about the one-to-one map.
