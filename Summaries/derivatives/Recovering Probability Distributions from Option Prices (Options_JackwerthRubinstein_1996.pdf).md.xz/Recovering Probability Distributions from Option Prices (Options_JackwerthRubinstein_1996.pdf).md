# Recovering Probability Distributions from Option Prices

**Authors:** Jens Carsten Jackwerth and Mark Rubinstein (Haas School of Business, UC Berkeley)  
**Publication:** *The Journal of Finance*, Vol. 51, No. 5 (December 1996), pp. 1611–1631  
**Source PDF:** `Options_JackwerthRubinstein_1996.pdf` (Drive id `0B-6kBz0I0dMscWdZamF6aDZSV0E`)  
**Summary prepared:** 2026-09-26 (Scholar batch_2026-09-26_2)  
**OCR:** Not required; clean `pdftotext` extract (~7,979 words of source; JSTOR scan)

---

## 1. Problem and Motivation

Risk management for derivatives books needs the **risk-neutral distribution** of underlyings, especially in the **tails**. Historical returns fail: rare crashes may be absent or dominate sample moments (Table I: standardized kurtosis of S&P 500 log returns depends radically on whether Oct 19, 1987 is in-sample). Parametric option models (stochastic vol, jumps) impose functional forms that may miss how the market actually prices extremes.

Jackwerth–Rubinstein recover **nonparametric** risk-neutral ending probabilities from European S&P 500 option prices (Apr 1986–Dec 1993), comparing optimization criteria and proposing a fast **smoothness** method. Headline empirical result: **since the 1987 crash**, the risk-neutral probability of a −3σ (−4σ) one-year index decline (~−36% / −46%) is about **10× (100×)** larger than under lognormality matched to ATM vol.

---

## 2. Method: Nonparametric Risk-Neutral Probabilities

### 2.1 Quadratic program relative to a prior (Rubinstein 1994)

On a discrete terminal grid $\{S_j\}$ (binomial-tree nodes or uniform strikes), choose posterior probabilities $P_j\ge 0$, $\sum P_j=1$, minimizing distance to a prior $P_j^*$ (typically lognormal) subject to pricing the underlying and all options inside bid–ask:

$$
\min_{P}\sum_j (P_j-P_j^*)^2
$$
subject to
$$
S_b \le e^{-rt}\sum_j P_j S_j \le S_a,
$$
$$
C_b^i \le e^{-rt}\sum_j P_j\max(S_j-K_i,0) \le C_a^i.
$$

**Virtues:** solution exists iff no general arbitrage across the quote set; if all quotes already consistent with the prior, posterior = prior; richer strike panels make the objective less influential (constraints dominate). Fully nonparametric: any distribution on the grid is admissible.

### 2.2 Alternative objectives

The paper compares several $f(P)$ (goodness-of-fit, entropy-type, smoothness, etc.). Empirically, **different objectives produce approximately the same implied distributions** when the option strip is informative—reassuring for robustness.

### 2.3 Smoothness criterion (preferred; ~100–1000× faster)

Maximize smoothness of the density / minimize second-difference roughness—equivalently work in **call space** via Breeden–Litzenberger:
$$
P_j = e^{rt}\frac{\partial^2 C}{\partial K^2}.
$$
Sample strikes on a \$5 grid from 0 upward (aligned with listed strikes). Minimize
$$
\min_C \sum_j\big(C_{j-2}-4C_{j-1}+6C_j-4C_{j+1}+C_{j+2}\big)^2
$$
(fourth-difference roughness of $C$, equivalent to second-difference roughness of $P$) subject to $C(K_i)=C_i^{\mathrm{mkt}}$ at observed strikes (penalty form). Boundary: deep OTM calls → 0; deep ITM → discounted futures intrinsic. Nonnegativity of butterflies imposed iteratively by “clamping” extreme strikes.

**Closed-form linear system** for unobserved $C_j$ (eqs. 16–18) replaces slow quasi-Newton searches—decisive for daily historical panels.

---

## 3. Data Construction

- **Options:** CBOE European S&P 500 options, trades and quotes, from the American→European switch (Apr 2, 1986) through Dec 31, 1993.
- **Futures:** CME S&P 500 futures (hedging venue; cash index lags in stress).
- **Dividends:** realized S&P daily ex-div amounts treated as expected; payout return $d=[1+D/S]^{1/t}$.
- **Rates:** implied from European put–call parity (median across strikes per day/expiry); futures-implied repo used to back out synchronized spot. Futures-based rates much less noisy than cash-index-based (Table III).
- **Synchronization:** translate futures to implied spot each minute; use quote midpoints carefully with bid–ask constraints in the QP.

Quality controls matter: stale cash index would fake arbitrage and warp left-tail probabilities.

---

## 4. Empirical Results

### 4.1 Pre- vs post-crash shape

Before Oct 1987, implied RNDs are relatively close to lognormal (mild smile). After the crash, RNDs become **negatively skewed** with **fat left tails**—the now-familiar equity-index smirk, read directly in probability space rather than only in IV(K).

### 4.2 Tail probabilities (headline)

Risk-neutral Prob of a 3σ one-year decline (~−36%): ~**10×** lognormal.  
4σ (~−46%): ~**100×** lognormal.  

These are **risk-neutral** odds (state prices / discount), not physical forecasting probabilities. They embed crash phobia / aversion; still the right inputs for pricing and for RN-scenario risk of option books.

### 4.3 Robustness across objectives

Smoothness, max entropy, and goodness-of-fit posteriors agree closely when strikes span the distribution. Disagreement concentrates in sparse wings—exactly where quotes are widest.

### 4.4 Time series 1986–1993

Daily/selected RNDs show the smirk appearing with the crash and **persisting**—not a one-week phenomenon. ATM vol alone (Table II style comparisons) understates left-tail mass: post-crash, even when ATM vol is moderate, OTM puts remain rich ⇒ left-tail RN probability stays elevated.

### 4.5 Historical moments vs options

Table I: sample kurtosis wildly sensitive to including 1987. Options-implied left tails after 1987 stay high even in calm samples—markets refused to treat the crash as a one-off draw from a thin-tailed law.

---

## 5. Method Detail Worth Implementing

**Grid:** 201 points at \$5 steps beats log-spaced binomial nodes for matching listed strikes and avoiding empty gaps between adjacent $K$.

**Penalty QP:** augmented Lagrangian / quadratic penalty on bid–ask and equality violations (eq. 10–11) when hard constraints are awkward.

**Butterfly extraction:**
$$
P_i = e^{rt}\frac{C_{i-1}-2C_i+C_{i+1}}{\Delta K}\cdot\frac{1}{\Delta K}
$$
(with their \$5 scaling as in eq. 15).

**Sanity checks:** $\sum P_i=1$ automatic under their boundary setup; $P_i\ge 0$ enforced; call price vs strike decreasing and convex; put–call parity held in inputs.

---

## 6. Limitations

- **Risk-neutral ≠ physical.** Crash-risk premia inflate left-tail $P_j$ relative to real-world frequencies; do not read 100× as a meteorological forecast without kernel adjustment.
- **Sample ends 1993.** Pattern persists in later decades but magnitudes vary (LTCM, 2008, COVID).
- **Index only; European.** Single names and Americans need exercise adjustments.
- **Wing illiquidity.** 4σ probabilities inherit wide put quote uncertainty.
- **Dividend assumption** (realized = expected) is standard but imperfect around special dividends / index changes.
- **No dynamics:** terminal RND for each expiry separately; not a full process (local vol / stochastic vol needed for path-dependent books).

---

## 7. Relation to Breeden–Litzenberger and Dupire

BL (1978) gives $q=e^{rt}\partial_{KK}C$. JR is the **empirical technology** to estimate that density from noisy, discrete quotes via optimization—especially smoothness in call space. Dupire then uses the whole maturity × strike surface for local vol; JR typically works expiry-by-expiry for RND snapshots. Use JR for scenario probabilities and smile diagnostics; Dupire for path-dependent pricing under diffusion assumption.

---

## 8. Paleologo-Facing Takeaways

1. Nonparametric RNDs from S&P options are **implementable** and robust across objectives when strikes are rich.
2. **Smoothness-in-C** is the practical algorithm (fast linear system + butterfly).
3. Post-1987, equity-index RN left tails are **order-of-magnitude** fatter than lognormal—10× at 3σ, 100× at 4σ in their sample.
4. Historical moments cannot substitute: crash inclusion flips kurtosis; options embed ongoing crash pricing.
5. For risk: use RNDs for **pricing measures** and stress scenarios; for physical VaR, combine with a pricing-kernel or historical overlay—do not confuse the two.

**Replication note.** On a modern SPX European strip: imply dividends/rates from parity+futures; fit smooth $C(K)$ with midpoint targets; extract butterflies; compare left-tail mass to Black lognormal with same forward and ATM variance; report 3σ/4σ RN probability ratios.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.


### Further notes on interpretation and desk use

Risk-neutral left tails after 1987 changed how desks quote OTM puts, how structured-product sellers hedge crash risk, and how “fear gauges” later formalized (VIX is an integrated BL functional of the same strip). JR’s contribution is to show the transformation **in probability space** with a careful nonparametric pipeline, not merely as an IV smirk chart.

When comparing pre- and post-crash days with similar ATM vol (their Table II spirit), the post-crash RND still carries more left mass—evidence that the smile’s skew component, not only the level of vol, is the crash legacy. For portfolio construction, equity-index put overlays priced off post-crash RNDs are expensive in RN expectation by construction; whether they are expensive in physical expectation is a separate risk-premium question (the pricing-kernel puzzle literature).

Computationally, if you only need a few expiries per day, even the slower QP-to-prior methods work; for full panel research (every day × every expiry), the smoothness linear system is what makes the 1986–1993 historical project feasible. Modern GPUs are less constraining, but the numerical preference for working in convex call space with explicit butterfly nonnegativity remains best practice.
