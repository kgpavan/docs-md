# A Closer Look at the Short-Term Return Reversal

**Authors:** Zhi Da (Notre Dame), Qianqiu Liu (University of Hawaii), Ernst Schaumburg (FRBNY)  
**Publication:** *Management Science* 60(3), March 2014, pp. 658–674  
**DOI:** 10.1287/mnsc.2013.1766  
**Source PDF:** `AbnormalReturnsMomentum_DaLiuSchaumburg_2014.pdf` (Drive id `0B-6kBz0I0dMsY3dzd2dJMEp4S1E`)  
**Sample:** January 1982–2009; stocks with regular I/B/E/S analyst coverage (tilts large/liquid)  
**Summary prepared:** 2026-09-26 (Scholar batch_2026-09-26_1)  
**OCR:** Not required; clean `pdftotext -layout` extract (~13.4k words of source)

---

## 1. Problem and Contribution

Short-term return reversal — long last month's losers, short last month's winners, hold one month — is among the oldest anomalies (Fama 1965; Jegadeesh 1990; Lehmann 1990). Jegadeesh (1990) documents about **2% per month** over 1934–1987. In an efficient market with a slow-moving SDF, prices should be near-martingales at monthly horizons (Sims 1984), so the effect is a puzzle.

Two non-exclusive explanations dominate:

1. **Sentiment / overreaction** (Shiller 1984; Black 1986; Stiglitz 1989; Summers–Summers 1989; Subrahmanyam 2005): prices temporarily deviate from fundamentals; reversal is correction.
2. **Liquidity / inventory** (Grossman–Miller 1988; Campbell–Grossman–Wang 1993; Jegadeesh–Titman 1995): uninformed order flow induces a price concession that reverses as compensation for liquidity providers. Empirically, standard reversal profits concentrate in small, high-turnover, illiquid stocks (Avramov–Chordia–Goyal 2006). Pastor–Stambaugh (2003) even *define* illiquidity via return reversal.

**This paper's idea.** Under both stories, reversal should come from the **nonfundamental** component of past returns. Decompose realized return into expected return, cash-flow news, and a residual; sort on the residual. That (i) boosts strategy profitability and (ii) cleans the laboratory for testing liquidity vs sentiment — separately on the long and short legs.

**Headline results:**

- Within-industry residual-return decile strategy: monthly $\alpha\approx\mathbf{1.34\%}$ ($t=9.28$) over 1982–2009.
- Standard reversal in the same analyst-coverage sample: $\alpha\approx\mathbf{0.33\%}$ ($t=1.37$) — insignificant.
- Enhanced strategy $\approx\mathbf{4\times}$ the risk-adjusted return of standard reversal (abstract).
- Long leg (buy residual losers) loads on lagged illiquidity and realized vol — **liquidity provision**.
- Short leg (sell residual winners) loads on lagged IPO activity and equity share in new issues — **sentiment under short-sale constraints** (Miller 1977; Stambaugh–Yu–Yuan 2012).

---

## 2. Return Decomposition

Write the realized return as

$$
r_t = \underbrace{\mathbb{E}_{t-1}[r_t]}_{\text{expected return}} + \underbrace{\mathrm{CF\,news}_t}_{\text{cash-flow news}} + \underbrace{\mathrm{DR\,news}_t}_{\text{discount-rate news}} + \underbrace{u_t}_{\text{residual / nonfundamental}}.
$$

At weekly/monthly frequency, DR news is small if the SDF is slow-moving; the authors therefore purge expected return and CF news and treat the rest as residual:

$$
u_t = r_t - \widehat{\mathbb{E}}_{t-1}[r_t] - \widehat{\mathrm{CF\,news}}_t.
$$

Industry adjustment is applied throughout: returns and components are measured in excess of industry averages, which (i) removes industry momentum (Moskowitz–Grinblatt 1999) that otherwise masks short-term reversal, (ii) cancels industry-common analyst biases. Results are qualitatively similar without industry controls.

The residual is spiritually close to Daniel–Titman's (2006) "intangible return," but computed at **monthly** frequency — only feasible because of the analyst-forecast CF news proxy.

---

## 3. Measuring the Components

### 3.1 Expected returns

Fama–French (1993) conditional expected return:

$$
\hat{\mathbb{E}}_t[r]=\hat{\mathbb{E}}[r_f]+\hat{\beta}^{\mathrm{MKT}}_{t}\hat{\mathbb{E}}[\mathrm{MKT}]+\hat{\beta}^{\mathrm{SMB}}_{t}\hat{\mathbb{E}}[\mathrm{SMB}]+\hat{\beta}^{\mathrm{HML}}_{t}\hat{\mathbb{E}}[\mathrm{HML}].
$$

Betas from a five-year rolling window (min 36 months); factor premia set to full-sample average factor returns (no look-ahead in betas; premia are constant). Robustness: CAPM or FF5 (FF3+UMD+reversal) does not change the qualitative results. At monthly frequency expected returns are small relative to realized returns, so the exact model is second-order for reversal sorts.

### 3.2 Cash-flow news via analyst forecast revisions

Novel operationalization following Easton–Monahan (2005) and Da–Warachka (2009). I/B/E/S monthly consensus (summary unadjusted), typically third Thursday of the month.

Define a scaled forecast revision / earnings surprise hybrid $\mathrm{FREV}$:

$$
\mathrm{FREV}_{t+1}=
\begin{cases}
\dfrac{A1_{t+1}-A1_t}{B_t} & \text{no earnings-announcement month},\\
\dfrac{E1_{t+1}-A1_t}{B_t} & \text{earnings-announcement month},
\end{cases}
$$

where $A1$ is consensus FY1 EPS forecast, $E1$ is actual EPS, and $B_t$ is book value per share. Monthly revisions mitigate persistent analyst biases.

Full CF news uses a **three-stage growth model** (Frankel–Lee 1998; Pástor–Sinha–Swaminathan 2008): near-term analyst forecasts, transition growth, and steady-state growth. Revisions in the implied earnings path (across maturities $X_{t,t+j}$) map into a CF news proxy for individual stocks (Da–Warachka portfolio methodology adapted to single names). Details in the paper's Section 2.2; the implementable takeaway is: **use the month-over-month change in the analyst-implied earnings trajectory, scaled, as CF news**.

### 3.3 Residual return

$$
u_{i,t}=r_{i,t}-\hat{\mathbb{E}}_{t-1}[r_{i,t}]-\widehat{\mathrm{CF\,news}}_{i,t},
$$

then demean within industry. Sort into deciles on $u_{i,t-1}$ within industry; long decile 1 (residual losers), short decile 10 (residual winners); hold one month.

---

## 4. Main Performance Results (Tables 2–5)

### 4.1 Headline alphas (Table 2)

Sample of analyst-covered stocks, 1982–2009:

| Strategy | Monthly $\alpha$ | $t$-stat |
|---|---|---|
| Standard reversal (prior return) | 0.33% | 1.37 |
| Residual-based within-industry | **1.34%** | **9.28** |
| Related residual sort in text | ~1.57% raw in one panel | — |

The abstract's "four times" refers to risk-adjusted performance vs standard reversal in this sample. Industry momentum had been masking reversal among larger names; once industry is removed and fundamentals purged, reversal is alive and well even in liquid, covered stocks.

### 4.2 Portfolio characteristics (Table 3)

Residual-sorted extreme deciles differ on standard limit-to-arbitrage proxies, but the residual sort is not merely a repackage of size or illiquidity — the point of later cross-sectional tests. Divergence between residual and raw return is informative: months when raw return is dominated by CF news should *not* reverse; the residual strategy automatically down-weights those.

### 4.3 Robustness (Tables 4–5)

- Within-industry residual reversal survives transaction-cost analysis (paper's cost adjustments).
- Subperiod stability: profits remain in later subsamples (Panel A/B of Table 5).
- Across industries (consumer services etc.): broadly positive.
- Excluding high-distress names (where analyst bias / delisting concerns bite) barely changes results.
- Alternative expected-return models and CF news constructions: qualitative invariance.
- Without industry controls: weaker but not zero — industry adjustment enhances but does not create the effect.

---

## 5. Liquidity vs Sentiment: Long vs Short Legs (Tables 6–8)

### 5.1 Time-series regressions (Table 6)

Regress risk-adjusted long-leg and short-leg profits on lagged macro proxies:

**Long leg (buy residual losers)** loads positively on:

- Lagged aggregate Amihud (2002) illiquidity,
- Lagged S&P 500 realized volatility,

consistent with compensation for liquidity provision when intermediaries are constrained (Nagel 2012; Coval–Stafford 2007 fire sales). Fire sales are more common than fire purchases (Shleifer–Vishny 1992), so liquidity should matter more on the loser side — confirmed.

**Short leg (sell residual winners)** loads positively on lagged sentiment / overvaluation proxies:

- Monthly number of IPOs ($nipo$),
- Equity share in new issues ($s$),

as in Baker–Wurgler (2006) and Hirshleifer–Jiang (2010). Interpretation: optimism plus short-sale constraints (Miller 1977) leave overvaluation in residual winners; correction produces short-leg profits. Matches Stambaugh–Yu–Yuan (2012): anomaly profits concentrate in short legs after high sentiment — here shown for short-term reversal among large stocks.

### 5.2 Subsamples (Table 7)

Split by size, BM, analyst coverage, NOA, DISP, liquidity, etc. (top 30% vs bottom 30% style cuts). **Strikingly consistent:** liquidity proxies explain loser-side reversal; sentiment proxies explain winner-side reversal — across cuts.

### 5.3 Cross-sectional confirmation (Table 8)

Fama–MacBeth regressions: stock-level Amihud illiquidity predicts stronger reversal **only among past residual losers**. Among residual winners, stocks with options traded (looser short-sale constraints) show **no** reversal — winners without options do. This pins the short-leg mechanism to shorting frictions + sentiment rather than symmetric liquidity.

---

## 6. Economic Interpretation

| Leg | Economic shock | Friction | Empirical proxy loading |
|---|---|---|---|
| Long (losers) | Fire-sale / liquidity demand | Costly liquidity provision | Amihud, realized vol |
| Short (winners) | Optimistic sentiment | Short-sale constraints | IPOs, equity issuance; options attenuate |

The two explanations are not competitors for the whole strategy; they are **leg-specific**. A unified "reversal = liquidity" or "reversal = overreaction" slogan is too coarse.

---

## 7. Limitations

- Requires analyst coverage $\Rightarrow$ excludes many microcaps where raw reversal is strongest; alphas are impressive *despite* that filter.
- CF news measurement error: if analyst revisions miss true CF news, residual still contains fundamentals. Authors argue any informative proxy improves isolation; industry demeaning helps.
- Constant factor premia in $\hat{\mathbb{E}}[r]$ are a simplification.
- Transaction costs: paper argues survival after costs, but live capacity for monthly full-book turnover is limited; need optimized trading (partial rebalance, cost-aware portfolio construction).
- 1982–2009 sample; post-Reg-FD / decimalization / HFT microstructure may change residual dynamics.
- Schaumburg's FRBNY affiliation: paper is academic research, not Fed policy work.

---

## 8. Quant Takeaways

1. **Sort on residual, not raw return.** Subtract FF expected return and a CF news proxy (analyst revision) before ranking. Expected uplift vs naive reversal: several times the alpha in covered names.
2. **Always industry-adjust** monthly reversal ranks; industry momentum otherwise cancels the signal.
3. **Risk and sizing are leg-asymmetric.**
   - Size the long leg to liquidity conditions (cut when Amihud and realized vol are elevated if you cannot warehouse inventory risk — or *increase* if you are paid as liquidity provider and can hold).
   - Size the short leg to sentiment and hard-to-borrow status; prefer winners without options / with high utilization when fading residual winners.
4. **Standard reversal "death" among large caps is partly measurement.** Residual+industry resurrection is the relevant update for liquid books.
5. **Process architecture.** Build a monthly pipeline: I/B/E/S consensus revision $\to$ CF news; FF rolling betas $\to$ expected return; residual $\to$ within-industry z-score $\to$ trade list. Combine with borrow screens on the short side.

### Minimal replication recipe

1. Universe: CRSP shares with I/B/E/S FY1 consensus this month and last month.
2. $\hat{\beta}$ from 36–60m FF3; $\hat{\mathbb{E}}[r]$ as above.
3. $\mathrm{FREV}$ from FY1 consensus change / book; optionally full Da–Warachka path revision.
4. $u=r-\hat{\mathbb{E}}[r]-\mathrm{CF\,news}$; subtract industry median.
5. Within industry, long bottom decile $u$, short top decile; equal-weight; 1-month hold.
6. Hedge optional FF3; expect raw/alpha near 1–1.5%/month historically in-sample.

---

## 9. Additional Empirical Detail for Implementers

**Why standard reversal fails in the paper's sample.** Restricting to analyst-covered stocks removes the illiquid microcaps that drove much of Jegadeesh's 2%/month. Industry momentum among covered stocks further offsets within-industry reversal when sorts ignore industry. The residual strategy repairs both distortions.

**Link to Nagel (2012).** Nagel relates short-term reversal to liquidity provision and VIX-style intermediaries' risk appetite. Da–Liu–Schaumburg refine: liquidity provision is the right story for *losers*; sentiment/shorting is the right story for *winners*. A VIX-only timing model for the whole long-short may therefore be misspecified — consider separate timing signals per leg.

**Link to Avramov–Chordia–Goyal (2006).** They show standard reversal lives in illiquid names. This paper shows that after purging fundamentals, a liquidity-linked long leg remains even among covered stocks, while the short leg is a different economic object.

**CF news vs earnings announcements.** FREV uses announcement-month surprises and non-announcement revisions, so the residual is defined every month — necessary for a monthly strategy. Pure announcement-window filters would not yield a full-month sort key.

**False positives.** A large negative residual can mean (i) liquidity concession, (ii) unrecognized bad CF news that analysts missed, or (iii) rising discount rates. (ii) and (iii) contaminate the long leg. Mitigations: require corroborating microstructure signs (Amihud spike, volume spike on down days), avoid names with concurrent credit deterioration, and diversify broadly across industries (already helped by within-industry sorting).

**Portfolio construction upgrades beyond the paper.**

- Mean-variance or LMCRX-style optimization with $\hat{u}$ as alpha, with separate risk aversion on long vs short.
- Borrow-fee penalty on short residual winners.
- Turnover penalty: residual reversal's edge decays within weeks; delay is costly, but so is full monthly reconstitution — solve explicitly.
- Combine with longer-horizon momentum carefully: residual losers may be intermediate-term momentum losers; check joint sorts on $u_{t-1}$ and $r_{t-12:t-2}$.

**What "four times" should mean for allocation.** If naive reversal in your universe prints 30 bp/month insignificant and residual prints 120–130 bp, the information ratio uplift is the right object for capital allocation — not the raw return ratio — after costs and after shorting fees on the sentiment leg.



## 10. Measurement Appendix and Leg-Timing Rules

### 10.1 Timeline within a month

I/B/E/S consensus dates are typically the third Thursday. A careful implementation:

1. Observe month-$t$ consensus on the I/B/E/S statistical date.
2. Compute FREV vs month-$t-1$ consensus.
3. Compute month-$t$ residual using month-$t$ return and CF news.
4. Form portfolios at month-$t$ close (or next open); hold through month-$t+1$.

Aligning CF news and returns in the same month is required for the residual to be a *past* sort key without look-ahead into $t+1$ returns.

### 10.2 Three-stage growth CF news (conceptual)

Let $\{X_{t,t+j}\}$ be expected earnings at horizons implied by FY1, FY2, and longer-term growth. Da–Warachka map revisions $\Delta X_{t,t+j}$ into a present-value CF news scalar. For a desk that wants 80% of the benefit with 20% of the complexity, the FY1 FREV alone already removes a large CF component; the multi-stage version is the paper's preferred specification.

### 10.3 Industry definition

Use a standard industry map (FF49 or GICS level-1/2). Within-industry residual = $u_i-\mathrm{median}_{k\in\mathrm{ind}(i)}(u_k)$. Decile breakpoints within industry require enough names per industry-month; merge thin industries.

### 10.4 Transaction-cost reality check

Monthly two-sided turnover of a decile long-short can approach 200%+/month in names that churn ranks. Even at 10–20 bp round-trip for liquid covered names, costs can consume 20–40 bp of the 134 bp alpha. The paper claims survival after costs; live systems should:

- trade only ranks 1–2 vs 9–10 with buffer bands,
- penalize bid–ask and ADV participation,
- allow incomplete fills.

### 10.5 Leg-specific timing rules (actionable)

**Long leg (residual losers):**

- Increase size when lagged Amihud and SPX realized vol are high *if* the desk's mandate is liquidity provision and funding is stable.
- Decrease size when funding stressed (TED, broker haircuts) even if Amihud is high — you may be forced to liquidate into the same fire sale.

**Short leg (residual winners):**

- Increase size when IPO count and equity share in issues are elevated.
- Require locate/borrow; skip names with options if the thesis is short-constraint driven (or conversely, prefer no-option names).
- Cut hard when sentiment proxies crash (correction may already have occurred).

### 10.6 Joint sort with momentum

Recommended diagnostic (not in paper, but implied by horizon structure):

|  | Residual loser | Residual winner |
|---|---|---|
| Intermediate-term loser | Reversal long; momentum short — conflict | Both short-ish |
| Intermediate-term winner | Both long-ish | Reversal short; momentum long — conflict |

Resolve conflicts with horizon-weighted signals or orthogonalize $u$ against $r_{12,1}$.

### 10.7 Matching the abstract's "four times"

In-sample: $1.34 / 0.33 \approx 4.1$. Out-of-sample, re-estimate CF news and expected-return pieces with expanding windows; report the ratio of IRs after costs, not just alpha ratios.



## 11. Placement in the Reversal Literature

**Classical facts.** Fama (1965), Jegadeesh (1990), Lehmann (1990): short-horizon contrarian profits. Lo–MacKinlay (1990): lead-lag among sizes can generate contrarian profits without overreaction — a reason the authors industry-adjust and focus on residual nonfundamental components.

**Liquidity channel.** Campbell–Grossman–Wang (1993): risk-averse liquidity providers require return reversal after non-informational trade. Grossman–Miller (1988): market makers absorb inventory. Pastor–Stambaugh (2003): aggregate liquidity from reversal. Avramov–Chordia–Goyal (2006): profits in illiquid names. Nagel (2012): reversal returns track intermediaries' risk appetite. Coval–Stafford (2007): fire-sale price pressure. This paper's long-leg results sit squarely in this tradition.

**Sentiment channel.** Miller (1977): short-sale constraints + dispersion $\to$ overpricing. Baker–Wurgler (2006): sentiment index including IPOs and equity issuance. Stambaugh–Yu–Yuan (2012): short legs of anomalies worse after high sentiment. Hirshleifer–Jiang (2010): issuance as overvaluation proxy. This paper's short-leg results extend that tradition to monthly residual reversal among large stocks.

**Fundamental news controls.** Daniel–Titman (2006): intangible returns drive long-run reversal. Da–Warachka (2009), Easton–Monahan (2005): analyst-based CF news. Moskowitz–Grinblatt (1999): industry momentum — the reason industry adjustment strengthens monthly reversal.

The methodological contribution is to combine these strands: purge fundamentals first, then let liquidity and sentiment explain different legs.

