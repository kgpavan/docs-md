# The Interaction of Value and Momentum Strategies

**Author:** Clifford S. Asness (Goldman Sachs & Company)  
**Publication:** *Financial Analysts Journal*, March/April 1997, pp. 29–36  
**Source PDF:** `AbnormalReturnsValueMomentum_Asness_1997.pdf` (Drive id `0B-6kBz0I0dMscFhLTzNhNkY5Rjg`)  
**Summary prepared:** 2026-09-26 (Scholar batch_2026-09-26_2)  
**OCR:** Not required; clean `pdftotext -layout` extract (~5,140 words of source)

---

## 1. Problem and Motivation

Value and momentum both predict the cross-section of equity returns, yet they are **negatively correlated across stocks**. A long-value portfolio therefore tends to short momentum; a long-momentum portfolio tends to short value. Univariate evidence alone therefore understates (or misstates) each signal once the other is held fixed—and, more importantly, may hide **interaction**: the marginal power of value may depend on the level of momentum, and vice versa.

Asness asks three operational questions:

1. Does value still work after conditioning on momentum (and conversely)?
2. Does that marginal power **vary** across quintiles of the conditioning variable?
3. Can any rational-distress or behavioral story for value/momentum accommodate the interaction?

The paper does **not** adjudicate risk versus mispricing. It adds a stylized fact that any eventual explanation must cover, and it has direct implications for how a multi-signal equity optimizer should trade off value and momentum when tracking-error-constrained.

---

## 2. Data and Construction

**Universe and sample.** Monthly data July 1963–December 1994 on NYSE, Amex, and Nasdaq firms with CRSP and Compustat coverage. NYSE breakpoints define quintiles; Amex/Nasdaq names are then assigned into those NYSE buckets (standard Fama–French practice to avoid microcap-driven sorts).

**Momentum.** $\mathrm{PAST}(2,12)$ = average monthly return over the past 12 months **excluding the most recent month**. Skipping month $t-1$ avoids microstructure bid–ask bounce that otherwise contaminates short-horizon reversal (Asness 1995).

**Value measures (industry-relative).** Two signals, both demeaned within industry:

- $\log(\mathrm{BV}/\mathrm{MV})$: book equity for the prior fiscal year (updated each July with data through prior December—lag sufficient to kill look-ahead), over lagged month-end market cap.
- $\mathrm{D}/\mathrm{P}$: prior-year common dividends over market cap, same lag.

Industry adjustment subtracts the value-weighted industry average of $\log(\mathrm{BV}/\mathrm{MV})$ or $\mathrm{D}/\mathrm{P}$ using 49 industries (Fama–French 1994a / Asness–Stevens). A “cheap” stock is cheap **relative to its industry**, not in absolute BV/MV space. Asness–Stevens (1995) had already shown that intraindustry value is generally stronger; conclusions here strengthen but do not reverse if one skips the industry adjustment.

**Portfolios.** Independent quintile sorts on each signal; 25 value-weighted intersection portfolios for the double sorts. Reported diagnostics per cell: average monthly return, summed full-period beta on the value-weighted NYSE/Amex/Nasdaq market (contemporaneous + one lag), average size, raw (not industry-adjusted) $\log(\mathrm{BV}/\mathrm{MV})$ and $\mathrm{D}/\mathrm{P}$, and average $\mathrm{PAST}(2,12)$.

---

## 3. Univariate Benchmarks

### 3.1 Momentum alone (Table 1)

| Statistic | Q1 (losers) | Q2 | Q3 | Q4 | Q5 (winners) | Q5−Q1 |
|-----------|------------:|---:|---:|---:|-------------:|------:|
| Monthly return | 0.61% | 0.80% | 0.81% | 1.09% | 1.48% | **0.87%** ($t=3.73$) |
| Beta | 1.14 | 0.92 | 0.96 | 0.93 | 1.17 | |
| Size (\$m) | 5,879 | 9,207 | 9,418 | 9,323 | 7,963 | |
| $\log(\mathrm{BV}/\mathrm{MV})$ | −0.51 | −0.62 | −0.73 | −0.86 | −1.12 | |
| $\mathrm{D}/\mathrm{P}$ | 3.90% | 3.99% | 3.68% | 3.19% | 2.15% | |
| $\mathrm{PAST}(2,12)$ | −1.52% | 0.01% | 1.12% | 2.29% | 4.64% | |

Momentum works: winners beat losers by 87 bp/month. Value measures fall mechanically across momentum quintiles (partly construction—MV in the denominator rises with past return given lagged BV and D). Beta is mildly U-shaped; size inverted-U.

### 3.2 Industry-relative $\log(\mathrm{BV}/\mathrm{MV})$ alone (Table 2)

Q5−Q1 return spread **0.51%**/month ($t=3.18$). Size falls after Q1 as value rises. $\mathrm{PAST}(2,12)$ **declines** across value quintiles (2.13% → 0.66%): cheap stocks are recent losers. So value and momentum are each positively related to future returns and **negatively** related to each other.

### 3.3 Industry-relative $\mathrm{D}/\mathrm{P}$ alone (Table 3)

Weaker univariate: Q5−Q1 only **0.31%**/month ($t=2.10$). Flat through Q1–Q4, jump at Q5. Again $\mathrm{PAST}(2,12)$ falls with $\mathrm{D}/\mathrm{P}$.

**Univariate takeaway.** Each signal works; value and momentum conflict in the cross-section. Naïve expectation: holding the other fixed should **strengthen** each marginal sort. That is not the full story.

---

## 4. Double Sorts: The Interaction

### 4.1 $\mathrm{PAST}(2,12)$ × industry-relative $\log(\mathrm{BV}/\mathrm{MV})$ (Table 4)

Average monthly returns on the 25 cells (rows = momentum, columns = value expensive→cheap):

| Momentum \\ Value | Q1 expensive | Q2 | Q3 | Q4 | Q5 cheap | Value Q5−Q1 ($t$) |
|-------------------|-------------:|---:|---:|---:|---------:|------------------:|
| Loser Q1 | **0.03%** | 0.49% | 0.80% | 0.83% | **1.00%** | **0.97%** (4.38) |
| Q2 | 0.61% | 0.59% | 0.90% | 1.25% | 1.35% | 0.74% (3.57) |
| Q3 | 0.52% | 0.93% | 0.80% | 1.19% | 1.44% | 0.92% (4.94) |
| Q4 | 0.99% | 0.97% | 1.17% | 1.45% | 1.68% | 0.69% (3.39) |
| Winner Q5 | **1.50%** | 1.44% | 1.49% | 1.60% | **1.62%** | **0.13%** (0.65) |
| Mom Q5−Q1 ($t$) | **1.47%** (5.71) | 0.95% (3.47) | 0.69% (2.66) | 0.76% (3.10) | 0.62% (2.57) | |

Two facts jump off the table:

1. **Value is strong among losers and dead among winners.** Value Q5−Q1 is 97 bp ($t=4.38$) in the loser row—larger than the univariate 51 bp—but only **13 bp and insignificant** among winners. Yet the **spread in actual $\log(\mathrm{BV}/\mathrm{MV})$** across value quintiles within the winner row is comparable to (if anything larger than) other rows. The sort “works” on the characteristic; it fails on **returns**.
2. **Momentum is strongest among expensive stocks.** Momentum Q5−Q1 is **147 bp** ($t=5.71$) in the expensive column versus 62 bp among cheap stocks—despite a momentum characteristic spread that is, if anything, **smaller** among expensive names.

Figures 1–3 in the paper plot the return surface and the characteristic surfaces: the return surface tilts steeply in value for losers and steeply in momentum for expensive stocks; characteristic spreads are roughly rectangular (sorts succeed mechanically).

### 4.2 Formal interaction test

Label cells $(Q_m, Q_v)$. Compare:

$$
[(Q_5,Q_1)-(Q_1,Q_1)] - [(Q_5,Q_5)-(Q_1,Q_5)] > 0
$$

(momentum stronger among expensive than cheap), equivalently

$$
[(Q_5,Q_5)-(Q_5,Q_1)] - [(Q_1,Q_5)-(Q_1,Q_1)] < 0
$$

(value weaker among winners than losers). Both rearrange to the same long/short:

$$
[(Q_5,Q_5)+(Q_1,Q_1)] - [(Q_5,Q_1)+(Q_1,Q_5)] < 0.
$$

**Result:** average return **−0.85%**/month, $t=-3.50$. Three equivalent readings:

- Value is statistically stronger over losers than winners.
- Momentum is statistically stronger over expensive than cheap.
- Raising both signals jointly has a weaker effect than the average of the two marginal effects (sub-additive interaction).

### 4.3 Same pattern, stronger, for $\mathrm{D}/\mathrm{P}$ (Table 5)

Univariate $\mathrm{D}/\mathrm{P}$ looked marginal (31 bp). Conditional on momentum it is not:

- Among losers: $\mathrm{D}/\mathrm{P}$ Q5−Q1 = **0.92%**/month ($t=4.62$)—three times the univariate spread.
- Among winners: only **0.15%** ($t=0.74$)—again dead.
- Momentum among low-$\mathrm{D}/\mathrm{P}$ (expensive) names: **1.53%**/month ($t=5.81$).

Interaction portfolio $[(Q_5,Q_5)+(Q_1,Q_1)]-[(Q_5,Q_1)+(Q_1,Q_5)]$ averages **−0.77%**/month ($t=-3.08$).

---

## 5. Interpretation Without Adjudication

Asness walks through both camps and shows the interaction is **compatible with either**:

**Rational distress (Fama–French).** $\mathrm{BV}/\mathrm{MV}$ is a noisy distress proxy. Conditional on being a **winner**, a high BV/MV firm is unlikely to be distressed—recent returns contradict distress—so the proxy’s loading on the true risk factor collapses among winners. Value “fails” among winners because the characteristic ceases to proxy risk there.

**Behavioral / aversion (Lakonishok–Shleifer–Vishny).** Investors dislike “bad companies” that value screens flag. Recent winners carry no such stigma regardless of multiples, so the premium to owning uncomfortable names vanishes among winners.

Neither story is preferred. The paper’s contribution is the stylized fact, not a horse race. Open questions left explicit: Is underreaction more prevalent among expensive than cheap firms? Do investors misprice bad news more than good news? Those remain for later debate.

---

## 6. Implementation Implications for a Quant Book

For a manager maximizing expected active return subject to tracking-error (or active-risk) budget, with both value and momentum in the alpha model:

- Naïve independent rankings push the book toward **cheap losers** and **expensive winners** as the pure intersection extremes.
- The interaction says: moving from expensive winners → cheap winners buys little expected return (value is flat among winners). Moving from cheap losers → expensive losers **hurts** a lot (you give up the strong value premium among losers) while also fighting momentum.
- Conjecture (Asness’s words): an informed optimizer may rationally hold **more expensive winners and more cheap losers** than a linear additive model suggests, because the marginal expected-return surface is flatter along the “both good” diagonal than along either axis alone.

In modern language: the alpha model should include a **value × momentum interaction** (or at least regime-conditional value and momentum weights), not just additive $z$-scores. Additive multi-factor scoring will over-own “cheap winners” relative to the empirical surface and under-own the extreme “cheap losers / expensive winners” corners that actually deliver the premium.

Also practical: industry-relative $\mathrm{D}/\mathrm{P}$, nearly useless univariately, becomes a strong conditioned signal once momentum is held fixed (except among top-quintile winners). Do not discard weak univariate value metrics—test them **inside** momentum slices.

---

## 7. Limitations and Caveats

- **Sample:** 1963–1994 US equities; pre-dates much of the subsequent factor zoo, international evidence, and post-2000 implementation (ETFs, crowding). Interaction has largely survived in later AQR / Asness–Moskowitz–Pedersen work, but this paper itself is US mid-sample.
- **Value-weighted within cells:** reduces microcap noise; equal-weight would likely amplify spreads.
- **Industry adjustment:** strengthens results; raw BV/MV would still show an interaction but with different magnitudes.
- **No transaction costs / shorting frictions:** long/short Q5−Q1 within thin cells (especially expensive losers) may be costly.
- **No formal risk model:** betas reported but no HML/UMD joint regression; the interaction is in raw returns.
- **Does not distinguish risk vs mispricing**—by design.

---

## 8. Bottom Line for Paleologo-Facing Use

1. Value and momentum are **negatively correlated**, each univariately positive for expected returns.
2. Holding the other fixed usually **strengthens** each—but the marginal slopes are **conditional**: value ≈ dead among winners; momentum ≈ strongest among expensive names.
3. Formal interaction $t\approx -3.5$ (BV/MV) and $t\approx -3.1$ ($\mathrm{D}/\mathrm{P}$).
4. Univariate weakness of $\mathrm{D}/\mathrm{P}$ masks a strong conditioned signal among non-winners.
5. Multi-signal equity construction should not treat value and momentum as additive independent alphas; the interaction is first-order for expected-return surfaces and for how much “both cheap and winning” a constrained optimizer should chase.

**Replication note (one pass).** Rebuild NYSE-breakpoint quintiles on $\mathrm{PAST}(2,12)$ and industry-relative $\log(\mathrm{BV}/\mathrm{MV})$, form 25 VW portfolios July 1963–Dec 1994, recompute the corner interaction portfolio; target ≈ −85 bp/month. Extend out-of-sample and add costs before treating as a live trading rule.


---

## 9. Detailed Reading of Characteristic Controls

A natural concern is that the interaction is an artifact of uneven characteristic spreads: maybe value “fails” among winners simply because there is no value dispersion left once you condition on being a winner. Tables 4–5 and Figures 2–3 reject that.

Within the winner row of Table 4, average raw $\log(\mathrm{BV}/\mathrm{MV})$ still runs from about $-1.64$ (expensive) to $+0.13$ (cheap)—a spread of roughly 1.8 log points, comparable to or larger than the loser-row spread ($-1.24$ to $+0.29$). $\mathrm{D}/\mathrm{P}$ among winners runs from 1.32% to 6.34%. The characteristic engine is running; the **return** engine is not.

Symmetrically, within the expensive column, $\mathrm{PAST}(2,12)$ still spans roughly $-0.92\%$ to $+5.01\%$ average monthly past return—if anything a **wider** momentum gap than among cheap stocks (where losers are even more negative but winners are similar). So momentum’s larger return spread among expensive names is not because the sort creates a bigger past-return wedge there.

One noted exception (footnote 6): among losers only, sorting on $\log(\mathrm{BV}/\mathrm{MV})$ induces a **negative** residual spread in $\mathrm{PAST}(2,12)$—cheaper losers are even bigger recent losers. That mechanical link should, if anything, **hurt** value within losers (you are buying the worst momentum). Empirically value is **strongest** among losers anyway—so the interaction survives a bias working against it.

Industry-adjusted spreads (not tabulated as returns but discussed) also do not collapse within momentum slices. The failure of value among winners is therefore a **pricing** fact, not a sorting failure.

---

## 10. Connection to the Broader Factor Literature (as of 1997 and after)

**Contemporaneous anchors.** Jegadeesh–Titman (1993) establish 6–12 month momentum; Fama–French (1992, 1993) establish BV/MV as a cross-sectional and time-series factor; Lakonishok–Shleifer–Vishny (1994) push cash-flow/price and behavioral extrapolation; Asness (1995) already showed momentum survives after common value controls and that skipping month $t-1$ matters. This 1997 FAJ piece is the interaction paper that sits between those building blocks and later integrated treatments.

**What a modern reader should map it to.** Later work (Asness–Moskowitz–Pedersen “Value and Momentum Everywhere,” Moskowitz–Grinblatt industry momentum, Daniel–Titman characteristics vs covariances, etc.) generalizes and internationalizes. The 1997 interaction—value weak among winners, momentum strong among expensive—remains a useful diagnostic when you rebuild US or global double sorts. If your backtest shows additive value+momentum without interaction, check whether you are (a) using overlapping definitions that already embed the other signal, (b) equal-weighting microcaps, or (c) looking at a sample where the interaction attenuated.

**Distress vs behavioral still open here.** The paper’s explicit agnosticism is a feature: it refuses to pretend a double-sort table identifies structural risk. For a research agenda, the clean next tests are: (i) does conditional value among winners still load on a distress factor in a spanning regression? (ii) do analyst forecast errors or earnings-announcement drifts concentrate in the expensive-loser / cheap-loser cells differently?

---

## 11. Quant Implementation Checklist

1. **Signal definitions.** Use $\mathrm{PAST}(2,12)$ (skip 1); industry-relative value (49 industries or GICS analog); update book/dividends with fiscal lag.
2. **Univariate sanity.** Reproduce ~80–90 bp/month momentum Q5−Q1 and ~50 bp value Q5−Q1 value-weighted over a comparable sample before trusting the double sort.
3. **Double-sort dashboard.** Always report the 5×5 return surface **and** the characteristic surfaces. If returns flatten among winners but characteristics do not, you have the Asness interaction.
4. **Interaction portfolio.** Trade $[(Q_5,Q_5)+(Q_1,Q_1)]-[(Q_5,Q_1)+(Q_1,Q_5)]$ as a single diagnostic; expect negative mean if the 1997 pattern holds.
5. **Alpha model.** Prefer either (a) interaction term in the cross-sectional regression / ML model, or (b) momentum-conditioned value weights (downweight value among top momentum) and value-conditioned momentum weights (upweight momentum among expensive).
6. **Optimizer.** With TE constraint, do not treat “max value z + max momentum z” as unconstrained ideal; the empirical surface says the joint maximum is less valuable than the sum of margins.
7. **Weak univariate metrics.** Re-test $\mathrm{D}/\mathrm{P}$, earnings yield, etc. **inside** momentum buckets before discarding.
8. **Costs.** Expensive-loser shorts and cheap-loser longs can be capacity- and borrow-constrained; haircut the paper’s frictionless spreads.

---

## 12. Numerical Summary Table (paper’s key spreads)

| Strategy | Conditioning | Monthly spread | $t$ |
|----------|--------------|---------------:|----:|
| Momentum univariate | all | 0.87% | 3.73 |
| Value $\log(\mathrm{BV}/\mathrm{MV})$ univariate | all | 0.51% | 3.18 |
| $\mathrm{D}/\mathrm{P}$ univariate | all | 0.31% | 2.10 |
| Value among losers | mom Q1 | 0.97% | 4.38 |
| Value among winners | mom Q5 | 0.13% | 0.65 |
| Momentum among expensive | value Q1 | 1.47% | 5.71 |
| Momentum among cheap | value Q5 | 0.62% | 2.57 |
| $\mathrm{D}/\mathrm{P}$ among losers | mom Q1 | 0.92% | 4.62 |
| $\mathrm{D}/\mathrm{P}$ among winners | mom Q5 | 0.15% | 0.74 |
| Momentum among low $\mathrm{D}/\mathrm{P}$ | $\mathrm{D}/\mathrm{P}$ Q1 | 1.53% | 5.81 |
| Interaction (BV/MV) | corners | −0.85% | −3.50 |
| Interaction ($\mathrm{D}/\mathrm{P}$) | corners | −0.77% | −3.08 |

Annualizing roughly ($\times 12$, ignoring compounding): univariate momentum ~10%/year, value among losers ~12%/year, value among winners ~1.5%/year, momentum among expensive ~18%/year. Those are paper-frictionless, value-weighted, mid-sample magnitudes—useful as calibration targets, not as live expected returns.

---

## 13. Final Takeaways

Asness (1997) establishes that value and momentum are not merely correlated antagonists in the cross-section; their **return premia are state-dependent on each other**. Value is a losers’ strategy; momentum is an expensive-stock strategy. Any quantitative process that blends the two without modeling that interaction will misallocate risk budget along the “both attractive” diagonal and leave expected return on the table in the corners. The paper is short, empirical, and deliberately non-doctrinal on risk versus behavior—exactly the sort of stylized-fact note that should sit next to Jegadeesh–Titman and Fama–French on a practitioner’s shelf.


---

## 14. Worked Example: How an Additive Scorer Goes Wrong

Suppose a simple z-score model
$$
\alpha_i = z^{\mathrm{val}}_i + z^{\mathrm{mom}}_i
$$
and a long/short book that buys the top decile of $\alpha$ and shorts the bottom. The top decile will be enriched in names that are **simultaneously** high value and high momentum—the $(Q_5,Q_5)$-ish region—while the short side will be enriched in $(Q_1,Q_1)$ (expensive losers).

From Table 4, the average return of the cheap-winner cell is 1.62%/month; the expensive-loser cell is 0.03%/month. The long/short of those two corners is large—but compare to alternatives:

- Long cheap-loser (1.00%) / short expensive-loser (0.03%): value-among-losers spread ≈ 0.97%.
- Long expensive-winner (1.50%) / short expensive-loser (0.03%): momentum-among-expensive ≈ 1.47%.
- Long cheap-winner (1.62%) / short expensive-winner (1.50%): value-among-winners ≈ 0.12%.

An additive optimizer that forces “max both” pays almost nothing on the last leg while concentrating names that may be crowded, high-beta, or capacity-constrained. A better heuristic: **maximize momentum among the expensive half; maximize value among the loser half**; treat the cheap-winner pocket as diversification, not as the alpha peak.

In mean-variance / TE language, the gradient of expected return with respect to value exposure is near zero on the winner slice, so the optimizer should not spend TE buying value there. The gradient with respect to momentum exposure is largest on the expensive slice, so TE spent on momentum should concentrate there.

---

## 15. Statistical Design Notes

- **NYSE breakpoints with Amex/Nasdaq assignment** prevent Nasdaq microcaps from defining the extreme quintiles—important for both momentum (tiny losers) and value (tiny cheap).
- **Value-weighting within cells** makes the results relevant to dollar-weighted implementable portfolios; equal-weight would likely show larger spreads and more noise.
- **Industry relative value** removes industry-level BV/MV and D/P that may reflect industry risk or accounting conventions rather than stock-level mispricing/distress.
- **Skip-month momentum** is now standard; without it, short-term reversal partially offsets medium-term momentum and muddies the interaction.
- **t-stats on long/short** assume standard errors adequate for monthly overlapping-ish portfolios; Asness does not report Newey–West, but with ~378 months the −3.5 interaction t is unlikely to be a pure serial-correlation artifact.

---

## 16. What This Paper Is Not

It is not a claim that value is dead among all high-momentum stocks forever; it is a mid-sample US equity interaction. It is not a transaction-cost-aware backtest. It is not a horse race between HML and UMD in a spanning regression. It is not international. Treat it as the **canonical double-sort documentation** of value–momentum dependence, then update with your own sample, costs, and risk model.


---

## 17. Cross-Checks a Reader Should Run

1. Rebuild Table 1–3 on CRSP/Compustat with the same lags; confirm momentum ~0.8–1.0%/month and value ~0.4–0.6%/month order of magnitude.
2. Rebuild Table 4; verify winner-row value spread near zero and expensive-column momentum spread near 1.5%/month.
3. Compute the corner interaction; target $t$ beyond $-3$.
4. Repeat with earnings yield / cash-flow yield instead of D/P; expect similar conditioning.
5. Split sample 1963–1979 vs 1980–1994; interaction should appear in both if robust.
6. Add 1-month reversal as a third sort; confirm skip-month choice is material.
7. Post-1994 holdout: does value among winners stay flat through the value crash of 1999–2000 and the momentum crashes of 2009 / 2020? (Out of paper scope, but decision-relevant for live use.)

If (2)–(3) fail on your data, the discrepancy is itself informative—definition drift, industry schema, or genuine regime change.


---

## 18. Closing Synthesis

The Interaction of Value and Momentum Strategies is a compact empirical paper with outsized practical weight. Its central message—that two of the most used cross-sectional signals are not only negatively correlated as characteristics but **conditionally dependent as return predictors**—should change how multi-factor equity processes are specified, how optimizers are constrained, and how weak univariate value metrics are evaluated. Reproduce the 5×5 surface, respect the interaction $t$-stat, and do not spend tracking error buying value among winners or ignoring momentum among expensive names. That is the whole actionable content; everything else is interpretation and robustness around it.


---

## 19. Extended Numerical Walkthrough of Table 4 Corners

Label cells by (momentum quintile, value quintile). Corner returns from the paper:

- $(1,1)$ expensive loser: 0.03%/month
- $(1,5)$ cheap loser: 1.00%/month
- $(5,1)$ expensive winner: 1.50%/month
- $(5,5)$ cheap winner: 1.62%/month

Value among losers: $1.00-0.03=0.97$. Value among winners: $1.62-1.50=0.12$. Momentum among expensive: $1.50-0.03=1.47$. Momentum among cheap: $1.62-1.00=0.62$.

Interaction portfolio return:
$$
[(5,5)+(1,1)]-[(5,1)+(1,5)] = (1.62+0.03)-(1.50+1.00)=1.65-2.50=-0.85,
$$
matching the reported −0.85%/month. This arithmetic is the entire interaction test; the $t=-3.50$ says the −85 bp is not noise over July 1963–Dec 1994.

Annualized without compounding: interaction ≈ −10.2%/year. That is the expected return you **leave on the table** (with sign) if you treat the two marginals as additive and overweight the “both good / both bad” diagonal relative to the empirical surface.

---

## 20. Industry-Relative D/P as a Cautionary Tale for Signal Retirement

Univariate industry-relative D/P delivered only 31 bp/month ($t=2.10$)—borderline for a standalone factor after costs. Many research processes would kill it. Conditional on loser status it delivered 92 bp ($t=4.62$). The signal was not dead; it was **masked** by its negative correlation with momentum and by failure among winners. Process implication: maintain a “conditional re-test” queue for weak univariate value metrics before retirement.
