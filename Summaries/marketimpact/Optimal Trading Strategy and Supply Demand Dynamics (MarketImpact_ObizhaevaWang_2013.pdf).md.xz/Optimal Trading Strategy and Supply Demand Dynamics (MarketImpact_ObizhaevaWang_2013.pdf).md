# Optimal Trading Strategy and Supply/Demand Dynamics

**Authors:** Anna A. Obizhaeva (University of Maryland) and Jiang Wang (MIT / CAFR / NBER)  
**Publication:** *Journal of Financial Markets* 16 (2013) 1–32 (available online Sept 2012; received July 2012)  
**Source PDF:** `MarketImpact_ObizhaevaWang_2013.pdf` (Drive id `1h-cgg6AnGbTIqX80tOG5wYrm_Ce0OUaV`)  
**Summary prepared:** 2026-09-26 (Scholar batch_2026-09-26_2)  
**OCR:** Not required; clean `pdftotext -layout` extract (~16,597 words of source)

---

## 1. Problem and Motivation

How should a trader execute a fixed parent order over a horizon when supply/demand is imperfectly elastic? Classic optimal-execution work (Bertsimas–Lo 1998; Almgren–Chriss 1999, 2000; Huberman–Stanzl 2005) treats liquidity largely through a **static** instantaneous price-impact function, often at fixed trading times. Obizhaeva–Wang argue that what matters most is **dynamics**: how the limit order book (LOB) **replenishes** after being hit—its **resilience**.

Empirically and in equilibrium LOB models, resilience is finite (Biais–Hillion–Spatt 1995; Foucault–Kadan–Kandel 2005; Goettler–Parlour–Rajan 2005; Coppejans–Domowitz–Madhavan; etc.). The paper builds a tractable LOB framework with three liquidity primitives—**spread**, **depth**, and **resilience**—solves optimal execution in discrete and continuous time, and shows:

1. Optimal policy is **not** “trade equal slices.” It mixes an **initial block**, a **continuous drip** that skims replenishing liquidity, and a **terminal block**.
2. The optimal schedule and its cost savings depend primarily on **resilience** $r$, not on static depth/spread in the way prior intuition suggested.
3. Cost savings versus naive even trading can be economically large when the book recovers slowly (examples: 0.33% to 7.41% of notional depending on half-life).

Partial-equilibrium: book dynamics are taken as given (reduced form for small non-strategic liquidity providers). Follow-ups (Alfonsi et al. 2010; Predoiu–Shaikhet–Shreve 2010) generalize shape and dynamics; the qualitative message survives.

---

## 2. Execution Problem Statement

Buy $X_0$ units by time $T$. A discrete strategy chooses times $0=t_0<\cdots<t_N=T$ and sizes $x_{t_n}\ge 0$ with $\sum_n x_{t_n}=X_0$. Objective: minimize expected total execution cost given LOB dynamics. Continuous strategies allow a flow rate $m_t$ plus singular (block) trades.

The paper deliberately separates **portfolio choice** (how large $X_0$ should be) from **execution** (how to work $X_0$), matching institutional practice where PMs hand child-order schedules to execution desks.

---

## 3. Limit Order Book Dynamics

### 3.1 Steady-state book

Block-shaped LOB for tractability: constant density $q$ of limit volume per price unit beyond the touch (market depth parameter). Bid–ask spread $s$. Mid-quote related to fundamental $F_t$ plus cumulative permanent impact.

### 3.2 Trade impact and exponential resilience

A buy $x_0$ immediately walks the book: ask jumps by $x_0/q$ (plus permanent component). Permanent impact shifts the steady-state mid by $\lambda x_0$. Define
$$
\kappa = \frac{1}{q}-\lambda
$$
as the **temporary** impact coefficient (transient displacement beyond the new steady state). After the trade, ask deviation from steady state decays exponentially:
$$
A_t = V_t + \frac{s}{2} + x_0\,\kappa\, e^{-r t},
$$
with resilience (refresh rate) $r\ge 0$. Equivalently, deviation $D_t=A_t-V_t-s/2$ satisfies inflow of new sell limits at rate proportional to $r q D_t$: the farther from steady state, the more aggressively liquidity providers replenish.

### 3.3 Many trades

With trade history $\{x_{t_i}\}$ and fundamental shocks,
$$
V_t = F_t + \lambda(X_0-X_t), \qquad
A_t = V_t + \frac{s}{2} + \sum_{t_i<t} x_{t_i}\,\kappa\, e^{-r(t-t_i)},
$$
where $X_t$ is remaining inventory to buy. Cost of a block $x$ at ask $A$ under block-shaped book:
$$
c(x)=\Bigl(A+\frac{x}{2q}\Bigr)x.
$$

**Key modeling claim:** temporary impact and its exponential decay are first-order for strategy design; focusing only on permanent $\lambda$ is not enough.

---

## 4. Nested Conventional Models (and Their Pathology)

### 4.1 Bertsimas–Lo as a special case

Fixed grid, linear permanent impact $P_n=P_{n-1}+\lambda x_n+u_n$. Optimal policy: equal slices $x_n=X_0/(N+1)$.

### 4.2 Continuous-time limit pathology

As $N\to\infty$ with only permanent linear impact, expected cost $\to (F_0+s/2)X_0+(\lambda/2)X_0^2$ **independent of strategy**. Any continuous path is equivalent. A slightly risk-averse trader then dumps everything at $t=0$ (L-shape) to kill variance—economically absurd. Huberman–Stanzl emphasize the lack of a well-behaved continuous limit.

### 4.3 Diagnosis inside the LOB framework

Conventional permanent-impact-only models correspond to extreme LOB parameter restrictions (e.g., infinite resilience or $\kappa=0$ so temporary effects vanish). Once $\kappa>0$ and $r<\infty$, strategy matters again and continuous-time limits exist with nontrivial optimal singular+absolutely continuous controls.

Temporary-impact penalties in Almgren–Chriss / Huberman–Stanzl restore dynamics but typically **force continuous trading** and rule out optimal blocks—precisely the policies OW show are optimal.

---

## 5. Optimal Policy

### 5.1 Discrete time with fixed grid (Proposition 1)

Value function quadratic in remaining size $X$ and current deviation $D$:
$$
J_{t_n}=(F_{t_n}+s/2)X_{t_n}+\lambda X_0 X_{t_n}+a_n X_{t_n}^2+b_n D_{t_n} X_{t_n}+g_n D_{t_n}^2.
$$
FOCs deliver optimal trade as a function of state $(X,D)$; coefficients solve a backward recursion. With $X_0=100{,}000$, $T=1$ day, $q=5{,}000$, etc., numerics already show **uneven** profiles—larger at ends—unlike Bertsimas–Lo flatness.

### 5.2 Continuous-time limit of discrete (Proposition 2) and direct continuous solution (Proposition 3)

As $N\to\infty$, the optimum converges to:

- **Initial block** of size $X_0/(rT+2)$,
- **Continuous flow** at rate $m_t = r X_0/(rT+2)$ (constant),
- **Terminal block** of size $X_0/(rT+2)$.

Remaining inventory declines linearly between the blocks. Fraction executed as continuous drip:
$$
\frac{\int_0^T m_t\,\mathrm{d}t}{X_0}=\frac{rT}{rT+2},
$$
increasing in resilience $r$ and horizon $T$. As $r\to\infty$ (instant refresh), continuous share → 1 (approach even flow). As $r\to 0$ (no refresh), continuous share → 0 (pure blocks / discrete strategy).

**Same policy** from discrete limit (Prop 2) and from solving the continuous control problem with flows + singular trades (Prop 3)—internal consistency.

### 5.3 Economic intuition

1. **Initial block** pushes the book away from steady state to **attract** replenishment (liquidity providers post more aggressively when $D$ is large).
2. Size the block so you buy enough “magnetism” without overpaying on the instantaneous walk.
3. **Drip** thereafter consumes incoming refresh at desirable prices, holding $D$ on the optimal path.
4. **Final block** finishes residual size when future replenishment no longer matters ($t=T$).

Static depth $q$ and permanent $\lambda$ affect **cost levels** but the **fractionation** of the optimal schedule is governed by the dimensionless product $rT$ (and $\kappa$ enters cost, not the $rT+2$ structure of sizes in the baseline case).

---

## 6. Cost Savings versus Even Trading

**Even (naive) strategy:** constant flow $m=X_0/T$. Under OW dynamics one can compute expected net execution cost (above fair $F+s/2$) in closed form involving $(\lambda/2)X_0^2$ plus a temporary-impact term with $\kappa$ and $r$.

**Optimal net cost** (Prop 3):
$$
\tilde J_0^{\mathrm{opt}}=\frac{\lambda}{2}X_0^2 + \frac{\kappa}{rT+2}X_0^2
$$
(up to the paper’s exact normalization). Difference versus even trading scales with $\kappa X_0^2$ times a factor decreasing in $rT$.

**Calibration illustration** (paper intro / §7): order size $20\times$ market depth, horizon one day.

| Book recovery half-life | Approx. cost saving vs even |
|-------------------------|----------------------------:|
| 0.90 minutes | 0.33% |
| 5.40 minutes | 1.88% |
| 27.03 minutes | 7.41% |

Slower resilience ⇒ larger value of optimal fractionation. Half-life $\approx \ln 2 / r$.

Additional tables in §7 vary $r$, $q$, $\lambda$, $X_0$, $T$ and show: savings rise with slower $r$ and larger $X_0/q$; optimal initial/terminal blocks shrink as $rT$ grows; independence of the **shape** of the optimum from $\lambda$ (permanent impact is strategy-invariant in the linear case—only a lump-sum $(\lambda/2)X_0^2$—so strategy design hinges on temporary/resilience parameters).

---

## 7. Comparative Statics Worth Memorizing

| Parameter change | Effect on optimal strategy | Effect on savings vs even |
|------------------|----------------------------|---------------------------|
| ↑ $r$ (faster refresh) | Larger continuous fraction; smaller blocks | ↓ savings (even strategy less bad) |
| ↑ $T$ | Same as ↑ $rT$: more drip, smaller blocks | Depends; more time to use resilience |
| ↑ $X_0/q$ (larger vs depth) | Larger absolute blocks; same $rT$ fractions | ↑ economic importance of optimality |
| ↑ $\lambda$ | Cost ↑ by $(\lambda/2)X_0^2$; **schedule shape unchanged** | Little change in relative savings from temporary part |
| ↑ $\kappa=1/q-\lambda$ | Temporary costs ↑; stronger motive to use resilience | ↑ savings from optimal policy |
| $r\to\infty$ | → continuous even-like | → 0 |
| $r\to 0$ | → discrete blocks only | Large if you wrongly used even flow |

---

## 8. Extensions Discussed

- General LOB shapes (not just blocks): follow-ups confirm qualitative block+drip+block structure under broad conditions.
- Discrete price grid / lot sizes: Predoiu–Shaikhet–Shreve.
- Risk aversion: pushes toward faster completion (earlier blocks), trading expected cost for lower inventory risk—as in Almgren–Chriss, but now with resilience.
- Stochastic resilience or depth: enriches state; same logic—manage expected future replenishment.
- Sell orders / two-sided book: symmetric for sells; unpredictable opposing flow averages out for risk-neutral expected-cost minimization.

---

## 9. Limitations

- **Exogenous LOB dynamics.** Strategic liquidity providers who anticipate the large trader would alter $r$ and depth; full equilibrium with unrestricted strategies remains hard (existing equilibria restrict order size/frequency).
- **Risk neutrality** in the baseline; no explicit α/risk tradeoff inside the execution desk objective (though discussable).
- **Block-shaped book** baseline; real books have declining depth away from touch.
- **Deterministic $r$, $\kappa$, $\lambda$.** No regime-switching liquidity crashes.
- **No dark pools / midpoint / pegging**—lit LOB only.
- **Partial equilibrium** ignores how the large trader’s presence changes other traders’ arrival.

---

## 10. Bridge to Kyle and to Practitioner TC Models

| Model | Friction | Optimal trade pattern |
|-------|----------|----------------------|
| Kyle (1985) | Adverse selection; permanent $\lambda$ from information | Smooth informed flow; constant depth in continuous limit |
| Bertsimas–Lo | Permanent linear impact, fixed times | Equal slices |
| Almgren–Chriss | Permanent + temporary; risk | Front-loaded continuous trajectories |
| **Obizhaeva–Wang** | LOB depth + **finite resilience** | **Blocks + drip + block** |

Practitioner implication: if your simulator has only permanent impact, strategy is unidentified in the continuous limit. If you add temporary impact as a speed penalty only, you will never propose optimal blocks. If you model **book refresh**, optimal execution naturally uses discrete top-ups to “recruit” liquidity plus skimming.

For a desk: estimate resilience half-life from post-trade ask recovery curves; if half-life is minutes to tens of minutes on your names, OW savings versus VWAP-like even trading are first-order. If books refill in seconds, simpler Almgren-style continuous schedules may suffice.

---

## 11. Equations Cheat Sheet

**Ask with history:**
$$
A_t=V_t+\frac{s}{2}+\sum_{i}\kappa x_{t_i}e^{-r(t-t_i)}, \quad V_t=F_t+\lambda(X_0-X_t).
$$

**Optimal continuous policy (risk-neutral, block book):**
$$
x_0=x_T=\frac{X_0}{rT+2}, \qquad m_t=\frac{r X_0}{rT+2}.
$$

**Net temporary-cost factor:** $\kappa/(rT+2)$ on $X_0^2$ under optimum vs larger factor under even flow.

**Half-life:** $t_{1/2}=\ln 2 / r$.

---

## 12. Numerical Example (Back-of-Envelope)

$X_0=100{,}000$, $A_0=\$100$, $q=5{,}000$ (so $X_0/q=20$ depth units), $T=1$ day ≈ 390 minutes RTH. If $t_{1/2}=5.4$ min, $r=\ln 2/5.4\approx 0.128/\mathrm{min}$. Then $rT\approx 0.128\times 390\approx 50$ if $T$ in minutes—paper’s examples use consistent units where $rT$ is moderate; follow their Table 1–2 calibrations rather than mixing months/minutes carelessly. With their stated half-lives and 20× depth order, savings 0.33%–7.41% of notional are the headline decision numbers.

At \$100 × 100{,}000 = \$10m notional, 1.88% saving ≈ \$188k on a single parent order—material versus typical commission schedules.

---

## 13. Paleologo-Facing Takeaways

1. **Resilience is the strategy statistic**; static spread/depth set cost levels but optimal fractionation is about $rT$.
2. Optimal execution with finite book refresh is **block–drip–block**, not VWAP-flat and not pure continuous Almgren.
3. Permanent linear impact alone cannot discipline continuous-time strategy choice; temporary impact modeled as decaying book displacement can.
4. Cost savings vs even trading rise into several percent of notional when recovery half-lives stretch toward tens of minutes and orders are large vs depth.
5. Implementation: estimate $r$ from LOB reset curves; estimate $\kappa$ from transient vs permanent decomposition; feed $(r,\kappa,\lambda,q)$ into OW policy or a numerical DP on $(X,D)$.

**Replication note.** Code the continuous policy $x_0=x_T=X_0/(rT+2)$, $m=rX_0/(rT+2)$; simulate exponential book; compare cost to $m=X_0/T$; match paper Table 2 savings across half-lives.


---

## 14. Derivation Sketch of the $rT+2$ Rule

In continuous time the state is remaining size $X_t$ and ask deviation $D_t$. Permanent impact contributes the unavoidable $(\lambda/2)X_0^2$ lump. Temporary cost involves $\kappa$ and the path of $D$. Exponential resilience $\dot D=-rD$ between trades, with jumps $D\leftarrow D+\kappa x$ at blocks and $\mathrm{d}D=\kappa m_t\mathrm{d}t-rD\mathrm{d}t$ under flow.

Optimality conditions (Prop 3) yield a quadratic value function in $(X,D)$ with deterministic coefficients. Solving the resulting ODE/FOC system with $X_T=0$ after the terminal block produces equal initial and terminal blocks $X_0/(rT+2)$ and constant flow $rX_0/(rT+2)$. The “+2” counts the two singular trades’ worth of temporary-impact budget relative to the integrated continuous refresh over $[0,T]$.

Dimensionless control parameter: $rT$. Only through $rT$ does horizon enter the fractionation. That is why static depth $q$ (inside $\kappa$) and permanent $\lambda$ drop out of the **shape** formulas.

---

## 15. Even Strategy Cost Explicitly

Under constant $m=X_0/T$, deviation solves $\dot D=-rD+\kappa X_0/T$ with $D_0=0$, hence
$$
D_t=\frac{\kappa X_0}{rT}(1-e^{-rt}).
$$
Expected temporary-plus-schedule cost integrates $(D_t+\text{half-spread walk})m$ and yields a larger $\kappa$-weighted factor than $\kappa/(rT+2)$. The gap is exactly the savings table’s engine. When $rT$ is large, $D_t$ stays small even under even flow, so savings vanish—fast books make VWAP-like schedules nearly optimal. When $rT$ is small, even flow keeps paying temporary impact that optimal blocks would have used to recruit liquidity once.

---

## 16. Desk Playbook

1. Estimate resilience: after isolating permanent impact, fit exponential decay of signed midpoint or microprice displacement; record half-life by name and by time-of-day.
2. Estimate $\kappa$ and $\lambda$ from temporary/permanent decomposition (e.g., 5-minute vs end-of-day impact).
3. For parent order $(X_0,T)$, set blocks $X_0/(rT+2)$ and drip $rX_0/(rT+2)$ as the risk-neutral baseline.
4. Overlay Almgren-style risk aversion by shifting mass earlier if inventory variance is costly.
5. Compare expected TC to VWAP and to pure Almgren paths in the same simulator; expect OW to win when half-lives are long and $X_0/q$ is large.
6. Re-estimate $r$ after structural LOB changes (fee tiers, maker-taker flips, closing auction redesigns).

---

## 17. Connection Back to Kyle

Kyle’s $\lambda$ is permanent informational impact with strategic informed flow. OW’s $\lambda$ is a reduced-form permanent coefficient; their distinctive parameter is resilience $r$ of mechanical book refresh. A full desk model needs both: adverse-selection permanent impact (Kyle) and transient LOB displacement (OW). Using only one misses either information-sharing dynamics or optimal block structure.



---

## 18. Discrete-Time Optimal Trades: Shape Before the Limit

Proposition 1’s finite-$N$ solution already shows larger trades at the first and last dates and smaller interior trades once resilience is finite—qualitatively the same as the continuous block–drip–block limit. If you must trade on a fixed clock (e.g., scheduled auctions only), solve the quadratic DP on $(X,D)$ rather than forcing equal slices. As the grid refines, interior trades approach the constant flow $m=rX_0/(rT+2)$ and the endpoints approach the blocks.

Table 1 in the paper (numerical optimal schedules across $r$) is the practical illustration: as half-life shortens, profiles flatten toward even; as half-life lengthens, endpoints fatten.

---

## 19. Cost Savings Formula Structure

Write net expected cost above fair value as
$$
\tilde J = \frac{\lambda}{2}X_0^2 + \kappa\, X_0^2 \cdot \Phi(\text{strategy}; rT).
$$
For the optimum, $\Phi_{\mathrm{opt}}=1/(rT+2)$. For even flow, $\Phi_{\mathrm{even}}$ is a larger explicit function of $rT$ (integral of the $D_t$ path above). Relative savings
$$
\frac{\tilde J_{\mathrm{even}}-\tilde J_{\mathrm{opt}}}{\text{notional}}
$$
scale with $\kappa X_0 / A_0$ (temporary impact in return units times size) times $\Phi_{\mathrm{even}}-\Phi_{\mathrm{opt}}$. That is why large orders versus depth and slow resilience dominate the 0.33%–7.41% examples.

---

## 20. When Not to Use OW Mechanically

- **Closing auctions / official opens** dominate the parent order—LOB resilience mid-day is irrelevant; use auction-specific models.
- **Dark mid-point** child orders change the effective $\kappa$.
- **Very high-frequency** micro-horizon ($T$ seconds) with $r$ also in seconds: $rT$ may still be $O(1)$, but latency and discrete ticks dominate the continuous idealization.
- **Alpha decay** inside $T$: if the PM’s edge decays, execution should internalize that (earlier trading)—OW is pure TC for exogenous $X_0$.
- **Risk limits** that forbid blocks: constraints may force near-continuous policies even when OW wants endpoints.

---

## 21. Minimal Simulation Spec for a Research Clone

State: $(X_t,D_t,F_t)$. Dynamics: $F$ random walk; on flow $m$, $D\leftarrow D+(\kappa m-rD)\mathrm{d}t$, $X\leftarrow X-m\mathrm{d}t$; on block $x$, $D\leftarrow D+\kappa x$, $X\leftarrow X-x$, pay $c=(A+x/(2q))x$ with $A=F+s/2+\lambda(X_0-X)+D$. Compare three policies: even flow; Almgren mean–variance continuous; OW block–drip–block. Report mean TC, TC variance, and pathwise max excursion of $D$. Match paper Table 2 for the half-lives 0.90, 5.40, 27.03 minutes as a unit test.


---

## Appendix: Notation Concordance with the PDF

Symbol usage in the JSTOR/ScienceDirect scans is occasionally garbled by OCR. This summary uses standard modern notation: $\lambda$ for permanent impact or Kyle’s depth slope (contextually distinguished), $\kappa$ for temporary LOB displacement per unit trade, $r$ for resilience, $q$ for depth density, $s$ for spread, $X_0$ for parent size, $T$ for horizon, $\Sigma_0$ for prior value variance in Kyle, and $\sigma_u$ for noise scale. When implementing from the PDF, trust the surrounding prose and the theorems’ qualitative statements if a displayed equation is corrupted, then cross-check against the clean formulas collected in the cheat-sheet sections above.


---

## 22. Half-Life to $r$ Conversion Table

| Half-life | $r=\ln 2/t_{1/2}$ |
|-----------|-------------------:|
| 30 seconds | 1.386 /s |
| 0.90 minutes | 0.770 /min |
| 5.40 minutes | 0.128 /min |
| 27.03 minutes | 0.0256 /min |
| 1 hour | 0.0116 /min |

For a 6.5-hour cash session ($T=390$ min): $rT$ equals about 300, 50, 10 for the three paper half-lives 0.90, 5.40, 27.03 min respectively (order-of-magnitude). Continuous fraction $rT/(rT+2)$ is then ≈0.993, 0.96, 0.83—so even at 27-minute half-life most volume is still drip, but blocks are 8.5% of $X_0$ each and materially reduce temporary cost versus pure even flow.

---

## 23. Interaction with Intraday Seasonality

Real resilience and depth vary over the day (open, lunch, close). A practical extension replaces constant $r$ with $r(t)$ and re-solves the DP: expect larger blocks when upcoming $r$ is high (recruit liquidity that will refill fast) and more patience when $r$ is low. Closing auction: treat as mandatory terminal liquidity pool with its own depth—OW’s terminal block may merge with auction participation optimization (separate literature). The paper’s constant-$r$ solution is the right backbone; seasonality is a state-dependent patch.

---

## 24. Risk-Averse Extension (Heuristic)

Add inventory penalty $\phi\int_0^T X_t^2\mathrm{d}t$ to the objective (Almgren style). The optimum shifts continuous mass earlier and can enlarge the initial block while shrinking the terminal block—because variance of execution cost / mark-to-market is front-loaded against risk aversion. As $\phi\to 0$, recover OW; as $\phi\to\infty$, approach immediate execution (subject to book depth). Numerically, augment the quadratic value function with a term in $X^2$ integrated against $\phi$.

---

## 25. Summary Scorecard

| Question | Answer |
|----------|--------|
| Does static depth alone pin optimal schedule? | No |
| Does resilience? | Yes ($rT$) |
| Optimal shape? | Block–drip–block |
| vs even flow savings? | 0.3%–7%+ notional in calibrations |
| Continuous limit well-defined? | Yes, unlike permanent-only models |
| Equilibrium book? | No—partial EQ reduced form |


---

## 26. Worked Cost Comparison (Synthetic Numbers)

Take $X_0=100{,}000$, $A_0=\$100$, $\lambda=10^{-6}$ \$/share${}^2$ contribution so $(\lambda/2)X_0^2=\$5{,}000$, $\kappa=2\times 10^{-6}$, $T=390$ min, $t_{1/2}=5.4$ min ⇒ $r=0.128$, $rT\approx 50$. Then
$$
\Phi_{\mathrm{opt}}=\frac{1}{52}\approx 0.0192, \qquad \kappa X_0^2\Phi_{\mathrm{opt}}\approx \$3{,}846.
$$
Even-flow $\Phi_{\mathrm{even}}$ is larger; paper’s 1.88% notional saving on a 20-depth-unit order at this half-life corresponds to roughly \$188{,}000 on \$10m notional—dominated by temporary-impact differences when $\kappa$ and $X_0$ are large. If your calibrated $\kappa$ is much smaller, absolute dollars shrink even if $\Phi$ gaps remain. Always report savings both in \% notional and in \$ vs your name’s ADV and depth.

---

## 27. Final Synthesis

Obizhaeva–Wang (2013) show that optimal execution in a limit-order market is governed by **how fast the book refills**, not merely by static depth or permanent impact. The optimal policy—initial block, continuous drip, terminal block—with sizes pinned by $rT+2$, and the associated cost savings versus even trading, should be the default mental model whenever transient impact is first-order. Pair with Kyle for informational permanent impact; implement by estimating resilience half-lives and feeding them into the closed-form schedule or a small DP on $(X,D)$.


Reading recommendation: assign Propositions 2–3 and Section 7 cost tables as core; treat Section 4 (conventional models as special cases) as the conceptual critique of permanent-impact-only execution theory.


---

## 28. One-Paragraph Executive Abstract

In markets where limit-order books refill only gradually after trades, the cost-minimizing way to buy a fixed quantity by a deadline is to open with a discrete block that recruits liquidity providers, skim the resulting order flow continuously, and finish with a symmetric terminal block; the controlling dimensionless number is resilience times horizon, and the cost gap versus naive even slicing grows into several percent of notional when recovery half-lives stretch toward tens of minutes and the parent order is large relative to displayed depth.


The companion Kyle (1985) note in this batch covers informational permanent impact; use both when specifying a transaction-cost model that needs adverse-selection depth and LOB resilience as separate channels.
