# Eigen-Adjusted Covariance Matrices: Improving Risk Forecasts for Optimized Portfolios

**Authors:** Jose Menchero; Jun Wang; D.J. Orr (MSCI)  
**Date:** May 2011  
**Venue:** MSCI Research Insight  
**Keywords:** Covariance matrix; eigenfactors; optimized portfolios; risk bias; Markowitz error maximization  
**Sample:** 50 largest U.S. stocks with full daily histories Jul 1993–Jul 2010 (4,303 trading days); rolling $T=200$ day sample covariances; out-of-sample bias window Apr 15, 1994–Jul 30, 2010 (4,103 days)  
**Source PDF:** `EigenfactorAdjustedCovarianceMatrix_MencheroWangOrr_2011.pdf`  
**Summary prepared:** 2026-09-26 (Scholar batch_2026-09-26_3)  
**OCR:** Not required; clean `pdftotext -layout` extract (~7,155 words of source)

---

## 1. Problem and Motivation

Markowitz (1952) mean–variance optimization needs expected returns and a covariance matrix. In practice both are estimated with error; Michaud (1989) describes optimizers as “error maximizers” that load heavily on assets with spuriously high expected returns or spuriously low covariances. Muller (1993) documented that risk models systematically **underestimate** the risk of optimized portfolios and suggested a rule-of-thumb **+20%** volatility scale—though the needed scale depends on the model’s conditioning.

Shepard (2009) gives an analytic bias under normality and stationarity. If $\sigma_{\mathrm{Pred}}$ is the predicted volatility of an optimized portfolio and $N$ assets are estimated over $T$ observations,

$$\sigma_{\mathrm{True}}=\frac{\sigma_{\mathrm{Pred}}}{1-(N/T)}. \tag{1}$$

For $N=50$, $T=100$, predicted risk is about half of realized risk. Menchero–Wang–Orr dig underneath this formula: they identify **eigenfactor portfolios**—the eigenvectors of the sample covariance—as the primary locus of systematic risk-forecast bias, show how to estimate and remove those biases by Monte Carlo, and demonstrate that de-biasing eigenvariances both (i) restores $B\approx 1$ bias statistics for optimized books and (ii) lowers out-of-sample optimized volatility.

---

## 2. Sample Covariance Construction

Relative (market-neutralized) stock returns are

$$f_{nt}=r_{nt}-R_t^M, \tag{2}$$

where $R_t^M$ is the cap-weighted estimation-universe return. Cap-weighted relative returns sum to zero each day by construction. Incomplete histories are excluded; the universe is the 50 largest U.S. stocks as of Jul 30, 2010 with complete daily returns back to Jul 1, 1993.

The sample covariance over a rolling window of $T=200$ days is

$$V_0(mn)=\frac{1}{T-1}\sum_{t=1}^{T}(f_{mt}-\bar f_m)(f_{nt}-\bar f_n). \tag{3}$$

Index $n=0$ is reserved for the market return $f_{0t}=R_t^M$, so every stock has unit market exposure—analogous to a world factor in a global equity risk model (Menchero–Morozov–Shepard 2010).

---

## 3. Bias Statistics

For a test portfolio with return $R_t$ and start-of-day predicted volatility $\sigma_t$, the standardized return (z-score) is $b_t=R_t/\sigma_t$. The **bias statistic** is the sample standard deviation of $\{b_t\}$ over the testing window $\tau$:

$$B=\sqrt{\frac{1}{\tau-1}\sum_{t=1}^{\tau}(b_t-\bar b)^2}. \tag{5}$$

Roughly, $B$ is realized risk / predicted risk; accurate forecasts give $B\approx 1$. Under normality and perfect forecasts the 95% CI is about $1\pm\sqrt{2/\tau}$, but fat tails and forecast noise (Jensen’s inequality) push $B$ slightly above 1 even for unbiased models. The paper treats $B$ as a diagnostic for **large systematic** bias, not for tiny deviations from one.

---

## 4. Non-Optimized Portfolios Are Fine; Eigenfactors Are Not

**Individual stocks** (returns from eq. 2): bias statistics cluster near 1 across the volatility spectrum (Figure 1a).  
**100 random dollar-neutral portfolios** $R_t^\ell=\sum_n\varepsilon_{n\ell}f_{nt}$ with $\varepsilon_{n\ell}\sim N(0,1)$ and market weight zero: again $B\approx 1$ (Figure 1b).

So $V_0$ forecasts risk accurately for stocks and for unstructured random books. The failure appears when one rotates into the **eigenbasis**.

Diagonalize $V_0=U_0 D_0 U_0'$. Eigenfactor $k$ has return

$$R_t^k=\sum_n u_{nt}^k f_{nt}, \tag{7}$$

with eigenfactors sorted by ascending predicted volatility. The smallest eigenfactor solves the minimum-variance problem under $\sum w_n^2=1$; the largest solves the corresponding maximum-variance problem. Empirically (Figure 1c):

- Smallest eigenfactors have $B\gg 1$ (strong **under**-prediction of risk).  
- Largest eigenfactors have $B$ slightly below 1 (mild **over**-prediction).

This pattern is the structural root of optimized-portfolio bias: optimizers lean into low-eigenvalue directions that look artificially safe in-sample.

---

## 5. Optimized Portfolios: Empirical Bias $\approx 1.45$

Random cap-weighted-mean-zero alphas $\alpha_{nt}^j$ are drawn; the optimizer builds the minimum-volatility book with $\alpha_P=1$ (plus investability so market exposure equals sum of stock exposures). Using $V_0$, bias statistics for 100 such optimized books lie in **1.4–1.5**, average $\approx\mathbf{1.45}$ (Figure 1d). Shepard’s formula predicts $1/(1-50/200)=1.33$; the gap is attributed to non-normality and non-stationarity amplifying estimation error.

---

## 6. Simulated Eigenfactor Biases

Treat $V_0$ as “truth,” simulate $M$ return panels under normality/stationarity, re-estimate $V_m$, diagonalize, and compare predicted eigenvolatilities $\sigma_{mt}(k)$ to “true” volatilities $\tilde\sigma_{mt}(k)$ under $V_0$:

$$\lambda_t(k)=\frac{1}{M}\sum_m\frac{\tilde\sigma_{mt}(k)}{\sigma_{mt}(k)},\qquad \lambda(k)=\frac{1}{T}\sum_t\lambda_t(k). \tag{10–11}$$

Mean simulated bias: smallest eigenfactor $\lambda\approx\mathbf{1.5}$, largest $\lambda\approx\mathbf{0.96}$ (Figure 2). Shape matches empirical Figure 1c; magnitudes are slightly smaller than real-data biases (again: normality/stationarity assumptions). Over ~16 years the 1st–99th percentile bands for the smallest eigenfactor stay in a narrow **1.4–1.6** range—biases are remarkably stable through time.

---

## 7. Eigen-Adjusted Covariance Matrix

Because simulations understate empirical bias, scale simulated biases away from 1:

$$\gamma(k)=a\bigl[\lambda(k)-1\bigr]+1, \tag{A8}$$

with empirical choice $a=\mathbf{1.4}$ effective across the spectrum (and used for all $T$ in Table 1). De-bias the diagonal,

$$\tilde D_0=\gamma^2 D_0, \tag{A9}$$

and rotate back:

$$\tilde V_0=U_0\tilde D_0 U_0'. \tag{A10}$$

This is the **eigen-adjusted covariance matrix**.

### Side effects at the stock level

Diagonal elements of $\tilde V_0$ differ from those of $V_0$. Stock-level bias statistics after adjustment: low-vol stocks $B\approx 0.90$, high-vol stocks $B\approx 1.10$ (Figure 3a). Mechanism: stocks are linear combinations of eigenfactors ($f_{nt}=\sum_k u_{kt}^n R_t^k$); low-vol names (e.g. Chevron, pred. vol 13.7% on Jul 30, 2010) project onto small eigenfactors whose variances were scaled **up**; high-vol names (Citigroup, 31.7%) project onto large eigenfactors scaled **down**. Average stock-level bias is near zero—unlike optimized books, which were **uniformly** biased downward by ~45%.

Random (non-optimized) portfolios retain $B\approx 1$ under $\tilde V_0$ (Figure 3b). Eigenfactor bias spectrum collapses to ~1 (Figure 3c). Optimized books built on $\tilde V_0$ also show $B\approx 1$, matching non-optimized accuracy (Figure 3d).

---

## 8. Out-of-Sample Volatility Improvements

Bias correction is valuable; out-of-sample performance matters more for portfolio construction.

**Minimum-risk fully invested portfolio** (left-most Markowitz frontier point), daily rebalance, Apr 1994–Jul 2010:

| Portfolio | Realized vol (ann.) |
|-----------|--------------------:|
| Cap-weighted universe | 19.84% |
| Min-risk using $V_0$ | 14.64% |
| Min-risk using $\tilde V_0$ | **13.98%** |

Eigen-adjustment cuts OOS volatility by about **4.5%** relative to the sample covariance.

**Min-risk, $\alpha_P=1$ books** (100 random alphas): for every portfolio, realized vol with $\tilde V_0$ is lower. Mean realized-volatility ratio $\tilde\sigma^R/\sigma^R=\mathbf{0.936}$ ⇒ **6.4%** risk reduction; with fixed alpha this is nearly a **7%** Information Ratio lift (Figure 5).

---

## 9. $N/T$ Dependence (Table 1)

Holding $N=50$, vary estimation length $T\in\{60,100,200,500\}$ for $\alpha_P=1$ optimized books:

- Eigen-adjusted books have **lower realized vol at every $T$**.  
- The gap **widens** as $T$ shrinks: at $T=500$ difference is only ~6 bps; at $T=60$, $V_0$ realized vols are **more than double** those from $\tilde V_0$.  
- Bias statistics under $\tilde V_0$ stay near 1; under $V_0$ they explode as $T$ falls, consistent with (1) but **worse** than (1) predicts (e.g. $T=100$: formula says $B=2.0$, data show $B=2.25$).

Practical implication: eigen-adjustment is most valuable precisely when risk models are most under-determined—short windows, large $N$, or any setting where $N/T$ is not tiny.

---

## 10. Technical Appendices (Implementation Notes)

**Appendix A.** Full-rank sample covariance requires $T>N$. Simulation: $f_m=U_0 b_m$ with row $k$ of $b_m$ drawn $N(0,D_0(k))$; estimate $V_m$; compare $D_m(k)$ to true eigenfactor variances $\tilde D_m=U_m'V_0 U_m$ (generally non-diagonal because $U_m$ is not the true eigenbasis). The paper adjusts **variances only**; adjusting eigenfactor **directions** did not help in their experiments.

**Appendix B.** Closed forms (Grinold–Kahn):

$$h_C=\frac{V^{-1}e}{e'V^{-1}e},\qquad h_A=\frac{V^{-1}\alpha}{\alpha'V^{-1}\alpha}.$$

---

## 11. Limitations

1. **Universe:** 50 large U.S. names with complete histories—survivorship and size bias; results may differ for small-cap or global universes with missing data.  
2. **Simulation assumptions:** normality/stationarity; residual bias is patched by the ad hoc $a=1.4$ scale rather than a fully nonparametric correction.  
3. **Market factor embedding:** relative returns plus $n=0$ market row; eigenfactor $k=0$ is near-colinear when weights are stable—not investable in the usual sense.  
4. **No expected-return side:** paper addresses covariance estimation bias under optimization, not Michaud’s expected-return error maximization.  
5. **Daily rebalance / no t-costs:** OOS vol gains ignore turnover and market impact.  
6. **Single-factor style risk model:** not a full fundamental Barra-style model; eigen-adjustment is a general covariance post-processor that could in principle sit on top of other estimators, but that is not demonstrated here.

---

## 12. Takeaways for Quant Implementation

1. **Diagnose eigenfactors, not just stocks.** If stock and random-portfolio bias stats look fine but optimized books are under-risked, check the eigenvalue spectrum.  
2. **De-bias the diagonal in the eigenbasis, rotate back**—a practical alternative (or complement) to Ledoit–Wolf shrinkage, shortsale constraints, or Muller’s flat 20% scale.  
3. **Use $a\approx 1.4$ as a starting empirical amplifier** of simulated biases when returns are fat-tailed and non-stationary.  
4. **The payoff is largest when $N/T$ is large**—exactly the regime of concentrated estimation windows and broad universes.  
5. **Accept small stock-level bias trade-offs** (low-vol slightly over-scaled, high-vol slightly under-scaled); portfolio-level forecasts are what matter, and those are restored to $B\approx 1$.  
6. **Expect ~5–7% OOS vol reduction** for min-variance / fixed-alpha optimized books in settings like the paper’s large-cap daily sample—material for IR even before alpha improvement.

---

## 13. Relation to Adjacent Literature

- Michaud (1989): error maximization → this paper isolates the **eigenvalue** channel of covariance error.  
- Muller (1993): flat volatility scale → eigen-adjustment is **spectrum-specific**.  
- Shepard (2009): analytic $N/T$ bias → empirical biases exceed the Gaussian formula; eigen-adjustment removes them without needing the closed form.  
- Ledoit–Wolf / DeMiguel–Garlappi–Nogales–Uppal norm constraints: shrink moments or weights; Menchero et al. shrink (scale) **eigenvariances**. Complementary rather than competing.

---

## 14. Equations Quick Reference

| Eq | Content |
|----|---------|
| (1) | Shepard bias $\sigma_{\mathrm{True}}=\sigma_{\mathrm{Pred}}/(1-N/T)$ |
| (2)–(3) | Relative returns; sample covariance |
| (4)–(5) | Standardized returns; bias statistic $B$ |
| (7) | Eigenfactor returns |
| (10)–(11), (A7)–(A10) | Simulated bias, empirical $\gamma$, $\tilde V_0$ |
| (B1)–(B2) | Min-risk fully invested and $\alpha_P=1$ holdings |

---

## 15. Bottom Line

Sample covariances forecast risk well for stocks and random portfolios but **systematically understate risk along low-eigenvalue directions**. Optimizers load on those directions, producing the classic optimized-portfolio risk underestimate ($B\approx 1.45$ for $N=50$, $T=200$). Monte Carlo estimation of eigenfactor volatility biases, amplified by $a=1.4$ for real-data fat tails, yields an eigen-adjusted covariance $\tilde V_0$ that restores unbiased risk forecasts for optimized books and reduces their out-of-sample volatility by roughly 4.5–6.4% in the authors’ large-cap daily sample—with much larger gains when $T$ is short.


---

## 16. Worked Numerical Context for Shepard’s Formula vs Reality

Equation (1) is a useful benchmark. For the paper’s baseline $N=50$, $T=200$:

$$1-\frac{N}{T}=1-0.25=0.75,\qquad \frac{1}{0.75}=1.\overline{3}.$$

So Gaussian theory says optimized predicted vol should be scaled by $\approx 1.33$. Empirically average $B\approx 1.45$. Relative excess of empirical over theory: $1.45/1.33-1\approx 9\%$. That residual is exactly what the simulation-plus-$a=1.4$ pipeline is designed to absorb. For $T=100$:

$$\frac{1}{1-0.5}=2.0\quad\text{(theory)},\qquad B_{\mathrm{emp}}\approx 2.25\quad\text{(Table 1)}.$$

Again empirics sit ~12.5% above the closed form. Flat Muller-style +20% would under-correct at short $T$ and over-correct at long $T$; eigen-adjustment adapts to the spectrum and to $T$.

---

## 17. Why Small Eigenfactors Are Under-Risked

Sampling noise in a Wishart-like setting compresses the eigenvalue spectrum: estimated small eigenvalues are too small, estimated large eigenvalues are too large (a classical random-matrix / Marchenko–Pastur effect, though the paper does not invoke RMT terminology). The optimizer’s solution $h\propto V^{-1}\alpha$ (or $V^{-1}e$) places large absolute weights where eigenvalues are small. Hence:

1. In-sample, those directions look cheap.  
2. Out-of-sample, true variance along those directions is larger than $D_0(k)$ suggests.  
3. Realized portfolio variance exceeds predicted variance → $B>1$.

De-biasing replaces $D_0(k)$ with $\gamma(k)^2 D_0(k)$ for small $k$ with $\gamma>1$, which raises predicted risk exactly where the optimizer wants to concentrate, pushing the optimizer to diversify more and restoring $B\approx 1$.

---

## 18. Simulation Protocol in Implementable Steps

For each day $t$ in the testing window:

1. Form $V_0$ from the trailing $T$ days of $f_{nt}$.  
2. Eigendecompose: $D_0=U_0'V_0U_0$.  
3. For $m=1,\ldots,M$:  
   - Draw $b_m$ with independent rows $N(0,D_0(k))$.  
   - Set $f_m=U_0 b_m$.  
   - Estimate $V_m=f_m f_m'/(T-1)$, decompose $D_m=U_m'V_m U_m$.  
   - True variance of simulated eigenfactors under $V_0$: $\tilde D_m=U_m'V_0 U_m$.  
   - Record $\sqrt{\tilde D_m(k)/D_m(k)}$.  
4. Average over $m$ to get $\lambda_t(k)$; average over $t$ to get $\lambda(k)$.  
5. Form $\gamma(k)=1.4(\lambda(k)-1)+1$.  
6. $\tilde V_0=U_0\,\mathrm{diag}(\gamma^2\circ\mathrm{diag}(D_0))\,U_0'$.

The paper finds $\lambda_t(k)$ almost constant in $t$ (Figure 2 percentile bands), so one could in practice compute $\lambda(k)$ once on a long panel and freeze it, refreshing periodically—though the published procedure re-estimates daily.

---

## 19. Connection Between Eigenfactor Bias Removal and Optimized Bias Removal

Figure 3 is the paper’s central empirical claim: once eigenfactor $B(k)$ is flattened to ~1, optimized-portfolio $B$ also falls to ~1 and becomes indistinguishable from random-portfolio $B$. That identifies eigenfactors as **sufficient statistics** for the optimization bias in this setting. You do not need a separate “optimizer bias” correction on top; fixing the spectrum fixes the optimized books.

---

## 20. Information Ratio Arithmetic

For $\alpha_P=1$ portfolios, predicted and realized alpha are the same by construction of the constraint; IR scales as $1/\sigma$. A mean realized-vol ratio of 0.936 implies

$$\frac{\mathrm{IR}_{\tilde V}}{\mathrm{IR}_{V}}=\frac{1}{0.936}\approx 1.068,$$

i.e. ~6.8% IR improvement from risk reduction alone. Combined with the min-risk fully invested vol drop 14.64%→13.98% (relative −4.5%), the left edge of the frontier moves left—raising attainable Sharpe for any mean-variance investor who trusts the covariance more than the mean.

---

## 21. Interaction with Missing Data and Factor Models

The authors intentionally exclude incomplete histories. In production risk models, missing data, EM covariance completion, or factor residualization change the eigenstructure. Eigen-adjustment remains well-defined on whatever full-rank $V_0$ the risk system produces (factor-model covariance, statistical PCA, hybrid). The simulation step only requires the ability to draw returns from $V_0$ and re-estimate with the **same** estimator. If the production estimator is a factor model rather than a raw sample covariance, one should simulate through that same factor estimator—not through a raw sample—so that $\lambda(k)$ reflects the actual bias of the deployed pipeline.

---

## 22. Stability Across Market Regimes

Figure 2’s tight percentile bands (smallest eigenfactor $\lambda\in[1.4,1.6]$ for 98% of days over 1994–2010) span the late-1990s bubble, the 2000–02 drawdown, the mid-2000s calm, and the 2008–09 crisis. That stability is encouraging for a slowly varying $\gamma(k)$. Still, a risk manager might floor $\gamma(k)$ or widen $a$ in crisis if empirical $B$ for optimized books drifts above 1 under the fixed $a=1.4$ choice.

---

## 23. What the Paper Does Not Claim

- It does not claim eigen-adjustment dominates Ledoit–Wolf, shortsale constraints, or norm constraints on weights (DeMiguel et al. 2009)—those act on different objects.  
- It does not provide a Bayesian or decision-theoretic derivation of $a=1.4$.  
- It does not optimize $a$ by cross-validation on OOS portfolio vol (an obvious extension).  
- It does not study expected-return estimation or Black–Litterman overlays.

---

## 24. Practical Checklist for a Desk Implementing Eigen-Adjustment

1. Confirm $T>N$ (or regularize before eigendecomposition).  
2. Build relative returns vs estimation-universe market.  
3. Run the simulation bias pipeline; plot $\lambda(k)$ vs $k$ and verify the hockey-stick shape (high at low $k$, slight dip below 1 at high $k$).  
4. Set $a$ so that post-adjustment eigenfactor $B(k)\approx 1$ on a holdout; start at 1.4.  
5. Publish both $V_0$ and $\tilde V_0$ risk reports for optimized candidate books; expect $\tilde V_0$ predicted vols higher for aggressive optimizers.  
6. Monitor live $B$ for production optimized portfolios monthly; if $B$ drifts, retune $a$ or refresh $\lambda(k)$.  
7. Keep stock-level vol forecasts optional: for single-stock vol, raw $V_0$ diagonals may be preferable given the mild induced bias in Figure 3a.

---

## 25. Extended Discussion of Figure Evidence

**Figure 1** is the smoking gun quartet: stocks OK, random OK, eigenfactors badly biased (monotonic in $k$), optimized uniformly biased ~1.45.  
**Figure 2** validates that a Gaussian simulator recovers the shape and approximate level of the bias, with narrow time bands.  
**Figure 3** shows the after picture: stock-level mild tilt by vol, random OK, eigenfactors flat, optimized flat.  
**Figure 4** (Chevron vs Citigroup projections) mechanistically explains the stock-level tilt.  
**Figure 5** histogram of OOS vol ratios all below 1—every one of 100 optimized books improves.

Together these figures make the paper unusually actionable for a Research Insight: the diagnostic, the fix, and the OOS payoff are all visual.

---

## 26. Summary Verdict

Eigen-adjusted covariance matrices attack Markowitz risk underestimation at its spectral source. For quantitative managers running optimized equity books off sample or lightly structured covariances, the method is a low-complexity, high-interpretability post-processor: simulate, scale eigenvariances with $a\approx 1.4$, rotate back, and expect materially better risk forecasts and modestly lower OOS volatility—especially when $N/T$ is not small.


---

## 27. Mathematical Detail: Bias Statistic Sampling Variability

Under i.i.d. $N(0,1)$ standardized returns, $(\tau-1)B^2\sim\chi^2_{\tau-1}$, so

$$\mathrm{Var}(B^2)=\frac{2}{\tau-1},\qquad \mathrm{sd}(B)\approx\frac{1}{\sqrt{2(\tau-1)}}$$

for $B$ near 1. With $\tau=4103$, $\mathrm{sd}(B)\approx 0.011$. The 95% normal CI $1\pm 2/\sqrt{\tau}\approx 1\pm 0.031$ cited in the text is in the same ballpark. Empirically, because returns are fat-tailed and $\sigma_t$ is estimated, dispersion of $B$ across stocks/portfolios in Figure 1a–b is wider than this ideal—but still clustered near 1, whereas eigenfactor and optimized $B$ sit many standard errors away from 1. That gap is what justifies calling the latter biases “systematic.”

---

## 28. Cap-Weight Drift and the Near-Zero Eigenfactor

Footnote 1 notes that if stock weights were constant over the estimation window, the smallest eigenfactor would have **exact** zero variance: the identity that $\sum_n w_n^{\mathrm{cap}} f_{nt}=0$ every day. Time-varying caps make this only approximate, so $k=0$ is a near-null direction reflecting the relative-return construction rather than an investable long–short. Risk systems implementing eigen-adjustment should either (i) drop the exact null if using a strictly relative universe without an $n=0$ market row, or (ii) keep the market row and treat $k=0$ carefully when interpreting “smallest eigenfactor” bias (the investable spectrum starts at $k=1$).

---

## 29. Comparison with Analytic Random-Matrix Corrections

Random-matrix theory (e.g. Laloux–Cize–Bouchaud–Potters) also rescales eigenvalues of sample covariances, typically replacing the noisy bulk with a Marchenko–Pastur fit while keeping outlier eigenvalues. Menchero–Wang–Orr differ in objective and method:

| | RMT bulk cleaning | Eigen-adjustment (this paper) |
|--|-------------------|-------------------------------|
| Target | Denoise covariance for PCA/risk | Unbias risk forecasts **under optimization** |
| Tool | Asymptotic spectral law | Finite-sample Monte Carlo through the **same** estimator |
| Output | Often shrink bulk eigenvalues toward MP fit | Multiply each empirical eigenvalue by $\gamma(k)^2$ from simulation |
| Validation | Often Frobenius / PCA stability | Bias statistic $B$ on optimized portfolios + OOS vol |

Both raise small eigenvalues relative to naive sample estimates. Eigen-adjustment is more tightly coupled to the **optimization** use case and to the empirical $B$ diagnostic.

---

## 30. Daily Rebalancing and Autocorrelation of Bias

Because $V_0$ rolls daily by one observation, adjacent days’ $\tilde V_0$ are highly correlated. Optimized holdings $h_A$ therefore trade slowly when alphas are fixed, but the paper’s random alphas are redrawn conceptually as cross-sectional probes rather than as a live alpha stream. For a live strategy with persistent alpha, turnover induced by eigen-adjustment alone should be modest (covariance changes slowly); most turnover still comes from alpha and from the $T$-day roll.

---

## 31. Annualization and Reporting Conventions

Reported vols (19.84%, 14.64%, 13.98%) are annualized from daily returns in the usual $\sqrt{252}$ sense (standard for such Research Insights). Bias statistics are unitless and invariant to annualization. When comparing to Shepard’s formula, ensure $N$ and $T$ count the same assets/observations used in $V_0$ (here 51 including market row ≈ 50 stocks).

---

## 32. Stress: What if Alphas Correlate with Eigenvectors?

The paper’s alphas are random and cap-mean-zero, hence roughly orthogonal to structured biases. If a real alpha signal loads systematically on small eigenfactors (e.g. a mean-reversion signal that is itself an approximate min-variance direction), eigen-adjustment will **increase** predicted risk of that signal and shrink active weights—acting like a Tikhonov regularizer on $V^{-1}$. That is desirable if the loading was spurious; it may reduce IR if the loading was genuine. Monitoring the projection of production alpha onto the smallest 5–10 eigenfactors is a useful companion diagnostic.

---

## 33. Replication Sketch (Minimal)

Given a $T\times N$ return matrix and a market series:

```text
V0 = cov(f)                         # relative returns
U, d = eigh(V0)                     # ascending eigenvalues
for m in 1..M:
    b = randn(N, T) * sqrt(d)[:,None]
    fm = U @ b
    Vm = cov(fm.T)
    Um, dm = eigh(Vm)
    true_var = diag(Um.T @ V0 @ Um)
    ratios[m] = sqrt(true_var / dm)
lambda = mean(ratios, axis=0)
gamma = 1.4*(lambda-1)+1
V_tilde = U @ diag((gamma*sqrt(d))**2) @ U.T
```

Then optimize $h\propto V_tilde^{-1}\alpha$ and compare realized vs predicted vol.

---

## 34. Closing Synthesis

The contribution is diagnostic clarity plus a fix: **optimized risk underestimation is eigenfactor risk underestimation**. Correct the spectrum with estimator-matched simulation, amplify mildly for fat tails ($a=1.4$), and both risk forecasts and OOS optimized vols improve. For MSCI-style equity risk research and for any desk still feeding sample or lightly structured covariances into an optimizer, eigen-adjustment is a concrete, reproducible upgrade over flat volatility pads.


---

## 35. Final Practitioner Notes

Eigen-adjustment complements, rather than replaces, liquidity constraints, turnover penalties, and alpha covariance shrinkage. In a full production stack one might: (i) build a factor covariance; (ii) eigen-adjust the factor block and/or the specific-risk diagonal in a manner analogous to Appendix A; (iii) optimize with t-cost aware objectives. The paper’s pure sample-covariance laboratory isolates the spectral effect cleanly—useful pedagogy and a lower bound on how much optimization bias a spectral fix can remove when $N/T$ is nontrivial.
