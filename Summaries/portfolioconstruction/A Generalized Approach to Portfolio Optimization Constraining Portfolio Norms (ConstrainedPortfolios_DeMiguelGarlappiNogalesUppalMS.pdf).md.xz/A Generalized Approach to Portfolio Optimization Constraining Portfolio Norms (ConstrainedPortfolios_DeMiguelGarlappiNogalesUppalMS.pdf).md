# A Generalized Approach to Portfolio Optimization: Improving Performance by Constraining Portfolio Norms

**Authors:** Victor DeMiguel (London Business School); Lorenzo Garlappi (McCombs, UT Austin); Francisco J. Nogales (Universidad Carlos III de Madrid); Raman Uppal (London Business School)  
**Publication:** *Management Science* 55(5), May 2009, pp. 798–812  
**DOI:** 10.1287/mnsc.1080.0986  
**Keywords:** Portfolio choice; covariance estimation; estimation error; shrinkage; norm constraints; lasso / ridge  
**Data:** Five monthly datasets (Table 1): 10Ind, 48Ind, 6FF, 25FF (all Jul 1963–Dec 2004, Ken French); 500CRSP randomized 500-stock panels Apr 1968–Apr 2005  
**Source PDF:** `ConstrainedPortfolios_DeMiguelGarlappiNogalesUppalMS.pdf`  
**Summary prepared:** 2026-09-26 (Scholar batch_2026-09-26_3)  
**OCR:** Not required; clean extract (~12,191 words of source)

---

## 1. Problem and Motivation

Markowitz mean–variance portfolios estimated from sample means and covariances perform poorly out of sample (Frost–Savarino; Michaud; Best–Grauer; Chopra–Ziemba; Broadie; Litterman). Means are harder to estimate than covariances (Merton 1980), and mean errors dominate weight errors—so a large literature focuses on **global minimum-variance** portfolios that use only covariances. Even then, sample covariances are noisy when $N$ is large relative to $T$.

Prior remedies include: higher-frequency returns; factor-structured covariances (Chan–Karceski–Lakonishok; Green–Hollifield); Ledoit–Wolf shrinkage of the covariance toward identity or a 1-factor target; shortsale constraints (Frost–Savarino; Chopra), which Jagannathan–Ma (2003) show are equivalent to shrinking extreme covariances; and, at the extreme, the naive $1/N$ rule (DeMiguel–Garlappi–Uppal 2009), which can beat optimized rules on Sharpe, CEQ, and turnover.

This paper’s contribution is a **unifying norm-constraint framework**: solve the usual minimum-variance problem on the sample covariance but add $\|w\|\le\delta$. Special cases recover Jagannathan–Ma shortsale constraints, Ledoit–Wolf portfolios, and $1/N$. New cases include soft shortsale budgets ($\|w\|_1\le\delta$ with $\delta>1$), general $A$-norm constraints, and **partial minimum-variance** portfolios from conjugate gradients. The authors give Bayesian (prior on weights) and moment-shrinkage interpretations, then run a large OOS horse race.

---

## 2. Datasets (Table 1)

| # | Dataset | Abb. | $N$ | Period | Source |
|---|---------|------|----:|--------|--------|
| 1 | 10 industry portfolios | 10Ind | 10 | 07/1963–12/2004 | Ken French |
| 2 | 48 industry portfolios | 48Ind | 48 | 07/1963–12/2004 | Ken French |
| 3 | 6 FF size×BM | 6FF | 6 | 07/1963–12/2004 | Ken French |
| 4 | 25 FF size×BM | 25FF | 25 | 07/1963–12/2004 | Ken French |
| 5 | 500 random CRSP stocks | 500CRSP | 500 | 04/1968–04/2005 | CRSP |

500CRSP: each April, randomly select 500 names with 120 months of past and 12 months of future returns; hold that universe 12 months (Jagannathan–Ma style).

Estimation window $\tau=120$ months (10 years); rolling one month. Results similar for $\tau=60$ or $240$ (not tabulated).

---

## 3. Baseline Minimum-Variance Problem

$$
\min_w\, w'\hat\Sigma w \quad\text{s.t.}\quad w'e=1. \tag{1–2}
$$

Solution $w_{\mathrm{MINU}}$. Shortsale-constrained MINC adds $w\ge 0$. Jagannathan–Ma show MINC equals MINU on the shrunk covariance

$$\hat\Sigma_{\mathrm{JM}}=\hat\Sigma-\lambda e'-e\lambda', \tag{3}$$

with $\lambda\ge 0$ the shortsale multipliers—i.e. covariances of shorted names are reduced.

Ledoit–Wolf replace $\hat\Sigma$ by

$$\hat\Sigma_{\mathrm{LW}}=\frac{1}{1+\nu}\hat\Sigma+\frac{\nu}{1+\nu}\hat\Sigma_{\mathrm{target}}, \tag{4}$$

with $\nu$ chosen to minimize expected Frobenius error; targets include identity (LWID) and 1-factor (LW1F).

---

## 4. Norm-Constrained Minimum Variance

Add $\|w\|\le\delta$. If $\delta\ge\|w_{\mathrm{MINU}}\|$, the constraint is slack. If $\delta<\|w_{\mathrm{MINU}}\|$, weights are **shrunk in norm** toward the minimum-norm fully invested portfolio (the target in the James–Stein sense for weights).

### 4.1 1-Norm (NC1) — Soft Shortsale Budgets

$$\|w\|_1=\sum_i|w_i|\le\delta.$$

**Proposition 1.** For $\delta=1$, NC1 coincides with shortsale-constrained MINC (Jagannathan–Ma).

For $\delta>1$, rewrite

$$-\sum_{i\in\mathcal{N}(w)}w_i\le\frac{\delta-1}{2}, \tag{5}$$

where $\mathcal{N}(w)=\{i:w_i<0\}$. The left side is total short interest; $(\delta-1)/2$ is a **shortsale budget** freely allocatable across names—exactly the spirit of 130/30 mandates (long 130%, short 30% ⇒ $\|w\|_1=1.6$). This class was not previously studied academically in this form.

### 4.2 $A$-Norm (including 2-Norm and Factor Norm)

Impose $w'Aw\le\omega$ (equivalent squared $A$-norm).

**Proposition 2.** For each Ledoit–Wolf $\nu\ge 0$ there is $\omega$ such that LW with target $A$ equals $A$-norm-constrained min-variance on the sample $\hat\Sigma$.

- $A=I$ ↔ Ledoit–Wolf (2004) toward identity ↔ **2-norm** constraint $\|w\|_2^2\le\omega$.  
- $A=\hat\Sigma_F$ (1-factor cov) ↔ Ledoit–Wolf (2003).

Reformulation of the 2-norm constraint:

$$\sum_i\Bigl(w_i-\frac{1}{N}\Bigr)^2\le\omega-\frac{1}{N}. \tag{7}$$

So 2-norm constraint = ball around $1/N$. Setting $\omega=1/N$ recovers exactly $w=1/N$.

**Implications for sparsity:** 1-norm (lasso) encourages zeros and concentrated long books with a short budget; 2-norm (ridge) keeps weights near $1/N$ and typically strictly positive; $\hat\Sigma_F$-norm keeps weights near the 1-factor min-var portfolio.

### 4.3 Partial Minimum-Variance (PAR)

Apply conjugate gradients starting at $1/N$; the path of $N-1$ intermediate portfolios ends at MINU. Each intermediate portfolio is a **partial minimum-variance** portfolio (order $k$).

**Proposition 3.** The 2-norm of the $k$th partial min-var portfolio is $\le$ that of MINU for $k\le N-1$. Online appendix: PAR is a discrete first-order approximation to 2-norm-constrained portfolios (chemometrics “partial least squares” analogue).

---

## 5. Bayesian Interpretation (Priors on Weights, Not Moments)

Classical Bayesian portfolio choice (Jorion) puts priors on means/covariances and maximizes expected utility under the return posterior. Here the prior is on **min-var weights**.

**Proposition 4 (1-norm).** Under normal returns and i.i.d. Double-Exponential prior on weights $p(w_i)\propto e^{-\eta|w_i|}$, plus independent prior on portfolio variance $\sigma^2$, the NC1 solution is the **mode** of the posterior of min-var weights (lasso / Tibshirani Bayesian story).

**Proposition 5 ($A$-norm).** Under a $N(0,A^{-1})$-type prior density $p(w)\propto |A|^{1/2}\exp(-\tfrac12 w'Aw)$, the $A$-norm-constrained solution is the posterior mode (ridge story).

Investor statement: “I believe the min-var weights look like draws from this prior,” then pick the mode given data—not “I believe means are shrunk toward the grand mean.”

---

## 6. Moment-Shrinkage Duality

**Proposition 6.** If NC1 solution has no exact zeros, it equals unconstrained min-var on

$$\hat\Sigma_{\mathrm{NC1}}=\hat\Sigma-\zeta n e'-e\zeta n', \tag{10}$$

where $n_i=1$ if $w_i<0$ else 0, and $\zeta$ is the single 1-norm multiplier. Versus Jagannathan–Ma (3), which applies **asset-specific** $\lambda_i$, NC1 applies a **common** shrinkage $\zeta$ to all shorted names’ covariances.

$A$-norm constraints equivalently shrink all of $\hat\Sigma$ toward $A$ (Prop. 2).

---

## 7. Portfolio Menu Evaluated (Table 2)

**New (Panel A):** NC1V, NC1R, NC2V, NC2R, NCFV, NCFR, PARV, PARR.  
Suffix **V** = calibrate $\delta$ (or $k$) by leave-one-out cross-validation minimizing estimated portfolio variance.  
Suffix **R** = choose $\delta$/$k$ to maximize last-month portfolio return (exploits Campbell et al. finding that **portfolio** returns are positively autocorrelated even when individual securities are weakly negatively autocorrelated—via positive cross-autocovariances).

**Benchmarks (Panel B):** $1/N$, VW, MEAN ($\gamma=5$), BAYE (Jorion, $\gamma=5$), MINU, MINC, FAC1, LWID, LW1F, BSV3 (Brandt–Santa-Clara–Valkanov parametric with size, BM, momentum, $\gamma=5$).

---

## 8. Evaluation Metrics and Inference

Rolling $\tau=120$:

$$\hat\sigma_i^2=\frac{1}{T-\tau-1}\sum_{t=\tau}^{T-1}(w_{it}'r_{t+1}-\hat\mu_i)^2,\quad
\widehat{\mathrm{SR}}_i=\hat\mu_i/\hat\sigma_i,$$

$$\mathrm{Turnover}=\frac{1}{T-\tau-1}\sum_t\sum_j|w_{ij,t+1}-w_{ij,t^+}|.$$

Sharpe inference: Ledoit–Wolf (2008) studentized circular block bootstrap, $B=1000$, block size 5. Variance inference: Politis–Romano stationary bootstrap. Significance declared at 5%.

---

## 9. Out-of-Sample Variances (Table 3) — Key Patterns

Monthly OOS variances (selected):

| Strategy | 10Ind | 48Ind | 6FF | 25FF | CRSP |
|----------|------:|------:|----:|-----:|-----:|
| NC1V | 0.00134 | 0.00126 | 0.00156 | 0.00135 | 0.00074 |
| NC2V | 0.00134 | 0.00137 | 0.00156 | 0.00130 | 0.00066 |
| PARV | 0.00138 | 0.00141 | 0.00159 | 0.00133 | 0.00065 |
| $1/N$ | 0.00179 | 0.00221 | 0.00230 | 0.00249 | 0.00169 |
| MINU | 0.00138 | 0.00186 | 0.00156 | 0.00143 | 0.00104 |
| MINC | 0.00134 | 0.00133 | 0.00186 | 0.00176 | 0.00087 |
| LWID | 0.00131 | 0.00143 | 0.00155 | 0.00126 | 0.00065 |
| LW1F | 0.00135 | 0.00140 | 0.00158 | 0.00134 | 0.00052 |
| MEAN | 0.01090 | 0.38107 | 0.00353 | 0.00942 | 0.00626 |

Findings:

1. **V-calibrated** norm constraints (NC1V, NC2V, NCFV, PARV) have similar variances across datasets; **R-calibrated** are higher variance (as expected—they chase return).  
2. Norm-constrained V portfolios beat $1/N$, VW, and MEAN on variance with statistical significance almost everywhere.  
3. They beat MINU often (e.g. PARV vs MINU significant on 48Ind and CRSP).  
4. NC1V generally beats nested MINC on 6FF, 25FF, CRSP (soft short budget helps).  
5. Versus LWID/LW1F: variances are **similar**—sometimes LW wins on a given dataset (e.g. LWID vs NC2V on 10Ind), sometimes NCFV beats LW1F (48Ind). Norm constraints are competitive with, not uniformly dominant over, covariance shrinkage.

---

## 10. Out-of-Sample Sharpe Ratios (Table 4)

Selected monthly Sharpes:

| Strategy | 10Ind | 48Ind | 6FF | 25FF | CRSP |
|----------|------:|------:|----:|-----:|-----:|
| NC1V | 0.285 | 0.289 | 0.339 | 0.365 | 0.401 |
| NC2V | 0.292 | 0.286 | 0.353 | 0.409 | 0.399 |
| PARR | 0.329 | 0.317 | 0.391 | 0.440 | 0.477 |
| $1/N$ | 0.254 | 0.251 | 0.256 | 0.257 | 0.333 |
| MINC | 0.285 | 0.291 | 0.263 | 0.272 | 0.399 |
| LWID | 0.296 | 0.262 | 0.323 | 0.397 | 0.409 |
| LW1F | 0.290 | 0.254 | 0.330 | 0.393 | 0.450 |
| BSV3 | 0.116 | 0.331 | 0.391 | 0.405 | 0.267 |

Headline results:

- **PARR** (partial min-var, return-calibrated) almost always posts the highest Sharpe among the authors’ strategies; p-values in Table 4 are vs PARR.  
- Norm-constrained portfolios beat $1/N$ and VW on Sharpe on all datasets, often significantly.  
- PARR / NC1R beat MINC and often beat LWID/LW1F on Sharpe—**even when variances were similar**—i.e. the return-calibration channel adds mean, not just variance reduction.  
- Cost: higher Sharpe of R-calibrated rules comes with **higher turnover** (Table 5).  
- BSV3 is a strong but not nested competitor (uses firm characteristics); PARR matches or beats it on several datasets without characteristics.

---

## 11. Turnover (Table 5) and the Variance–Sharpe–Turnover Trilemma

V-calibrated norm portfolios have moderate turnover—higher than $1/N$ and VW, often comparable to LW, lower than MEAN/MINU in high-$N$ settings. R-calibrated and especially PARR turn over more because $\delta$/$k$ jumps when last month’s winning configuration changes. A t-cost-aware user should prefer **V** calibration unless the Sharpe gain clears the cost hurdle; the paper flags this tradeoff explicitly without claiming net-of-cost dominance for R rules.

---

## 12. Statistical / Chemometrics Genealogy

Unconstrained min-var weights are OLS coefficients of a particular regression (Britten-Jones 1999). Therefore:

| Constraint | Regression analogue |
|------------|---------------------|
| $\|w\|_1\le\delta$ | lasso (Tibshirani 1996) |
| $\|w\|_2\le\delta$ | ridge (Hoerl–Kennard 1970) |
| Partial min-var path | partial least squares (Wold; Frank–Friedman) |

This taxonomy clarifies why 1-norm sparsifies and 2-norm densifies, and why PAR sits between $1/N$ and MINU on a path of increasing fit / decreasing regularization.

---

## 13. Calibration Details Worth Implementing Carefully

**Cross-validation (V):** for each candidate $\delta$ (or $k$), for each $t=1,\ldots,\tau$: drop month $t$, form $\hat\Sigma^{(-t)}$, solve norm-constrained min-var, record $w'r_t$; choose $\delta^*$ minimizing the variance of these pseudo-OOS returns.

**Return calibration (R):** $\delta^*=\arg\max_\delta w_\delta'r_{\tau}$ using the last month in the window only (authors report 2–6 month averages worked worse—autocorrelation is most local).

Grid $\delta$ from $\|w_{\mathrm{MINU}}\|$ down toward the min-norm portfolio; for PAR, $k=1,\ldots,N-1$.

---

## 14. Limitations

1. **No t-costs in the objective**—Sharpe gains for R rules may not survive realistic costs.  
2. **Long-only industry/FF datasets** already limit shorting; the soft shortsale budget shines more on 500CRSP.  
3. **Min-var focus**—framework extends to mean–variance but empirics do not stress alpha-rich settings.  
4. **BSV3 not apples-to-apples**—uses characteristics; included as a high-Sharpe benchmark only.  
5. **Single 1-factor model**—Chan et al. suggest multi-factor cov estimators add little vs 1-factor for this purpose.  
6. **Parameter uncertainty of $\delta$**—CV is noisy; no empirical Bayes hierarchy on $\delta$.

---

## 15. Takeaways for Quant Implementation

1. **Think of regularization as a constraint on $\|w\|$,** not only as a covariance tweak—same portfolios, clearer knobs (short budget, distance to $1/N$).  
2. **NC1 with $\delta\in(1,1.6]$** is the academic formalization of 130/30-style short budgets; start there before hard long-only.  
3. **NC2 / PAR** are the right tools when the prior is “near equal weight.”  
4. **Calibrate $\delta$ by CV on variance** for risk-focused mandates; use R calibration only if you believe short-horizon portfolio autocorrelation and can afford turnover.  
5. **Expect variance ≈ Ledoit–Wolf, Sharpe ≥ shortsale-constrained / $1/N$** in the paper’s horse race—norm constraints are a first-class citizen next to covariance shrinkage.  
6. **Monitor turnover** as a first-class metric alongside Sharpe; the paper’s wins are gross of costs.

---

## 16. Relation to Companion Papers

- DeMiguel–Garlappi–Uppal (RFS 2009): $1/N$ horse race → here $1/N$ is the $\omega=1/N$ corner of NC2.  
- Jagannathan–Ma (JF 2003): shortsale constraints as covariance shrinkage → nested as NC1 with $\delta=1$.  
- Ledoit–Wolf (2003, 2004): covariance shrinkage → dual to $A$-norm constraints (Prop. 2).  
- Brandt–Santa-Clara–Valkanov: parametric portfolios → different information set; similar Sharpe/turnover ballpark without characteristics.

---

## 17. Equations Quick Reference

| Eq | Content |
|----|---------|
| (1)–(2) | Min-var with weights summing to 1 |
| (3) | JM shrunk covariance from shortsale multipliers |
| (4) | LW convex combination with target |
| (5) | Shortsale-budget form of $\|w\|_1\le\delta$ |
| (6)–(7) | $A$-norm / 2-norm ball around $1/N$ |
| (8)–(9) | Double-Exponential / Normal priors on weights |
| (10) | NC1 dual covariance shrinkage |
| (11)–(13) | OOS variance, Sharpe, turnover |

---

## 18. Detailed Reading of Why Soft Shortsale Budgets Help

Hard $w\ge 0$ (MINC) zeros out any name the unconstrained solution wanted to short, discarding information in that name’s covariances except through the JM adjustment. Soft $\|w\|_1\le\delta$ with $\delta>1$ allows limited shorting of the most egregious overweights’ hedges—useful when $N$ is large (25FF, 500CRSP) and some negative weights are genuine hedges rather than pure estimation noise. Table 3’s significant variance wins of NC1V over MINC on 6FF/25FF/CRSP support that interpretation. On 10Ind ($N=10$), MINC and NC1V variances match (0.00134)—little room for soft shorts to help.

---

## 19. Why Return-Calibrated PARR Wins Sharpe

Conjugate-gradient partial solutions are nested subspace optima. Choosing $k$ to max last-month return picks the subspace dimension that recently worked—adaptive regularization strength. Combined with portfolio-level AR(1) in returns, this is a momentum-of-diversification effect: when a moderately regularized book worked last month, keep similar $k$. The paper’s own caveat is turnover; net-of-cost performance is left open.

---

## 20. Bottom Line

Constraining portfolio-weight norms is a single framework that nests shortsale constraints, Ledoit–Wolf shrinkage portfolios, and $1/N$, while delivering new soft-short and partial min-var rules. Empirically, variance-calibrated norm portfolios match Ledoit–Wolf on risk and beat $1/N$, VW, and hard shortsale constraints; return-calibrated partial min-var portfolios deliver the best Sharpes in the study at the cost of higher turnover. For implementation, the actionable knobs are the norm type (1 vs 2 vs factor), the threshold $\delta$ (or order $k$), and the calibration criterion (variance CV vs last-month return).


---

## 21. Cross-Dataset Robustness Narrative

Across $N=6$ to $N=500$ and industry vs characteristic-sorted vs random-stock universes, the qualitative ranking is stable: MEAN is disastrous on variance (0.38 monthly variance on 48Ind!); BAYE helps but still lags norm constraints on several sets; FAC1 is a weak min-var proxy when factors are coarse; LW and norm constraints form the efficient frontier of simple estimators. That stability across designs is the paper’s empirical strength relative to single-dataset studies.

---

## 22. Notes on Multiple Testing and Bootstrap Choice

Reporting p-values vs a single benchmark (PARV for variance, PARR for Sharpe) avoids a full pairwise matrix in print but the authors state they computed all pairs and use those in discussion. Block bootstraps with length 5 match monthly dependence at business-cycle-ish short range; fat-tail studentization (Ledoit–Wolf 2008) matters especially for MEAN/BAYE and 48Ind where outliers dominate.

---

## 23. Implementation Pseudocode (NC1 / NC2)

```text
for each month t:
  Sigma = sample_cov(returns[t-τ:t])
  for delta in grid:
    w[delta] = argmin w'Sigma w
                 s.t. sum(w)=1, norm(w)<=delta
  delta_star = CV_or_last_return_rule(w, returns)
  hold w[delta_star] for month t+1
```

Use QP/SOCP solvers: 2-norm and $A$-norm are convex quadratic constraints; 1-norm is LP-representable via $w=w^+-w^-$, $\sum(w^++w^-)\le\delta$.

---

## 24. Closing Synthesis

The paper reframes estimation-error-robust portfolio choice as **regularized weights**. By proving duality with the major covariance-shrinkage and shortsale literatures and by adding soft short budgets and partial min-var paths, it gives both a map of existing methods and new strategies that win on Sharpe in a careful OOS horse race—provided one respects the turnover cost of aggressive $\delta$ calibration.


---

## 25. Deeper Dive: 1-Norm vs 2-Norm Economic Motivation

Investors who think “I should not be more short than $X\%$ of NAV in aggregate, but I am agnostic about which names” should use $\|w\|_1$. Investors who think “my null is equal weight; any departure must be justified by covariance evidence” should use $\|w\|_2$. Investors who trust a market-factor model as the right null should use $\|\cdot\|_{\hat\Sigma_F}$. The paper’s empirical finding that all three V-calibrated variants deliver similar variances suggests that **having a binding norm constraint** matters more than which norm, for pure risk reduction—while Sharpe differences show up mainly when R-calibration injects a timing overlay.

---

## 26. Connection to 130/30 and Long–Short Mandates

A 130/30 book has $\sum w_i^+=1.3$, $\sum w_i^-=0.3$, hence $\|w\|_1=1.6$. NC1 with $\delta=1.6$ is exactly the min-var portfolio under that aggregate short budget without forcing which names are short. Relative to a hard 130/30 with fixed name lists, NC1 endogenously selects the shorts that most reduce variance per unit of short budget—attractive as a risk-model overlay on top of an alpha-driven 130/30 mandate (replace min-var objective with mean–variance using the alpha vector).

---

## 27. Partial Minimum-Variance Path Geometry

Conjugate gradients on $\min w'\hat\Sigma w$ s.t. $w'e=1$ generate $\hat\Sigma$-orthogonal search directions. The $k$th partial solution lives in a $k$-dimensional Krylov subspace seeded at $1/N$. Early $k$ ≈ heavily regularized (close to $1/N$); late $k$ ≈ MINU. PARV picks $k$ by CV variance; PARR picks $k$ by last-month return. Empirically PARR’s Sharpe leadership (Table 4) says that the data’s short-horizon portfolio autocorrelation aligns with intermediate $k$ more often than with either extreme—neither pure $1/N$ nor full MINU.

---

## 28. Why MEAN and BAYE Fail Here

MEAN uses sample means with $\gamma=5$; in 48Ind the OOS variance explodes to 0.38 because estimated means generate extreme long–short industry bets that do not persist. BAYE (Jorion) shrinks means toward the grand mean and cuts variance sharply (e.g. 0.068 on 48Ind) but still underperforms norm-constrained min-var on several Sharpes. The paper thus reaffirms Jagannathan–Ma’s dictum: if you lack strong mean priors, drop means and regularize min-var weights / covariances instead.

---

## 29. Brandt–Santa-Clara–Valkanov Comparison

BSV3 parameterizes weights as $w\propto 1/N + \theta'x_i$ with characteristics $x$ (size, BM, momentum). It needs security-level characteristics and a utility-based estimation criterion. On 48Ind and 6FF/25FF, BSV3 Sharpe (0.33–0.40) rivals PARR; on 10Ind and CRSP it lags. Norm-constrained rules need only returns, making them usable on industry portfolios and international universes lacking clean characteristics. The paper’s claim is not that PARR dominates BSV3 universally, but that similar Sharpe is achievable without $x_i$.

---

## 30. Finite-Sample CV Noise

With $\tau=120$ and $N=48$ or $500$, leave-one-out CV variances are noisy; $\delta^*$ can chatter month to month, contributing to turnover even for V rules. Practical stabilizations (not in the paper): (i) smooth $\delta_t=0.8\delta_{t-1}+0.2\delta^*_t$; (ii) pick $\delta$ on a coarse grid; (iii) re-estimate $\delta$ quarterly. These would likely cut turnover with small Sharpe cost.

---

## 31. Extension to Mean–Variance with Alpha

Replace (1) by $\min_w\, w'\hat\Sigma w-\lambda_{\mathrm{RA}}^{-1}\hat\mu'w$ or the usual mean–variance form, keeping $\|w\|\le\delta$. Propositions on nesting LW/JM need re-proof but the computational recipe is unchanged. When $\hat\mu$ is an alpha signal rather than sample means, NC1/NC2 become regularized active portfolios—directly comparable to Grinold–Kahn “alpha vs risk” with an extra norm penalty.

---

## 32. What “Higher Sharpe with Higher Turnover” Means Quantitatively

Suppose PARR Sharpe exceeds LWID by 0.05 monthly (roughly the 6FF gap 0.391 vs 0.323). Annualized, that is material. If extra two-way turnover is 50%/month beyond LWID and round-trip cost is 20 bps, monthly cost ≈ 0.10%, which can erase much of a 0.05 Sharpe advantage depending on volatility. Users must plug their own cost curves; the paper supplies the gross ingredients.

---

## 33. Bottom-Line Implementation Ranking (Gross of Costs)

For a returns-only min-var desk on industry or FF portfolios:

1. **PARR / NC2R / NC1R** if turnover is cheap and short-horizon portfolio AR is trusted.  
2. **NC1V / NC2V / PARV / LWID / LW1F** if the mandate is risk reduction with moderate turnover—these are roughly tied.  
3. **MINC** if the mandate forbids shorts and simplicity is paramount ($\delta=1$ NC1).  
4. Avoid **MEAN**; treat **BAYE** as a mean-side benchmark only.

That ranking is the operational distillation of Tables 3–5.


---

## 34. Historical Placement

Published 2009, the paper sits at the intersection of the “$1/N$ puzzle” literature and the covariance-shrinkage literature, offering a common language. Subsequent work on portfolio norms, elastic-net weights, and constrained risk budgeting largely follows this template: choose a penalty/constraint geometry that encodes the investor’s null portfolio, calibrate the strength on OOS criteria, and report variance, Sharpe, and turnover together.


---

## 35. Numerics Recap for Quick Reference

**Variances (monthly):** Norm V-rules ~0.0013–0.0016 on industry/FF; CRSP ~0.0005–0.0007; $1/N$ ~0.0017–0.0025; MEAN up to 0.38 on 48Ind.

**Sharpes (monthly):** PARR ~0.32–0.48; $1/N$ ~0.25–0.33; MINC ~0.26–0.40; LWID/LW1F ~0.25–0.45.

**Design:** $\tau=120$, five datasets, block bootstrap inference.

These magnitudes are the paper’s empirical deliverable for anyone re-implementing the horse race.


---

## 36. Reader’s Digest of Propositions

- **P1:** $\delta=1$ in NC1 ⟺ Jagannathan–Ma shortsale-constrained min-var.  
- **P2:** LW shrinkage toward $A$ ⟺ $A$-norm constraint on weights (duality).  
- **P3:** Partial min-var portfolios have 2-norm ≤ MINU.  
- **P4–P5:** NC1 / $A$-norm as posterior modes under DE / Normal weight priors.  
- **P6:** NC1 dual to common-shrinkage of shorted names’ covariances.

These six results are the theoretical spine; Tables 3–5 are the empirical spine.
