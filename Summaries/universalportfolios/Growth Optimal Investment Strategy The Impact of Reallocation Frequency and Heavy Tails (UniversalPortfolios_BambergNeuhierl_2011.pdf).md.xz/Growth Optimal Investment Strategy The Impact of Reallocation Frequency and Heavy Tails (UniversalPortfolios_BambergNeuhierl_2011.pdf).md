# Growth Optimal Investment Strategy: The Impact of Reallocation Frequency and Heavy Tails

**Authors:** G. Bamberg (Universität Augsburg, Institut für Statistik and Mathematische Wirtschaftstheorie); A. Neuhierl (Northwestern University – Kellogg School of Management)  
**Publication:** *German Economic Review* 13(2): 228–240 (2011)  
**Source PDF:** `UniversalPortfolios_BambergNeuhierl_2011.pdf` (Drive id `14P7qsUgcOYg5chN4CY-QTSBFh1agIVWE`)  
**Summary prepared:** 2026-09-26 (Scholar batch_2026-09-26_4)  
**Extraction:** `pdftotext -layout` OK (~5,221 words; journal pages 228–240). No OCR required.  
**Note on title:** An earlier candidate label suggested “Universal Portfolios with Side Information and Drawdown”; the actual title is **Growth Optimal Investment Strategy: The Impact of Reallocation Frequency and Heavy Tails**. The paper is about the Kelly / maximum expected log (MEL) criterion, not Cover-style universal portfolios with side information.

---

## 1. Problem and Contribution

The authors study the **maximum expected log (MEL)** strategy—also called the Kelly criterion, maximum geometric mean strategy, or growth-optimal portfolio—in a two-asset economy with one risky asset and one risk-free asset. Two questions that, they argue, the large MEL literature had not cleanly answered:

1. **Reallocation frequency / basic return period.** If the MEL portfolio must be rebalanced to keep the risky weight $a$ constant, does the *optimal* $a^*$ depend on the length of the return period (equivalently, on how often one rebalances)?  
2. **Heavy tails.** Relative to a light-tailed (e.g., normal) benchmark for log returns, how does fat-tailedness of the log-return distribution change $a^*$?

**Main qualitative answers:** (i) yes—the MEL weight depends on the period length; lengthening the buy-and-hold interval *can* (and in their leading example *does*) reduce optimal risk exposure, though the opposite can also occur in other designs; (ii) heavier lower tails generally produce **lower** $a^*$, but if the density is symmetric and the mean log return exceeds the risk-free log return, $a^*$ **cannot fall below $1/2$** no matter how heavy the tails.

JEL: G11, G12. Keywords: heavy tails; asymptotic optimality; portfolio management.

---

## 2. MEL Criterion: Setup and Asymptotic Optimality

Starting wealth $w_0$, period simple returns $R_1,\ldots,R_T$, no intermediate deposits/withdrawals:

$$
W_T = w_0\prod_{t=1}^{T}(1+R_t).
$$

With log returns $r_t=\ln(1+R_t)$,

$$
W_T = w_0\exp\Big(\sum_{t=1}^{T} r_t\Big).
$$

If $\{r_t\}$ are i.i.d. with finite mean $\ell=\mathbb{E}r_t$, the WLLN gives $\frac{1}{T}\sum r_t\to\ell$, hence

$$
W_T \approx w_0 e^{\ell T}\qquad\text{for large }T.
$$

This is a pathwise growth statement, **not** a statement about $\mathbb{E}W_T$. By Jensen, $\mathbb{E}W_T > w_0 e^{\ell T}$ when log returns are random—so MEL is more conservative than maximizing expected terminal wealth. The criterion is therefore:

$$
\max\ \mathbb{E}\ln(1+R_t).
$$

**Asymptotic dominance** (Breiman 1961; Algoet–Cover 1988; etc.): if $W_T^*$ is MEL wealth and $W_T$ is any other strategy’s wealth,

$$
\lim_{T\to\infty}\mathbb{P}(W_T^*>W_T)=1,\qquad
\mathbb{P}\Big(\lim_{T\to\infty}\frac{W_T^*}{W_T}=\infty\Big)=1.
$$

**Utility special case.** If the investor has $u(w)=\ln w$ and cares only about $W_T$, then

$$
\mathbb{E}u(W_T)=\ln w_0 + T\,\mathbb{E}r_t,
$$

so MEL is *exactly* optimal for every finite $T$ (myopia of log / CRRA). The authors acknowledge the Samuelson (1971) / Merton–Samuelson (1974) critique: log is only one utility; for other utilities MEL can be arbitrarily bad in utility terms. They do not adjudicate that debate; they take MEL as the object of study.

---

## 3. Two-Asset MEL and Reallocation Frequency

### 3.1 Portfolio log return

Risky log return $r$, risk-free log return $r_f$, weight $a$ in the risky asset:

$$
w_0 e^{r(a)} = w_0 a e^{r} + w_0(1-a)e^{r_f},
$$

hence

$$
r(a)=\ln\big(a e^{r}+(1-a)e^{r_f}\big).
$$

Optimize

$$
a^*=\arg\max_a\ \mathbb{E}r(a).
$$

$\mathbb{E}r(a)$ is concave in $a$, so the optimum is unique. With unbounded support for $r$, they restrict $0\le a\le 1$ (no shorting, no leverage) to keep the problem well-defined. Corner solutions $a^*\in\{0,1\}$ are possible.

### 3.2 Example 1 — dichotomous returns

Gross return $e^{r}$ equals $2$ or $0.25$ each with probability $1/2$. Then

$$
\mathbb{E}r(a)=\tfrac12\ln\big(2a+(1-a)e^{r_f}\big)+\tfrac12\ln\big(0.25a+(1-a)e^{r_f}\big),
$$

with closed form

$$
a^*=\frac{e^{r_f}(1.125-e^{r_f})}{(2-e^{r_f})(e^{r_f}-0.25)}.
$$

For $e^{r_f}=1.05$, **$a^*=0.1036$** (~10% in the risky asset).

Because the MEL mix is not a traded single security, **periodic rebalancing** is required: after a double, too much wealth sits in the risky asset and must be sold down to restore $a^*$. MEL is a discrete-time **constant-mix** strategy.

### 3.3 Example 2 — doubling the period length

Interpret Example 1’s returns as **half-year** returns. Aggregate to a one-year basic period: the yearly log return is the convolution $r_1+r_2$ of two i.i.d. half-year returns (binomial tree with three yearly gross returns: $4$, $0.5$, $1/16$ with probabilities $1/4$, $1/2$, $1/4$). Maximizing expected log over the yearly mix yields

$$
a^{**}=0.0813
$$

when $e^{r_f}=1.05$—**lower** than $a^*=0.10$. Extending the buy-and-hold interval reduced optimal risk exposure in this example.

**Important qualification:** one cannot conjecture that longer periods *always* cut $a^*$. Bamberg–Dorfleitner–Krapp (2006) give buy-and-hold examples where a longer horizon *raises* the initial risky share; those examples translate into the MEL setting. What *is* invariant: asymptotic optimality property (dominance of $W_T^*$) continues to hold for any fixed basic period, because comparisons use the same period definition.

---

## 4. Heavy Tails: Definitions and Why MEL Still Works

### 4.1 Return notion matters

“Stock returns have heavy tails” is ambiguous. If log return $r$ is normal (light tails), the percentage return $100(e^{r}-1)$ is shifted lognormal and has a **very heavy upper tail**. The paper focuses on heavy tails for **log returns** as alternatives to normality.

Classical references: Mandelbrot (1963), Samuelson (1967), stable Paretian models (Rachev–Mittnik 2000, etc.).

### 4.2 Tail definitions (for log return $r$)

1. **Pareto upper tail:** $\mathbb{P}(r>x)\sim c/x^{\alpha}$ as $x\to\infty$, $\alpha>0$.  
2. **Regular variation:** $\mathbb{P}(r>x)\sim L(x)/x^{\alpha}$ with $L$ slowly varying.  
3. **Subexponential / no exponential moments:** $\mathbb{E}e^{sr}=\infty$ for all $s>0$.  
4. **Weaker:** $\mathbb{E}e^{r}=\infty$.

Under (1)–(4), Bamberg–Dorfleitner (2002) show that the **percentage** return has infinite mean—so Markowitz mean–variance is undefined/useless. Conditional VaR can also be infinite with short sales (Bamberg–Neuhierl 2010).

### 4.3 MEL objective remains finite

Assume $\mathbb{E}r<\infty$ and $0\le a\le 1$. Splitting the integral of $\ln(ae^{r}+(1-a)e^{r_f})$ on $\{r\le 0\}$ and $\{r>0\}$ and using elementary bounds yields

$$
\mathbb{E}r(a)\le \ln\big(a+(1-a)e^{r_f}\big)+\mathbb{E}[r]_+ <\infty,
$$

and similarly $\mathbb{E}r(a)>-\infty$. So MEL remains well-posed when mean–variance is not.

---

## 5. Specific Distributions and Numerical $a^*$

### 5.1 Models (Table 1 parameters)

Risk-free log rate fixed at $r_f=0.03$. Risky log-return mean $\ell=0.06$ in all cases (roughly annual equity vs bond). Distributions:

| Distribution | Parameters |
|---|---|
| Normal | $\ell=0.06$, $\sigma=0.3$ |
| Laplace | $\ell=0.06$, $k\in[0.5,3]$ (step 0.05) |
| Power Laplace (GED) | $\ell=0.06$, $p\in[0.5,7]$ |
| Student-$t$ | $\ell=0.06$, $m\in[3,150]$ |
| Stable $S_{\alpha}(0,c,d)$ | $\alpha\in[1.1,2]$, $\beta=0$, $c=0.3/\sqrt{2}$, $d=0.06$ |

Densities:

**Laplace:** $f(r)=\frac{k}{2}e^{-k|r-\ell|}$. Heavy tails for $k\le 1$.

**Power Laplace:** $f(r)=\frac{1}{2p^{1/p}\Gamma(1+1/p)}\exp(-|r-\ell|^p/p)$. Heavy for $p\le 1$; $p=2$ is Gaussian; $p\to\infty$ tends to uniform.

**Student-$t$:** heavy for all finite $m$; $\to$ normal as $m\to\infty$.

**Stable:** fat-tailed for $\alpha<2$ (with $\beta\neq -1$).

### 5.2 Benchmark and tables

Normal benchmark: **$a^*=0.8378$**.

**Table 2 — Laplace $k$:**  
$k$: 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1, 2  
$a^*$: 0.51, 0.51, 0.53, 0.54, 0.56, 0.58, 0.60, 0.62, 0.65, 0.68, **1.00**

**Table 3 — Power Laplace $p$:**  
$p$: 0.5, 0.6, 0.7, 0.8, 0.9, 1, 2, 3, 4, 5, 6  
$a^*$: 0.51, 0.52, 0.53, 0.64, 0.66, 0.68, 0.84, 0.93, 0.99, 1.00, 1.00

**Table 4 — Student-$t$ $m$:**  
$m$: 3, 5, 10, 15, 20, 30, 40, 50, 55, 60, 100  
$a^*$: 0.66, 0.72, 0.77, 0.79, 0.81, 0.82, 0.82, 0.82, 0.83, 0.83, 0.83

**Table 5 — Stable $\alpha$:**  
$\alpha$: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2  
$a^*$: 0.58, 0.59, 0.61, 0.63, 0.65, 0.68, 0.71, 0.74, 0.78, 0.84

**Pattern:** as tails lighten ($k\uparrow$, $p\uparrow$, $m\uparrow$, $\alpha\uparrow$), $a^*$ rises toward (and for very light Laplace/GED, to) full investment. Heavy lower tails cut the Kelly weight—e.g., stable $\alpha=1.1$ gives $a^*\approx 0.58$ vs normal $0.84$.

**Variance comparison:** increasing normal $\sigma$ can mimic heavy-tail $a^*$. Example: normal with $\ell=0.06$, $\sigma=0.8$ yields $a^*\approx 0.55$, close to stable $\alpha=1.1$.

---

## 6. Appendix Theory: Why $a^*\ge 1/2$ under Symmetry and $\ell>r_f$

FOC for interior optimum (density $f$):

$$
\int_{-\infty}^{\infty}\frac{e^{r}-e^{r_f}}{a e^{r}+(1-a)e^{r_f}}f(r)\,dr = 0.
$$

Define

$$
h(r;a)=\frac{e^{r}-e^{r_f}}{a e^{r}+(1-a)e^{r_f}}.
$$

For $a=1/2$, $h(1/2,\cdot)$ is **point-symmetric** about $r=r_f$:

$$
h(1/2,r_f-x)=-h(1/2,r_f+x).
$$

If $f$ is symmetric about $\ell>r_f$, more probability mass lies above $r_f$ than below, so the integrand’s expectation at $a=1/2$ is **positive**. Because the FOC’s left-hand side decreases in $a$, it follows that

$$
a^*>1/2.
$$

If $\ell=r_f$, then $a^*=1/2$ regardless of tail thickness. This qualifies the slogan “heavier tails ⇒ always less risk”: the **equity premium in log returns** ($\ell-r_f$) can dominate tail thickness in determining whether one is above or below half wealth in the risky asset.

Technical note: exchanging derivative and integral needs uniform convergence; for heavy tails this is stated for $a>0$.

---

## 7. Proportional Transaction Costs (Appendix A.2)

With proportional cost rate $\tau$ on the risky leg, end-of-period wealth matches a cost-adjusted log return $r-c$ with $c=-\ln(1-\tau)\approx\tau$ for small $\tau$ (e.g., $\tau=0.01\Rightarrow c\approx 0.01005$). The MEL objective becomes

$$
\max_a\ \mathbb{E}\ln\big(a e^{r-c}+(1-a)e^{r_f}\big).
$$

So costs enter as a downward shift of the risky log return before the usual MEL comparison across assets/strategies.

---

## 8. Practitioner Takeaways

1. **Kelly / MEL weights are period-dependent.** Annual vs monthly rebalance is not a pure trading-friction issue; it changes the optimizer because the convolution of returns changes the objective. Calibrate $a^*$ at the horizon you will actually rebalance.  
2. **Heavy log-return tails cut Kelly fractions** in the calibrated tables—often from ~0.84 (normal) down toward ~0.5–0.7 for empirically relevant heavy-tail parameters.  
3. **But** with symmetric favorable returns ($\ell>r_f$), **$a^*\ge 1/2$** always—tails alone cannot justify a tiny equity weight under MEL with a meaningful premium.  
4. When percentage returns have infinite mean, **mean–variance and CVaR (with shorts) can break**; MEL remains defined if $\mathbb{E}r<\infty$.  
5. Proportional costs are an easy adjustment: replace $r$ by $r-c$.  
6. This paper is **not** about Cover universal portfolios, side information, or drawdown constraints—those themes belong to other UP literature despite the PDF’s library filename.

---

## 9. Limitations

- Two-asset only; no multi-asset growth-optimal numerics.  
- i.i.d. log returns; no serial dependence, regime switching, or stochastic volatility beyond the static heavy-tail distribution.  
- Leverage/shorts excluded when support is unbounded.  
- No empirical estimation of $\ell,\sigma,\alpha$ from a specific market—parameters are calibrated to “look like” annual equity/bond moments.  
- Samuelson critique acknowledged but not resolved: MEL may be wrong for non-log investors even if asymptotically growth-optimal.

---

## 10. Extended Discussion of Reallocation Frequency (Worked Intuition)

The period-length effect is easy to miss because continuous-time Kelly formulas (e.g., $a^*=\mu/\sigma^2$ in Black–Scholes) look horizon-invariant for log utility. In discrete time with **rebalancing only at period boundaries**, lengthening the period is *not* the same as observing the same diffusion more sparsely: within the long period the mix $a$ is **not** restored, so the year-end wealth ratio is

$$
a\,e^{r_1+r_2}+(1-a)e^{2r_f}
$$

rather than the product of two separately rebalanced mixes. That buy-and-hold convex combination is a different random variable than two compounded MEL steps, and its expected log maximizer shifts (here, from 0.104 to 0.081).

Operationally:

- If a desk runs Kelly on **daily** returns but finances/risk-reports on **monthly** capital, the theoretically consistent $a^*$ is the one for the period at which weights are actually reset.  
- “Half Kelly” heuristics sometimes used under uncertainty are a different robustness device; Bamberg–Neuhierl’s point is identification of the objective’s horizon, not parameter uncertainty.

---

## 11. Reading the Tables as a Robustness Surface

Fix $\ell=0.06$, $r_f=0.03$ (300 bp log equity premium). Then:

- Moving from Gaussian $\sigma=0.3$ ($a^*\approx 0.84$) to Student-$t$ with $m=3$ ($a^*\approx 0.66$) is a **~18 percentage-point** cut in the risky weight.  
- Stable $\alpha=1.5$ (a common rough equity estimate in older stable literature) gives $a^*\approx 0.65$.  
- Laplace with $k=1$ (borderline heavy) gives $0.68$; very heavy $k=0.5$ gives $0.56$.  
- As GED $p\to 2$, $a^*\to$ Gaussian neighborhood ($0.84$ at $p=2$); as $p\to\infty$ (platykurtic), $a^*\to 1$.

For a CIO using Kelly-like growth targeting in a pension glide path, replacing a normal assumption with a $t_5$ or stable-$1.5$ assumption is first-order for the equity weight—larger than many capital-market-assumption tweaks to expected return of 50 bp.

---

## 12. Links to the Universal-Portfolio / Kelly Literature

Although misfiled under a “UniversalPortfolios_” basename, the intellectual lineage is Kelly (1956), Breiman (1961), Latané (1959), Algoet–Cover (1988), Thorp (2006 handbook chapter), with critical notes from Samuelson (1971) and Merton–Samuelson (1974). Cover’s universal portfolios (Cover 1991; Cover–Ordentlich 1996) are about *competitive* schemes that achieve MEL growth without knowing the distribution; Bamberg–Neuhierl instead assume known (or postulated) distributions and study comparative statics of the oracle MEL weight. The two research programs are complementary: UP theory asks how to learn $a^*$; this paper asks how $a^*$ moves when the period or the tail model changes.

---

## 13. Equations Cheat-Sheet

**Wealth:** $W_T=w_0\exp(\sum r_t)$, growth rate $\ell=\mathbb{E}r$.  
**MEL:** $\max\mathbb{E}\ln(1+R)$.  
**Mix:** $r(a)=\ln(a e^{r}+(1-a)e^{r_f})$.  
**FOC:** $\mathbb{E}\big[(e^{r}-e^{r_f})/(a e^{r}+(1-a)e^{r_f})\big]=0$.  
**Costs:** use $r-c$, $c=-\ln(1-\tau)$.  
**Symmetry lemma:** $\ell>r_f$ + symmetric $f$ $\Rightarrow a^*>1/2$.

---

## 14. Verdict

Bamberg–Neuhierl (2011) is a compact, equation-driven note that cleans up two comparative statics for Kelly/MEL investors: rebalancing horizon matters for the optimal risky weight, and heavy log-return tails reduce that weight—but not below one-half when the log premium is positive and shocks are symmetric. It is most useful as a teaching and calibration companion to growth-optimal allocation under non-normal returns, and should not be confused with Cover-style universal portfolio algorithms despite the library filename.


---

## 15. Numerical Worked Example: From Half-Year Kelly to Annual Kelly

Start from Example 1’s half-year gross returns $\{2, 0.25\}$ with equal probability and $e^{r_f}=1.05$ per half-year. One-year gross returns without intra-year rebalancing, if the investor holds constant share $a$ through both half-years, are not simply $(ae^{r}+(1-a)e^{r_f})^2$ pathwise in log-expectation—the paper aggregates the *risky asset’s* two-period gross return first (convolution), then mixes once at the annual horizon. The three atomic yearly gross outcomes for the risky asset are:

$$
4\ \text{with prob }1/4,\quad 0.5\ \text{with prob }1/2,\quad 1/16\ \text{with prob }1/4.
$$

The annual risk-free gross is $e^{2r_f}=1.05^2=1.1025$. The objective becomes

$$
\begin{aligned}
\mathbb{E}\ln\big(a e^{r_1+r_2}+(1-a)e^{2r_f}\big)
&= \tfrac14\ln(4a+(1-a)1.1025)\\
&\quad+\tfrac12\ln(0.5a+(1-a)1.1025)\\
&\quad+\tfrac14\ln(a/16+(1-a)1.1025).
\end{aligned}
$$

Numerical maximization yields $a^{**}=0.0813$ vs $a^*=0.1036$ at the half-year horizon—a **relative cut of about 22%** in the risky weight from merely changing the rebalance grid. A desk that estimates Kelly on daily data but rebalances quarterly should not paste the daily $a^*$ into the quarterly book without re-solving the convolved problem (or moving to a continuous-time approximation with explicit trading).

---

## 16. Why Infinite-Mean Percentage Returns Break Markowitz but Not MEL

Suppose $\mathbb{E}e^{r}=\infty$ (definition (14)). Then expected simple return is infinite, so the Markowitz problem $\max_a \mathbb{E}[a(e^{r}-1)+(1-a)(e^{r_f}-1)]$ subject to a variance constraint is ill-posed: every portfolio with $a>0$ has infinite expected return. Risk measures that integrate the whole right tail (CVaR with shorts) can likewise explode. MEL only needs $\mathbb{E}r<\infty$, which is far weaker: stable laws with $\alpha\in(1,2)$ have finite means but infinite variances; for $\alpha\le 1$ even the mean of $r$ may fail—and then MEL itself needs reconsideration. The paper’s numerical stable table starts at $\alpha=1.1$ with a location parameter, staying in the finite-mean region for $r$.

This is the cleanest “why Kelly survives fat tails” argument in the paper: the objective’s logarithm tames the multiplicative wealth process exactly where linear expected-return objectives blow up.

---

## 17. Comparative Statics vs Popular Kelly Heuristics

Practitioners often use:

- **Full Kelly** under a lognormal/GBM approximation $a^*=(\mu-r)/\sigma^2$;  
- **Half Kelly** as a robustness haircut;  
- **Fractional Kelly** tuned to a max-drawdown or utility.

Bamberg–Neuhierl’s tables are a distributional robustness surface, not a fractional-Kelly rule. For $\sigma=0.3$, $\mu_{\log}=0.06$, $r_f=0.03$, the GBM-style approximation gives

$$
a^*\approx\frac{0.06-0.03}{0.3^2}=0.333,
$$

which **does not match** their numerical normal MEL weight $0.8378$. The discrepancy is expected: (i) their $a$ is a portfolio weight in a two-asset mix with the exact log objective $\mathbb{E}\ln(ae^{r}+(1-a)e^{r_f})$, not the continuous-time excess-drift / variance formula for a continuously rebalanced futures-like exposure; (ii) continuous-time Kelly for a stock-plus-bond diffusion involves the excess *simple* return drift and can differ once discrete compounding and the no-leverage constraint bind. The lesson for implementers: **state the trading mechanics before quoting a Kelly formula**. Their Tables 2–5 are the right comparative statics *for their discrete constant-mix MEL problem*; they are not plug-in replacements for Thorp’s continuous betting fractions without care.

---

## 18. Heavy Lower Tails vs Heavy Upper Tails

The paper repeatedly stresses **lower** tails as what cuts $a^*$. Intuitively, MEL’s logarithm penalizes near-ruin outcomes severely; a heavy left tail on $r$ raises the probability of paths where $ae^{r}+(1-a)e^{r_f}$ is small, pulling the optimal $a$ down. A heavy *upper* tail is less punishing under log (log growth benefits from upside but with declining marginal impact). Stable laws with $\beta=0$ are symmetric in the innovation sense used here; skewness ($\beta\neq 0$) is not explored numerically. For equity markets with negative skew / crash risk, one should expect *even lower* $a^*$ than the symmetric tables—qualitatively reinforcing the “heavy tails cut risk” message on the downside.

---

## 19. Allocator-Facing Summary Paragraph

For a long-horizon investor who explicitly wants growth optimality (endowments, some family offices, Kelly-style prop books), Bamberg–Neuhierl say: (1) pick the rebalance period and solve MEL at that period; (2) replace Gaussian log returns with a heavy-tailed density calibrated to the same mean and a plausible scale—expect a sizable cut in $a^*$ but not a collapse below 50% if the log premium remains ~3% under symmetry; (3) fold proportional costs in as $r\mapsto r-c$; (4) do not confuse this exercise with universal-portfolio regret bounds or with mean–variance optimization under infinite-mean simple returns. The paper is short, transparent, and best used as a calibration companion rather than as an empirical asset-pricing contribution.


---

## 20. Full Replication Recipe for Tables 2–5

To reproduce $a^*$ numerically:

1. Fix $r_f=0.03$ and a density $f_{\theta}(r)$ with mean $0.06$.  
2. For a grid $a\in\{0,0.01,\ldots,1\}$, estimate
   $$\widehat{G}(a)=\int \ln\big(a e^{r}+(1-a)e^{r_f}\big)f_{\theta}(r)\,dr$$
   by quadrature (Gauss–Hermite for light tails; truncated adaptive quadrature or Monte Carlo with importance sampling for stable/Pareto-like tails).  
3. Set $a^*=\arg\max_a\widehat{G}(a)$.  
4. For Laplace/GED/$t$, standard libraries suffice. For stable innovations, use characteristic-function-based density evaluation (e.g., Nolan’s methods) with the paper’s scale $c=0.3/\sqrt{2}$ and location $d=0.06$.

Critical numerical checks: (i) $G(a)$ concave; (ii) at the normal parameter, $a^*\approx 0.8378$; (iii) as $m\to\infty$ in Table 4, $a^*\to$ normal value; (iv) as $\alpha\to 2$ in Table 5, $a^*\to 0.84$.

---

## 21. Relationship Between Reallocation Frequency and Transaction Costs

The paper treats period length and costs in separate sections, but they interact. Longer periods mean fewer rebalances and lower cumulative proportional costs, yet Example 2 shows longer periods can *also* lower the desired $a^{**}$. A joint problem is:

$$
\max_{a}\ \mathbb{E}\ln\big(a e^{r_{\Delta}-c_{\Delta}}+(1-a)e^{r_f\Delta}\big),
$$

where $\Delta$ is the period length, $r_{\Delta}$ the convolved risky log return, and $c_{\Delta}$ the effective cost drag for rebalancing at that frequency (possibly including a fixed cost amortized into an effective $\tau$). The optimum $(a^*,\Delta^*)$ is a genuine joint design choice for implementing MEL in markets with both fat tails and nonzero $\tau$. The authors stop short of solving that joint problem, but their appendices supply the two ingredients.

---

## 22. What “Asymptotic Optimality Invariant to Period” Really Means

Property (6) compares $W_T^*$ and $W_T$ built from the **same** period definition. If you change the period, you change the strategy class and the meaning of one “trial.” You do not get to claim that the half-year MEL strategy dominates an annual MEL strategy pathwise—their capital processes are different gambling games. The invariance statement is narrower: *within* a fixed period length, MEL still asymptotically crushes alternatives. Comparative statics across period lengths are about **which MEL game you choose to play**, not about dominance across games.

---

## 23. Mistakes to Avoid When Citing This Paper

1. Citing it as a universal-portfolio / side-information paper (filename trap).  
2. Importing Table 2–5 weights into a continuous-time GBM Kelly formula without matching the discrete mix objective.  
3. Concluding “fat tails ⇒ Kelly weight → 0”; the symmetry lemma forbids that under $\ell>r_f$.  
4. Ignoring the no-leverage constraint: some growth-optimal solutions in unbounded markets want $a>1$; the paper’s $a\le 1$ bind may be active (Laplace $k=2$ gives $a^*=1$).  
5. Treating Example 2’s 22% cut as universal—the authors explicitly say the sign of the period effect can flip.

---

## 24. Closing Synthesis

Kelly’s growth criterion remains central to long-horizon portfolio theory and to competitive online investment. Bamberg and Neuhierl add two comparative-static disciplines that quants actually need when turning Kelly into a policy: honor the rebalancing grid, and honor the tail model. Their tables show that a move from Gaussian to empirically motivated heavy tails can cut the risky weight by ten to twenty-five percentage points at a fixed 3% log premium—economically large—while the theoretical floor at one-half under symmetry keeps the conclusion from collapsing into pure risk aversion. Together with a simple proportional-cost adjustment, that is a complete miniature toolkit for discrete-time MEL in a two-asset world.


---

## 25. Minimal Glossary

| Term | Meaning in this paper |
|---|---|
| MEL | Maximum expected log; Kelly growth criterion |
| $a^*$ | Optimal fraction of wealth in the risky asset |
| Basic return period | Interval over which returns are measured and weights are reset |
| Heavy tails (log return) | Pareto / regular variation / no exponential moments / $\mathbb{E}e^{r}=\infty$ |
| Constant mix | Strategy that restores weights each period |
| $r_f=0.03$, $\ell=0.06$ | Calibration of annual-like risk-free log rate and risky mean |

With these definitions fixed, the paper’s two headline sentences are precise: lengthening the basic period changed $a^*$ from $0.1036$ to $0.0813$ in the dichotomous example; replacing normal log returns by heavy-tailed alternatives cut $a^*$ from $0.8378$ toward the one-half floor in Tables 2–5.
