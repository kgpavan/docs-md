# Nonparametric Prediction

**Authors:** László Györfi and Dominik Schäfer  
**Publication:** Chapter 16 in a collected volume on nonparametric / statistical learning methods (PDF pagination 339–354); bibliographic cluster around Györfi–Lugosi and Cover–Algoet universal investment results circa early 2000s  
**Source PDF:** `UniversalPortfolios_Gyorfi_2003.pdf` (Drive id `0B-6kBz0I0dMscEhiVkEwSnRqV0U`)  
**Summary prepared:** 2026-09-26 (Scholar batch_2026-09-26_4)  
**Extraction:** `pdftotext -layout` OK (~5,877 words). No OCR required.  
**Note on title:** An earlier candidate label suggested “Nonparametric Kernel-Based Sequential Investment Strategies.” The chapter’s actual title is **Nonparametric Prediction**. It covers three loss functions—squared loss (regression), 0–1 loss (pattern recognition), and log utility (portfolio selection)—with universal consistency via expert aggregation. The portfolio section *is* a kernel/partition-based universal investment scheme in the Cover–Algoet tradition.

---

## 1. Agenda

The chapter constructs **universal prediction rules** for stationary (and ergodic) time series: procedures that are asymptotically optimal yet require **no a priori knowledge** of the data-generating distribution (Haussler–Kivinen–Warmuth; Merhav–Feder). Three prototypical losses organize the exposition:

1. **Squared loss** — real-valued regression / sequential prediction.  
2. **0–1 loss** — finite-alphabet pattern recognition.  
3. **Logarithmic utility** — sequential portfolio selection (growth rate of wealth).

The unifying engine is **data-dependent combination of elementary experts**: down-weight experts that have predicted poorly in the past (Cesa-Bianchi et al.; Littlestone–Warmuth; Vovk; Weinberger–Merhav–Feder). For portfolios, the same idea yields a strategy that is **universal** for all ergodic return processes with finite $\mathbb{E}|\log X^{(j)}|$.

---

## 2. Squared-Error Prediction

### 2.1 Sequential setup

Observe covariates $x_i\in\mathbb{R}^d$ and responses $y_i\in\mathbb{R}$. At time $i$ the predictor forms $g_i(x_1^i,y_1^{i-1})$ before seeing $y_i$. Cumulative loss:

$$
L_n(g)=\frac1n\sum_{i=1}^n\big(g_i(x_1^i,y_1^{i-1})-y_i\big)^2.
$$

### 2.2 Static regression reminder

For i.i.d. $(X,Y)$ with $\mathbb{E}Y^2<\infty$, the $L^2$ risk is minimized by $m(x)=\mathbb{E}[Y|X=x]$, and

$$
\mathbb{E}(g(X)-Y)^2=\mathbb{E}(m(X)-Y)^2+J(g),\qquad J(g)=\mathbb{E}(m(X)-g(X))^2.
$$

Stone (1977): there exist **universally consistent** local-averaging estimators

$$
m_n(x)=\sum_{i=1}^n W_{ni}(x;X_1,\ldots,X_n)\,Y_i
$$

(nearest neighbor, partitioning, kernel) with $J(m_n)\to 0$ for all distributions with finite second moments, under standard conditions (e.g., $k_n\to\infty$, $k_n/n\to 0$ for $k$-NN).

**Kernel estimator:**

$$
m_n(x)=\frac{\sum_{i=1}^n Y_i K_h(x-X_i)}{\sum_{i=1}^n K_h(x-X_i)},\qquad K_h(u)=K(u/h).
$$

**Least squares over growing classes $\mathcal{F}_n$:** minimize empirical $L^2$ risk over piecewise polynomials / splines, etc.

### 2.3 Dependent data: Cesàro universality

For stationary ergodic $\{(X_i,Y_i)\}$, the ideal predictor $\mathbb{E}[Y_{n+1}|X_{n+1},D_n]$ **cannot** be learned pathwise for all processes (Györfi–Morvai–Yakowitz). Even the limiting minimal risk

$$
L^*=\lim_{n\to\infty}\min_g\mathbb{E}\big(g(X_{n+1},D_n)-Y_{n+1}\big)^2
$$

is not achievable by any single sequence in the almost-sure instantaneous sense. However, there exist predictors with

$$
\lim_{n\to\infty}\frac1n\sum_{i=1}^n\big(g_i(X_{i+1},D_i)-Y_{i+1}\big)^2 = L^*\quad\text{a.s.}
$$

for **all** stationary ergodic sequences—**universal Cesàro consistency**.

### 2.4 Expert aggregation lemma (squared loss)

Lemma 1 (extension of Kivinen–Warmuth / Singer–Feder arguments). Experts $\tilde h_k$ with predictions in $[-B,B]$, outcomes in $[-B,B]$, prior $q_k$ on experts, weights

$$
w_{t,k}=q_k\exp\big(-(t-1)L_{t-1}(\tilde h_k)/c\big),\quad c\ge 8B^2,\quad
v_{t,k}=\frac{w_{t,k}}{\sum_i w_{t,i}}.
$$

Combined predictor $\tilde g_t=\sum_k v_{t,k}\tilde h_k(y_1^{t-1})$ satisfies

$$
L_n(\tilde g)\le \inf_k\Big(L_n(\tilde h_k)-\frac{c\ln q_k}{n}\Big).
$$

### 2.5 Quantized-match experts and Theorem 1

Elementary experts $h^{(k,\ell)}$: quantize $\mathbb{R}^d$ by $G_\ell$ and $\mathbb{R}$ by $H_\ell$; look for past times $i$ where the last $k$ quantized $x$-blocks and $y$-blocks match the present; predict the average of those matched $y_i$.

No single $(k,\ell)$ is universally consistent (bias–variance tension). Combine with prior $q_{k,\ell}>0$ via Lemma 1. **Theorem 1 (Györfi–Lugosi):** if quantizers are “asymptotically fine” and $|Y_i|\le B$ a.s., the combination is universally Cesàro consistent.

---

## 3. Pattern Recognition (0–1 Loss)

Static Bayes classifier: $g^*(x)=\arg\max_i\mathbb{P}(Y=i|X=x)$. For ergodic dependent data, instantaneous risk $R^*$ is again not pathwise learnable, but **universal Cesàro consistency** is achievable:

$$
L_n(g)=\frac1n\sum_{i=1}^n\mathbf{1}\{g_i(X_{i+1},D_i)\neq Y_{i+1}\}\to R^*\quad\text{a.s.}
$$

Györfi–Lugosi–Morvai construct such classifiers by **randomized** expert combination.

**Lemma 2 (Cesa-Bianchi):** finite expert class of size $N$; exponential weights with learning rate $\sqrt{8\ln N/n}$; randomized prediction via uniform $U_t\sim\mathrm{Unif}[0,1]$ yields

$$
\mathbb{E}L_n(\tilde g)\le \min_{k=1,\ldots,N} L_n(\tilde h^{(k)})+\sqrt{\frac{\ln N}{2n}}
$$

for every sequence. This finite-$N$ regret bound is the combinatorial engine behind the infinite-expert consistency constructions (let $N$ grow, nest partitions, etc.).

---

## 4. Log Utility: Portfolio Selection

### 4.1 Market and wealth

$d$ stocks; return vector $x=(x^{(1)},\ldots,x^{(d)})$ with $x^{(j)}$ the gross return factor on asset $j$. Portfolio $b$ in the simplex (no consumption, no short sales):

$$
S_1=S_0\langle b,x\rangle.
$$

After $n$ days with nonanticipating $b_i=b(x_1^{i-1})$,

$$
S_n=S_0\prod_{i=1}^n\langle b(x_1^{i-1}),x_i\rangle
=S_0\exp\big(n W_n(B)\big),
$$

$$
W_n(B)=\frac1n\sum_{i=1}^n\log\langle b(x_1^{i-1}),x_i\rangle.
$$

Maximizing $S_n$ ≡ maximizing average growth rate $W_n$.

### 4.2 Log-optimum benchmark (Algoet–Cover)

For stationary ergodic $\{X_n\}$, the log-optimum strategy $B^*$ satisfies

$$
\mathbb{E}\big[\log\langle b^*(X_1^{n-1}),X_n\rangle\big|X_1^{n-1}\big]
=\mathbb{E}\Big[\max_b\log\langle b(X_1^{n-1}),X_n\rangle\Big|X_1^{n-1}\Big],
$$

and for any competing $B$,

$$
\limsup_{n\to\infty}\frac1n\log\frac{S_n}{S_n^*}\le 0\quad\text{a.s.},\qquad
\lim_{n\to\infty}\frac1n\log S_n^*=W^*\quad\text{a.s.},
$$

with

$$
W^*=\mathbb{E}\Big[\max_{b(\cdot)}\mathbb{E}\big[\log\langle b(X_{-\infty}^{-1}),X_0\rangle\big|X_{-\infty}^{-1}\big]\Big].
$$

**Definition (universality).** $B$ is universal for a class $\mathcal{C}$ of ergodic processes if for every process in $\mathcal{C}$,

$$
\lim_{n\to\infty}\frac1n\log S_n(B)=W^*\quad\text{a.s.}
$$

### 4.3 The chapter’s universal strategy $B$

**Elementary partition portfolios $H^{(k,\ell)}$.** Nested partitions $\mathcal{P}_\ell=\{A_{\ell,j}\}$ of $\mathbb{R}^d$ with quantizer $G_\ell$. For each length-$k$ quantized string $s$,

$$
b^{(k,\ell)}(x_1^{n-1},s)=\arg\max_b\prod_{\{k<i<n:\,G_\ell(x_{i-k}^{i-1})=s\}}\langle b,x_i\rangle
$$

(equivalently, maximize the average log return over matched past blocks); use the uniform portfolio if no matches. Then

$$
h^{(k,\ell)}(x_1^{n-1})=b^{(k,\ell)}\big(x_1^{n-1},\,G_\ell(x_{n-k}^{n-1})\big).
$$

**Mixture.** With prior $q_{k,\ell}>0$ on all pairs $(k,\ell)$,

$$
b(x_1^{n-1})=\frac{\sum_{k,\ell} q_{k\ell}\,S_{n-1}(H^{(k,\ell)})\,h^{(k,\ell)}(x_1^{n-1})}{\sum_{k,\ell} q_{k\ell}\,S_{n-1}(H^{(k,\ell)})}.
$$

Wealth of the mixture is the prior-weighted average of expert wealths:

$$
S_n(B)=\sum_{k,\ell} q_{k\ell}\,S_n(H^{(k,\ell)}).
$$

**Theorem 2.** If (a) partitions are nested and (b) diameters of cells intersecting any fixed ball shrink to 0 as $\ell\to\infty$, then $B$ is universal for all ergodic processes with $\mathbb{E}|\log X^{(j)}|<\infty$ for each coordinate $j$.

### 4.4 Proof architecture (high level)

1. **Wealth lower bound:**
   $$
   W_n(B)\ge\sup_{k,\ell}\Big(W_n(H^{(k,\ell)})+\frac{\log q_{k\ell}}{n}\Big)
   \implies\liminf W_n(B)\ge\sup_{k,\ell}\liminf W_n(H^{(k,\ell)}).
   $$
2. **Breiman’s generalized ergodic theorem** (Lemma 3): if $f_i(Z)\to f(Z)$ a.s. with integrable dominant, then $\frac1n\sum f_i(T^i Z)\to\mathbb{E}f(Z)$.  
3. **Algoet–Cover continuity of log-optimal portfolios** (Theorem 3): weak convergence of return measures $\Rightarrow$ almost-sure convergence of $\langle b_n,u\rangle$ for log-optimal $b_n$; and nested information $\sigma$-fields raise conditional growth rates to the full $W^*$.  
4. Empirical conditional measures on matched blocks converge to true conditional laws of $X_0$ given quantized past; elementary experts’ growth rates $\to\epsilon_{k,\ell}$; nested partitions make $\epsilon_{k,\ell}$ a submartingale in $(k,\ell)$ with

$$
\sup_{k,\ell}\epsilon_{k,\ell}=W^*.
$$

Hence $\liminf W_n(B)\ge W^*$ a.s., i.e., universality.

---

## 5. What “Kernel-Based” Means Here

The candidate filename emphasized kernels. In the chapter:

- **Regression section:** classical Nadaraya–Watson kernels appear as universally consistent static estimators.  
- **Portfolio section:** the universal scheme is **partition / histogram** based (nearest-neighbor–like matching of quantized past return blocks), closer to Algoet’s universal schemes than to Cover’s continuous $\mu$-weighted universal portfolio on the simplex.  
- Combination weights are **multiplicative wealth weights** (exponential in past growth), the portfolio analogue of exponential expert weights under log loss.

So “kernel-based sequential investment” is a fair informal description of the nonparametric neighborhood-matching idea, but the precise object proved universal in Theorem 2 is the **partition-expert mixture**.

---

## 6. Implementation Sketch for a Quant Research Desk

**Offline / research mode (finite expert truncation).**

1. Choose finite grids $k\in\{1,\ldots,K_{\max}\}$, $\ell\in\{1,\ldots,L_{\max}\}$.  
2. Build nested partitions of return space (e.g., product quantiles of past returns, or dyadic cubes on $\log x$).  
3. For each $(k,\ell)$, maintain maps from quantized $k$-blocks $\to$ cumulative log-optimal $b$ (online convex optimization on the simplex: maximize $\sum\log\langle b,x_i\rangle$ over matches—solved by gradient ascent / EG).  
4. Mix experts by normalized $q_{k\ell}S_{n-1}(H^{(k,\ell)})$.  
5. Enforce no-short / no-leverage by staying in the simplex; add a small cash asset if needed for numerical stability when some $x^{(j)}\approx 0$.

**Practical frictions not in the theorem:** transaction costs, leverage constraints, overnight gaps, non-ergodicity / structural breaks, survivorship in equity universes. Universality is an asymptotic, frictionless guarantee.

**Feature dimension:** $d$ large makes partitions empty (curse of dimensionality). Practitioners often apply the scheme to a small set of liquid futures or to PCA factors, or replace hard partitions by continuous kernels / nearest neighbors in a low-dimensional feature map (related literature: Györfi–Urbán–Vajda-type nearest-neighbor portfolios).

---

## 7. Connections Among the Three Losses

| Loss | Static optimum | Sequential impossibility | Universal object |
|---|---|---|---|
| Squared | Regression function $m(x)$ | Instantaneous a.s. consistency for all ergodic processes | Cesàro $L^2$ risk $\to L^*$ |
| 0–1 | Bayes classifier | Same | Cesàro error rate $\to R^*$ |
| Log utility | Log-optimum portfolio $b^*(\cdot)$ | Competing with $W^*$ without knowing $P$ | Growth rate $\to W^*$ |

Expert aggregation is the common constructive principle; the portfolio case is distinguished because the “loss” is $-\log\langle b,x\rangle$ and wealth multiplies—so weighting experts by their **capital** is both the Hedge algorithm and the investor’s physical mixture.

---

## 8. Key Equations (Obsidian Math)

**Regression decomposition:**

$$
\mathbb{E}(g(X)-Y)^2=\mathbb{E}(m(X)-Y)^2+\mathbb{E}(m(X)-g(X))^2.
$$

**Expert weights (squared loss):**

$$
v_{t,k}\propto q_k e^{-(t-1)L_{t-1}(h_k)/c},\quad c\ge 8B^2.
$$

**Wealth:**

$$
S_n=S_0\exp\Big(\sum_{i=1}^n\log\langle b_{i},x_i\rangle\Big).
$$

**Universal mixture:**

$$
S_n(B)=\sum_{k,\ell}q_{k\ell}S_n(H^{(k,\ell)}).
$$

**Growth target:**

$$
W^*=\mathbb{E}\Big[\max_b\mathbb{E}[\log\langle b(X_{-\infty}^{-1}),X_0\rangle|X_{-\infty}^{-1}]\Big].
$$

---

## 9. Limitations and Scope

- Purely theoretical chapter: **no empirical backtest**, no transaction costs, no capacity.  
- Boundedness $|Y|\le B$ for the squared-loss theorem; portfolio theorem needs $\mathbb{E}|\log X^{(j)}|<\infty$.  
- Simplex constraint excludes shorting/leverage—growth rates are for long-only mixes.  
- Universality is asymptotic; finite-sample regret vs the best $(k,\ell)$ still carries $\frac{-\log q_{k\ell}}{n}$ penalties and empty-bin effects.  
- Ergodicity is essential; adversarial or heavily nonstationary markets are outside the theorem (though individual-sequence expert methods in Section 2 partially cover adversarial squared loss).

---

## 10. Practitioner Takeaways

1. **Universal investment without a return model is possible** in the ergodic long-only world: mix nonparametric log-optimal experts on quantized histories.  
2. The same expert-mixture philosophy that yields online regression/classification yields Cover–Algoet-type growth optimality.  
3. **Nearest-neighbor / partition memory of past return blocks** is the nonparametric engine—kernels appear explicitly in the regression half.  
4. For applied work, truncate $(k,\ell)$, control $d$, and budget costs; treat Theorem 2 as existence + design template, not a turnkey trading system.  
5. Filename notwithstanding, cite the chapter as **Györfi–Schäfer, “Nonparametric Prediction,”** with portfolio results in §16.4 building on Algoet, Cover, Breiman.

---

## 11. Extended Portfolio Discussion: Why Matching Blocks Work

Log-optimal $b^*$ is a function of the **conditional distribution** of next returns given the infinite past. Quantized $k$-blocks with fine partitions approximate that conditional law when the process is ergodic: every time the recent past “looks like” a past episode, the empirical distribution of the subsequent return is a Monte Carlo draw from roughly the right conditional. Maximizing $\sum\log\langle b,x_i\rangle$ on those episodes is the empirical log-optimal portfolio for that bin. Mixing over $(k,\ell)$ hedges the usual nonparametric bias–variance tradeoff: small $k$ / coarse $\ell$ → many matches, biased conditionals; large $k$ / fine $\ell$ → few matches, high variance. Wealth-weighted mixing automatically emphasizes the bins that actually made money historically—an online model-selection device with a growth-rate interpretation.

---

## 12. Comparison to Cover (1991) Universal Portfolios

Cover’s universal portfolio continuously mixes **all constant rebalanced portfolios** $b\in\Delta^{d-1}$ with a Dirichlet-type prior, competing with the best *constant* $b$ in hindsight. Györfi–Schäfer’s $B$ mixes **state-dependent** partition experts and competes with the best *causal* log-optimal strategy (growth $W^*$), a strictly harder benchmark when returns are dependent. Cover–Ordentlich (1996) add side information; here side information is replaced by self-generated quantized past returns. Computationally, Cover’s mixture is hard in high $d$ (integration over the simplex); the partition approach replaces that with a countable expert list and per-bin convex optimizations.

---

## 13. Finite-Sample and Computational Considerations

- **Complexity:** each day, for each $(k,\ell)$, update the active bin’s sufficient statistics for $\nabla_b\sum\log\langle b,x\rangle$; cost scales with number of experts times cost of a simplex gradient step.  
- **Empty bins:** fall back to uniform $b$; early wealth can lag until bins populate—hence the need for small-$k$ experts in the mixture.  
- **Priors:** any $q_{k\ell}>0$ works asymptotically; in practice, exponential decay in $k+\ell$ stabilizes early weights.  
- **Numerical stability:** use log-wealth in the mixture weights; clip returns away from $0$ to avoid $\log 0$.

---

## 14. Regression–Portfolio Dictionary for Cross-Readers

| Regression concept | Portfolio analogue |
|---|---|
| Expert predictor $h_k$ | Elementary portfolio strategy $H^{(k,\ell)}$ |
| Cumulative squared loss $L_n$ | Negative cumulative growth $-W_n$ (or inverse wealth) |
| Exponential weights $e^{-L/c}$ | Wealth weights $S_n(H^{(k,\ell)})$ |
| Cesàro consistency to $L^*$ | Growth consistency to $W^*$ |
| Quantized nearest matches | Same, on return-path features |

This dictionary is the chapter’s real pedagogical contribution: one technology, three loss functions.

---

## 15. Verdict

Györfi and Schäfer give a unified nonparametric recipe for universal sequential decisions under squared, 0–1, and log-utility losses. For finance readers filing the PDF under universal portfolios, §16.4 is the payoff: a rigorously universal, partition-based, long-only sequential investment strategy that attains Algoet–Cover growth $W^*$ for every ergodic market with finite expected absolute log returns, via wealth-weighted mixing of nonparametric experts. The result is foundational rather than empirical; implementers must still confront dimensionality, costs, and non-ergodicity.


---

## 16. Detailed Walk-Through of Theorem 2’s Inequality Chain

Start from $S_0=1$ without loss of generality. Mixture wealth is the convex combination of expert wealths, so

$$
W_n(B)=\frac1n\log\sum_{k,\ell}q_{k\ell}S_n(H^{(k,\ell)})
\ge\frac1n\log\Big(\sup_{k,\ell}q_{k\ell}S_n(H^{(k,\ell)})\Big)
=\sup_{k,\ell}\Big(W_n(H^{(k,\ell)})+\frac{\log q_{k\ell}}{n}\Big).
$$

Taking $\liminf_{n\to\infty}$ and using $\log q_{k\ell}/n\to 0$ yields

$$
\liminf_n W_n(B)\ge\sup_{k,\ell}\liminf_n W_n(H^{(k,\ell)}).
$$

For fixed $(k,\ell)$, define empirical conditional measures $P_{j,s}^{(k,\ell)}$ on returns following quantized block $s$ in a length-$j$ window of the bi-infinite stationary process. Ergodic theorem $\Rightarrow$ weak convergence

$$
P_{j,s}^{(k,\ell)}\Rightarrow \mathcal{L}\big(X_0\mid G_\ell(X_{-k}^{-1})=s\big)
$$

when that atom has positive probability (else the measure is a point mass at $(1,\ldots,1)$ by convention). Algoet–Cover continuity then upgrades log-optimal portfolios along the empirical measures to the log-optimal portfolio of the limit, pathwise for almost every $X_0$. Breiman’s lemma converts that pathwise convergence into convergence of average growth rates:

$$
W_n(H^{(k,\ell)})\to\epsilon_{k,\ell}
=\mathbb{E}\Big[\max_b\mathbb{E}\big[\log\langle b,X_0\rangle\mid G_\ell(X_{-k}^{-1})\big]\Big].
$$

Nested partitions make $\{\epsilon_{k,\ell}\}$ increase in $k$ and $\ell$. Submartingale convergence plus Algoet–Cover’s information-monotone limit of conditional growth rates produce

$$
\sup_{k,\ell}\epsilon_{k,\ell}=W^*.
$$

Combining displays finishes $\liminf W_n(B)\ge W^*$. Combined with the universal upper bound $\limsup\frac1n\log(S_n/S_n^*)\le 0$ valid for *any* strategy, one gets exact asymptotic growth $W^*$.

---

## 17. Why Instantaneous Learning Is Impossible but Cesàro Learning Is Not

Györfi–Morvai–Yakowitz-type negative results say: there is no predictor satisfying

$$
g_n(X_{n+1},D_n)-\mathbb{E}[Y_{n+1}|X_{n+1},D_n]\to 0
$$

almost surely for *every* stationary ergodic process. Intuition: ergodic processes can hide arbitrary dependence at arbitrarily long ranges; any finite-time estimator can be fooled on a subsequence of times. Cesàro consistency averages those mistakes; bad stretches become negligible in the $\frac1n\sum$ sense. Portfolio universality is itself a Cesàro / growth-rate statement—$\frac1n\log S_n$—not a statement that $b_n$ equals $b^*$ every day.

For trading, that distinction matters: universal schemes can have long drawdowns relative to an oracle while still delivering the oracle’s growth rate asymptotically.

---

## 18. Side Information and Features

Although this chapter does not develop Cover–Ordentlich side information formally, the partition experts *create* discrete side information from the past return path. One can replace $G_\ell(x_{n-k}^{n-1})$ by $G_\ell(f_{n-k}^{n-1})$ for a feature map $f$ (macro variables, order-flow imbalance, volatility state). The theorem’s logic survives if features remain part of a joint ergodic process and partitions refine. That is the practical route to “universal portfolios with side information” in the nonparametric style: enrich the alphabet being quantized, then keep the same wealth-weighted mixture.

---

## 19. Relationship to Nearest-Neighbor and Kernel Portfolios

Set $\ell$ so that partitions approximate $\varepsilon$-balls, or replace hard bins by $k$-NN in return-path space: define the expert that solves

$$
\max_b\sum_{i\in N_k(n)}\log\langle b,x_i\rangle,
$$

where $N_k(n)$ indexes the $k$ past times whose trailing windows are closest to the present in, say, Euclidean distance on log-returns. Mixture over $k$ (and over distance metrics / window lengths) again yields a Hedge-style universal scheme. Kernels enter as soft weights $K(d_i/h)$ inside the empirical log-optimal objective. The chapter’s Theorem 2 is the hard-partition special case with a clean ergodic proof.

---

## 20. Checklist: From Chapter to Research Code

1. Choose assets with strictly positive gross returns (add $\varepsilon$ floor).  
2. Build nested grids on $\log x\in\mathbb{R}^d$ or on ranks.  
3. Maintain dictionary: quantized key $\to$ running gradient for $\sum\log\langle b,x\rangle$.  
4. Each day: look up key for each $(k,\ell)$; take that bin’s $b$; mix by current expert wealth.  
5. Track metrics: $W_n$, excess growth vs best constant-rebalanced portfolio, turnover, bin hit rates.  
6. Stress: scramble dates (should kill growth edge if dependence was real); raise $d$ (should degrade).  

---

## 21. Bibliographic Anchors

Algoet (1992, 1994); Algoet–Cover (1988); Breiman (1957/1960, 1961); Cesa-Bianchi et al. (1997); Cover (1991); Cover–Ordentlich (1996); Cover–Thomas (1991); Devroye–Györfi–Lugosi (1996); Györfi–Kohler–Krzyżak–Walk (2002); Györfi–Lugosi (2001); Györfi–Lugosi–Morvai (1999); Györfi–Morvai–Yakowitz (1998); Haussler–Kivinen–Warmuth (1998); Littlestone–Warmuth (1994); Merhav–Feder (1998); Stone (1977); Vovk (1990, 1998, 2001); Weinberger–Merhav–Feder (1994).

---

## 22. Final Synthesis for the Finance Library

File this note under universal portfolios / nonparametric sequential investment, but keep the true title **Nonparametric Prediction**. The chapter’s portfolio theorem is a cornerstone for ergodic universal trading with memory, complementary to Cover’s constant-rebalanced mixtures. Together with the Bamberg–Neuhierl MEL comparative statics in the same batch, it separates two layers: *what growth rate is achievable* (Algoet–Cover $W^*$, MEL $a^*$) versus *how to learn a strategy that achieves it without knowing $P$* (Györfi–Schäfer mixture).


---

## 23. Worked Micro-Example (One Risky Feature Dimension)

Suppose $d=2$ (stock + cash-like asset with $x^{(2)}\equiv 1$) and returns are quantized by median splits ($\ell=1$: two cells; $\ell=2$: four cells). Take $k\in\{1,2\}$. Experts:

- $(1,1)$: match only yesterday’s up/down cell; log-optimize $b$ on next-day returns after past “up” days vs “down” days.  
- $(2,1)$: match the last two days’ up/down pattern (UU, UD, DU, DD).  
- $(1,2)$ and $(2,2)$: same with finer four-cell alphabet.

Initialize $S_0(H^{(k,\ell)})=1$, $q_{k\ell}=1/4$. Each day:

1. Update each expert’s bin using the new return.  
2. Recompute each expert’s recommended $b$ for tomorrow’s bin.  
3. Set $b_n\propto\sum q_{k\ell}S_{n-1}(H^{(k,\ell)})h^{(k,\ell)}$.  
4. Apply $b_n$ to $x_n$; multiply each expert’s wealth by $\langle h^{(k,\ell)},x_n\rangle$.

If the market alternates regimes (high drift after UU, low after DD), the $(2,\cdot)$ experts pull ahead and dominate the mixture; if memory is short, $(1,\cdot)$ dominate. The mixture’s $\frac1n\log S_n$ tracks the better memory length automatically—exactly Lemma 1 / wealth-weighting in portfolio clothing.

---

## 24. Failure Modes When Ergodicity Fails

- **Single structural break:** pre-break experts dominate weights; post-break learning is slow because old wealth is large (multiplicative weights have long memory). Fixes: wealth discounting / fixed shares of capital rejuvenated each period (not in the chapter).  
- **Adversarial returns:** universality is for stochastic ergodic $P$, not worst-case sequences. Individual-sequence regret methods (Cover universal portfolios, Vovk aggregating strategies) are the adversarial cousins.  
- **Absorbing crashes:** if some $x^{(j)}=0$ with positive probability, $\log$ terms explode; the finite-moment condition fails. Use gross-return floors or bankruptcy modeling outside the theorem.

---

## 25. How This Chapter Sits Next to Mathis–Cover Side Information

A prior Scholar summary in this library covers Mathis–Cover on measuring side information for investment. Györfi–Schäfer generate side information endogenously from quantized past returns and prove growth universality. Mathis–Cover ask how much a given side-information process raises growth. Joint reading: use Mathis–Cover to evaluate features; use Györfi–Schäfer to turn features into a universal strategy via partitions and mixing.

---

## 26. Equations Recap for Slide Decks

**Cesàro goal (regression):** $\frac1n\sum (g_i-Y_{i+1})^2\to L^*$.  

**Expert inequality:** $L_n(\tilde g)\le\inf_k\big(L_n(h_k)-c\ln q_k/n\big)$.  

**Portfolio wealth mix:** $S_n(B)=\sum q_{k\ell}S_n(H^{(k,\ell)})$.  

**Universality:** $\frac1n\log S_n(B)\to W^*$ a.s. for all ergodic $P$ with $\mathbb{E}|\log X^{(j)}|<\infty$.  

**Partition diameter:** $\lim_{\ell\to\infty}\max_{A\cap S\neq\emptyset}\mathrm{diam}(A)=0$ on balls $S$.

---

## 27. Closing

Nonparametric prediction, in Györfi–Schäfer’s hands, is the claim that expert aggregation plus refining memory partitions delivers universal Cesàro optimality for regression, classification, and growth-optimal investment. The finance payload is Theorem 2: a concrete, mixture-of-partition-portfolios algorithm that attains Algoet–Cover’s $W^*$ without knowing the return law. That is the right way to read—and to file—`UniversalPortfolios_Gyorfi_2003.pdf`.


---

## 28. Glossary and Index of Symbols

| Symbol | Meaning |
|---|---|
| $L_n(g)$ | Average loss of strategy $g$ after $n$ rounds |
| $m(x)$ | Regression function $\mathbb{E}[Y|X=x]$ |
| $J(g)$ | Excess $L^2$ risk vs $m$ |
| $h^{(k,\ell)}$ | Elementary expert with memory $k$, quantizer level $\ell$ |
| $q_{k\ell}$ | Prior mass on expert $(k,\ell)$ |
| $W_n(B)$ | Average growth rate of portfolio strategy $B$ |
| $W^*$ | Maximal ergodic growth rate (Algoet–Cover) |
| $G_\ell$ | Quantizer associated with partition $\mathcal{P}_\ell$ |
| $S_n(H^{(k,\ell)})$ | Wealth of elementary portfolio expert |
| $B$ | Wealth-weighted mixture strategy (Theorem 2) |

With this glossary, the chapter’s three universality theorems can be stated in one sentence each: combined quantized-match experts achieve $L^*$ in squared loss; randomized combined classifiers achieve $R^*$ in 0–1 loss; wealth-weighted partition portfolios achieve $W^*$ in log utility—for all stationary ergodic environments satisfying the stated moment bounds.


---

## 29. Reading Path and Exam-Style Questions

**Suggested reading order:** §16.1 motivation → §16.4 portfolios (finance core) → §16.2 Lemma 1 (engine) → Theorem 2 proof sketch → static regression/classification as background.

**Exam-style checks:**

1. Why does $S_n(B)=\sum q_{k\ell}S_n(H^{(k,\ell)})$ imply the $\sup_{k,\ell}(W_n+\log q_{k\ell}/n)$ lower bound?  
2. State two conditions on $\{\mathcal{P}_\ell\}$ required by Theorem 2.  
3. Distinguish Cover’s universal portfolio from Györfi–Schäfer’s $B$ in terms of the competitor class.  
4. Give one negative result explaining why Cesàro consistency is the right goal for ergodic squared-loss prediction.  
5. Write the log-optimum fixed-point characterization of $b^*(X_1^{n-1})$.

Answers live in §§16.2–16.4 and the Algoet–Cover citations. Clearing these five checks means the chapter’s finance content has been absorbed at research-usable depth.


---

## 30. One-Paragraph Abstract for Database Entry

Györfi and Schäfer survey universal sequential prediction under squared, 0–1, and log-utility losses. Elementary nonparametric experts that match quantized histories are combined with exponential / wealth weights to achieve Cesàro optimality for every stationary ergodic process (under mild moment bounds). In the portfolio section, the resulting mixture of partition-based log-optimal strategies attains Algoet–Cover’s maximal growth rate $W^*$, providing a rigorous nonparametric route to universal long-only investment with memory.
