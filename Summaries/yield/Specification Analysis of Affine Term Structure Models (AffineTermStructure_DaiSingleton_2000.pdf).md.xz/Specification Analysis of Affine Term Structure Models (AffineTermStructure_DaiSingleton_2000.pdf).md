# Specification Analysis of Affine Term Structure Models

**Authors:** Qiang Dai (NYU) and Kenneth J. Singleton (Stanford)  
**Publication:** *The Journal of Finance* Vol. LV, No. 5, October 2000, pp. 1943–1978  
**Source PDF:** `AffineTermStructure_DaiSingleton_2000.pdf` (Drive id `0B-6kBz0I0dMsbDdtYXVQZDY1Rjg`)  
**Summary prepared:** 2026-09-26 (Scholar batch_2026-09-26_4)  
**Extraction:** `pdftotext -layout` OK (~16,090 words source). No OCR required.

---

## 1. Motivation and Research Questions

Affine term structure models (ATSMs) dominate empirical multifactor yield-curve work because they combine (i) affine risk-neutral drift and conditional variance for the state $Y(t)$ with (ii) essentially closed-form zero prices (Duffie–Kan 1996). Yet the literature’s zoo of special cases—Vasicek, CIR, Balduzzi–Das–Foresi–Sundaram (BDFS), Chen, independent multi-CIR—had not been organized by **admissibility** (positive conditional variances / well-defined bond prices) or compared for **goodness-of-fit**.

Dai–Singleton answer two questions:

- **Q1:** Given a popular ATSM, is it maximally flexible within its admissible class? What overidentifying restrictions does it impose?  
- **Q2:** Are extant models, or their maximal counterparts, flexible enough to describe joint short- and long-yield dynamics?

There is **no single encompassing ATSM**: admissibility constraints preclude nesting all affine models in one parametric family. The authors therefore classify $N$-factor ATSMs into **$N+1$ non-nested subfamilies** indexed by $m=\mathrm{rank}(B)$, the number of state variables that enter conditional variances, each with a **canonical maximal model**.

**Empirical bottom line (three-factor LIBOR/swap data):** Gaussian ($m=0$) lacks stochastic vol; fully CIR-like CSR ($m=3$) cannot generate the **negative factor correlations** the data want. Intermediate branches $m=1,2$ with newly allowed correlations—especially preferred models $A_1(3)_{\mathrm{DS}}$ and $A_2(3)_{\mathrm{DS}}$—fit well; classical BDFS and Chen restrictions are **strongly rejected**. Negatively correlated diffusions are central to matching volatility and non-normality of yield changes. On balance $A_1(3)_{\mathrm{DS}}$ looks somewhat better than $A_2(3)_{\mathrm{DS}}$ for term-structure moments.

---

## 2. Affine Setup

Absent arbitrage, zero price maturing at $\tau$:

$$
P(t,\tau)=\mathbb{E}_t^{Q}\Big[\exp\Big(-\int_t^{\tau} r_s\,ds\Big)\Big].
$$

Short rate affine in $N$-vector $Y$:

$$
r(t)=\delta_0+\delta_y'Y(t).
$$

Risk-neutral affine diffusion:

$$
dY(t)=\mathcal{K}^{Q}(\theta^{Q}-Y(t))\,dt+\Sigma\sqrt{S(t)}\,dW^{Q}(t),
$$

with diagonal $S(t)$ satisfying

$$
[S(t)]_{ii}=\alpha_i+\beta_i'Y(t).
$$

Bond prices $P(t,\tau)=e^{A(\tau)-B(\tau)'Y(t)}$ with Riccati ODEs for $A,B$ (Duffie–Kan). Market prices of risk

$$
\Lambda(t)=\sqrt{S(t)}\,\lambda
$$

preserve affinity under the physical measure $P$:

$$
dY(t)=K(\Theta-Y(t))\,dt+\Sigma\sqrt{S(t)}\,dW^{P}(t).
$$

**Admissibility:** $[S(t)]_{ii}>0$ for all $i$ over the state space. Without restrictions on $(K,\Theta,\Sigma,B,\alpha)$, this fails.

---

## 3. Classification: Branches $A_m(N)$

Index $m=\mathrm{rank}(B)$ = number of independent linear combinations of $Y$ driving conditional variances. Each ATSM falls in exactly one of $m=0,1,\ldots,N$. For each $m$, $A_m(N)$ is the set of admissible models nested in (invariant transforms of) a **canonical representation**.

### 3.1 Canonical form (intuition)

Partition $Y=(Y^{B},Y^{D})$ with $Y^{B}$ $m\times 1$ (variance-driving “CIR-like” factors) and $Y^{D}$ $(N-m)\times 1$ (“Gaussian-like” factors). Canonical restrictions include:

- $\Sigma=I$;  
- structured $K$ with zeros preventing feedback that would push $Y^{B}$ negative;  
- $\Theta^{B}\ge 0$, $K_{ij}\le 0$ for $j\neq i$ in the $B$-block (Feller-like), $K^{BB}\Theta^{B}>0$ componentwise;  
- $B$ with identity on the $B$-block and nonnegative loadings of Gaussian factors into variances;  
- $\alpha=(0_m,1_{N-m})$.

Stationarity: eigenvalues of $K$ strictly positive.

**Invariant transformations** (Appendix A)—rescaling, rotation within admissible class, affine shifts—generate the equivalence class of maximal models $AM_m(N)$ without changing $r(t)$ or bond prices.

### 3.2 The volatility–correlation tradeoff (three-factor case)

For $N=3$ there are four branches:

| Branch | Volatility drivers $m$ | Conditional correlations | Unconditional correlations |
|---|---|---|---|
| $A_0(3)$ Gaussian / Vasicek | 0 (constant vols) | Fully flexible signs/magnitudes | Flexible |
| $A_1(3)$ (nests BDFS) | 1 | Some free (incl. negative) | Flexible |
| $A_2(3)$ (nests Chen) | 2 | More constrained; some signs restricted | Partially constrained |
| $A_3(3)$ CSR / multi-CIR | 3 | **Instantaneous correlations = 0** | Must be **non-negative** |

**Punchline:** more stochastic-volatility flexibility $\Rightarrow$ less freedom for correlations. CSR models with nonzero unconditional correlations still cannot make them negative; yet US yield data want negative factor correlations (e.g., ~$-0.5$ between implied factors in Duffie–Singleton 1997-style calculations). Hence **$A_3(3)$ is theoretically incapable of matching US history**.

Independent CIR factors (Chen–Scott 1993; Pearson–Sun 1994; Duffie–Singleton 1997) are **not required** for admissibility or closed-form zeros—correlated CSR is admissible if correlations stay nonnegative—but that still cannot deliver the needed negatives.

---

## 4. Popular Models as Restricted Maximal Models (Q1)

### 4.1 BDFS inside $A_1(3)$

BDFS treats $(v,u,r)$ as stochastic vol, central tendency, and short rate. Relative to $A_1(3)_{\mathrm{Max}}$, BDFS sets several correlations/feedbacks to zero (notably constraining conditional correlation between $u$ and $r$, and setting $k_{rv}=0$ so $v$ does not enter $r$’s drift, etc.). Dai–Singleton rewrite BDFS in their $A_Y$ notation and list the parameter zeros—each a testable overidentifying restriction.

### 4.2 Chen inside $A_2(3)$

Chen’s three-factor model with stochastic vol and central tendency sits in $A_2(3)$ but zeros uncorrelatedness restrictions between pairs of Brownian motions and constrains feedbacks. Again nested in a richer maximal model.

### 4.3 Vasicek / Gaussian

Gaussian models are already essentially maximal in $A_0(3)$ up to identification normalizations—but lack time-varying conditional vols, which the SNP diagnostics on swaps suggest matter (though swap data in their sample are “remarkably uneventful” vs Treasuries).

---

## 5. Econometric Strategy

### 5.1 Data

Primary: **USD LIBOR and fixed-for-floating swap yields** (not Treasuries), following Duffie–Singleton (1997). Motivation: swaps are closer to “constant maturity,” less contaminated by repo specialness, taxes, and other Treasury institutional factors outside standard ATSMs. Maturities used in estimation: **6-month LIBOR, 2-year and 10-year swaps**. Intermediate 3y, 5y, 7y used for out-of-sample pricing-error diagnostics. Qualitative results similar on Treasuries, but swap history is shorter.

### 5.2 Estimation: EMM / SMM

Simulated method of moments with Gallant–Tauchen SNP score generator. Auxiliary model selected as **Non-Gaussian VAR(1)–ARCH(2)** with Hermite polynomial order $K_z=4$ on innovations (“homogeneous-innovation” Hermite coefficients). Moment vector = scores of the auxiliary log-density; optimal GMM criterion. Asymptotic efficiency under their selection strategy (Gallant–Long). They fix the Hermite constant $e_0=0.01$ for numerical stability.

### 5.3 Risk-premium identification

With $\Lambda=\sqrt{S}\lambda$, not all $\lambda$ components are identified from zeros alone:

- Gaussian $A_0(N)$ with zero yields: **one** of $N$ prices of risk unidentified (collinear with $\delta_0$).  
- Non-Gaussian $A_m(N)$: identification improves if some Gaussian-like factors enter variances ($b_k\neq 0$ for a $k>m$).  
- **Coupon / swap yields** nonlinearly map states to observations and identify all market prices of risk.

Intuition: time-varying risk premia (from stochastic vol or nonlinear yield map) separate $\lambda$ from the short-rate level.

---

## 6. Empirical Results (Q2)

### 6.1 Models compared

In each of $A_1(3)$ and $A_2(3)$:

- Classical: $A_1(3)_{\mathrm{BDFS}}$, $A_2(3)_{\mathrm{Chen}}$  
- Maximal: $A_m(3)_{\mathrm{Max}}$  
- Preferred intermediate (“DS”): $A_1(3)_{\mathrm{DS}}$, $A_2(3)_{\mathrm{DS}}$ — free the empirically crucial correlations while not opening every Max parameter (Max had large SEs / overfitting concern).

$A_1(3)_{\mathrm{DS}}$ frees $(\sigma_{ru},\sigma_{ur})$ relative to BDFS.  
$A_2(3)_{\mathrm{DS}}$ frees $(k_{uv},k_{rv},\sigma_{rv})$ relative to Chen.

Both DS models maintain $d_1=0$ (instantaneous $r$ depends on only two of three AY states)—not rejected.

### 6.2 Goodness-of-fit (Table I narrative)

BDFS and Chen produce **large $\chi^2$** vs degrees of freedom → **strongly rejected**.  
$A_m(3)_{\mathrm{Max}}$ and $A_m(3)_{\mathrm{DS}}$ **not rejected** at conventional levels.  
Normalized SNP scores (Figure 2): BDFS/Chen fail on level (A), persistence/AR (C), and conditional covariance (t) score blocks; DS models shrink those $t$-ratios by allowing negative conditional correlations.

### 6.3 Parameter highlights

Mean reversion of $(v,u,r)$ in DS models (approx.):

- $A_1(3)_{\mathrm{DS}}$: $(m,n,k)\approx(0.37,0.23,17.4)$  
- $A_2(3)_{\mathrm{DS}}$: $(0.64,0.10,2.7)$

**Central tendency $u$ mean-reverts slowly; $r$ gaps to $u$ close fast**—familiar from Balduzzi et al. and Andersen–Lund. **Caution:** changing correlations **rotates** latent states; labels “central tendency” / “volatility” are not invariant. Example: in BDFS, $\Delta u$ correlates $0.98$ with 10y swap changes; in $A_1(3)_{\mathrm{DS}}$, $\Delta u$ correlates $0.95$ with **2y** swaps—and estimated $n$ is larger (faster $u$ reversion) precisely because of that rotation.

Volatility factor $v$ proxied by butterfly (long 10y + LIBOR, short 2y) in both, but butterfly weights differ across models.

### 6.4 Pricing errors on unused maturities (Table IV)

Moments of pricing errors (bp) for 3y/5y/7y swaps:

**$A_1(3)_{\mathrm{DS}}$:** means about $-11$, $+17$, $-13$ bp; stdev ~10–16 bp; AR(1)~0.95.  

**$A_2(3)_{\mathrm{DS}}$:** means about $-43$, $-63$, $-48$ bp (systematically higher model yields); stdev ~8–12 bp.

$A_1(3)_{\mathrm{DS}}$ has notably smaller average pricing errors. Both models err more on steep/inverted curve quartiles in patterned ways (table columns Q-Invert / Q-Steep).

### 6.5 Why $A_1(3)$ edges $A_2(3)$

Branches are non-nested, so no formal encompassing test. Informal verdict favoring $A_1(3)_{\mathrm{DS}}$:

1. Smaller intermediate-maturity pricing bias.  
2. Feedback parameters $k_{rv},k_{uv}$ that $A_2$ needs are **not essential** once $A_1$ frees $\sigma_{ur},\sigma_{ru}$.  
3. Admissibility in $A_2$ **prevents** freeing $\sigma_{ur}$ and forces $k_{uv}$ (hence $k_{rv}$) **negative**, implying **positive** unconditional corr between stochastic central tendency and stochastic vol—against the negative corr pattern the data favor.

**Economic takeaway:** the data’s demand for **negative factor correlations** is easier to satisfy in $A_1(3)$ than in the more volatility-rich $A_2(3)$.

---

## 7. Equations for Implementation

**Riccati (risk-neutral):**

$$
\frac{dA}{d\tau}=-\theta^{Q\prime}\mathcal{K}^{Q\prime}B+\frac12\sum_{i=1}^N\big[\Sigma'B\big]_i^2\alpha_i-\delta_0,
$$

$$
\frac{dB}{d\tau}=-\mathcal{K}^{Q\prime}B-\frac12\sum_{i=1}^N\big[\Sigma'B\big]_i^2\beta_i+\delta_y.
$$

**Physical drift after $\Lambda=\sqrt{S}\lambda$:** $K=\mathcal{K}^{Q}-\Sigma\Phi$, etc. (paper’s eqs. 8–9).

**EMM moment:** average score $\frac1n\sum\partial_g\log f(y_t|x_{t-1},g)$ of SNP auxiliary, matched to model-simulated paths.

---

## 8. Practitioner Takeaways

1. **Do not treat “affine” as one model**—choose a branch $m$ knowing the vol–corr tradeoff.  
2. **Independent CIR is an extra restriction**, not a pricing necessity; but full CSR still cannot do negative corr.  
3. For USD swaps, **prefer $A_1(3)$-style specs with free negative corr** over Chen/BDFS zeros.  
4. **Labels of latent factors rotate** when correlations change—don’t over-interpret “level/slope/butterfly” names across specs.  
5. Use **swaps/coupons** if you need to identify market prices of risk.  
6. Maximal models can overfit; **DS intermediates** (free the corr that matter) are the practical sweet spot in the paper.

---

## 9. Limitations

- Three-factor focus for empirics; classification is general-$N$ but evidence is $N=3$.  
- Sample of swaps shorter than Treasuries; “uneventful” SNP order may understate vol-of-vol vs equity-crisis eras after 2000.  
- Admissibility conditions are **sufficient**, not proved necessary—richer admissible models might exist.  
- MPR specification $\Lambda=\sqrt{S}\lambda$ is restrictive vs later essentially affine / extended MPR literature (Duffee, Cheridito–Filipović–Kimmel, etc.).  
- No interest-rate options / variance swaps in the estimation—only yield curve dynamics.

---

## 10. Extended Discussion: Admissibility Intuition

CIR’s Feller condition keeps the square-root process nonnegative so $\sqrt{v}$ is defined. With multiple factors, any channel that lets a Gaussian factor feed into a variance factor’s drift with the wrong sign can push variance factors negative with positive probability. Canonical zeros in the upper-right of $K$ and sign restrictions on $K_{ij},B_{ij}$ close those channels. Instantaneous correlations among variance-driving Brownian motions must be zero in the canonical form; Gaussian-like factors can correlate through $B$ loadings. Unconditional corr can still arise from drift feedback—but for $m=N$, the sign pattern forces unconditional corr $\ge 0$.

This is why “just add correlation to multi-CIR” fails as a fix for US yields: the admissible correlations have the wrong sign relative to the data.

---

## 11. Extended Discussion: What Negative Correlations Buy

Yield changes are skewed/kurtotic and show heteroskalasticity. SNP scores for conditional covariance and Hermite (non-Gaussian) parameters reject BDFS/Chen. Allowing $\mathrm{corr}(du,dr)<0$ or $\mathrm{corr}(dv,dr)<0$ lets the model generate:

- sharper curve steepening/flattening joint with level moves;  
- state-dependent yield vol without needing all three factors in $S(t)$;  
- better matching of butterfly vs level co-movement.

Table IV’s reduction in mean pricing error from $A_2$ to $A_1$ DS suggests that **mis-specified correlation** shows up as **level bias along the curve**, not only as dynamic score failures.

---

## 12. Comparison Sheet vs Common Industry Models

| Model | Branch | Stochastic vol | Negative factor corr? | Paper’s verdict on swaps |
|---|---|---|---|---|
| Vasicek 3F | $A_0(3)$ | No | Yes | Not emphasized; missing vol |
| Independent CIR 3F | $A_3(3)$ | Yes | No (inadmissible if forced) | Inconsistent with corr |
| BDFS | $A_1(3)$ restricted | Yes (1 factor) | Limited | Rejected |
| Chen | $A_2(3)$ restricted | Yes (2 factors) | Limited | Rejected |
| $A_1(3)_{\mathrm{DS}}$ | $A_1(3)$ | Yes | Yes (key frees) | Preferred |
| $A_2(3)_{\mathrm{DS}}$ | $A_2(3)$ | Yes | Partially | OK fit, worse pricing errors |

---

## 13. Replication Checklist

1. Build canonical $A_1(3)$ and $A_2(3)$ state spaces with admissibility inequalities imposed in estimation.  
2. Map BDFS/Chen parameterizations into canonical/AY form; impose their zeros for nested tests.  
3. Obtain daily 6m LIBOR + 2y/10y swap yields; construct overlapping weekly or daily $y_t$ as in the paper’s SNP design.  
4. Estimate SNP auxiliary (VAR1–ARCH2–Hermite4); freeze $g$; run EMM on structural $f$.  
5. Report $\chi^2$, score $t$-ratios by block, pricing errors on 3y/5y/7y, and implied factor–yield correlations.  
6. Stress: re-estimate on Treasuries; expect qualitatively similar corr need.

---

## 14. Verdict

Dai–Singleton (2000) is the organizing paper for affine term structure specification. Its classification by $m$, the formal vol–corr tradeoff, and the swap-market EMM evidence that **BDFS/Chen are too tight while negative correlations are essential** remain required reading before estimating any three-factor affine curve model. For implementation, start from $A_1(3)_{\mathrm{DS}}$-style correlation freedom unless a specific derivatives market forces richer stochastic volatility—and even then, watch admissibility when chasing negative corr.


---

## 15. AY Representation and Interpreting Tables II–III

The paper reports estimates in an $A_r$ / AY representation where the state is rotated so that coordinates are closer to $(v,u,r)$-style labels. Table III (branch $A_2(3)$) illustrates the pattern of “fixed” vs freed parameters:

- Chen column: $k_{uv}=k_{rv}=k_{vu}=\sigma_{rv}=\sigma_{ru}=a_r=b_u=0$ (fixed), with $r_S$ tied to $u_N$.  
- DS column: large and significant $k_{uv}\approx -33.9$ ($t\approx -2.4$ scale in OCR-garbled text; paper reports strong significance), $k_{rv}$ similarly negative significant, $\sigma_{rv}$ large negative—exactly the correlation/feedback channels Chen shut down.  
- Max column: still more freed parameters ($k_{vu}$, $\sigma_{ru}$, $a_r$, $b_u$, …) with many $t$-ratios collapsing toward zero—the overfitting symptom that motivates DS.

Parallel structure holds in Table II for $A_1(3)$: BDFS zeros vs DS freeing $\sigma_{ru},\sigma_{ur}$ vs Max’s kitchen sink.

Market prices of risk $\lambda_v,\lambda_u,\lambda_r$ are large in magnitude in several columns (e.g., $\lambda_r$ hundreds), consistent with the known difficulty of pinning risk premia even when formally identified by coupon/swap nonlinearities. Section II.B’s identification theory explains why swaps help, but finite-sample precision remains limited—another reason not to choose Max.

---

## 16. SNP Auxiliary Model in Enough Detail to Replicate Moments

Observed yield vector $y_t$ (dimension 3: 6m, 2y, 10y). Conditional mean $\mu(x_{t-1})$ is VAR(1). Conditional scale $R(x_{t-1})$ is diagonal-ARCH(2) in lagged absolute residuals with cross terms as in equation (35)—the paper’s “ARCH(2)” block. Innovations $z_t=R^{-1}(y_t-\mu)$ enter a Hermite polynomial $h(z|x)$ of total order 4 with **constant** coefficients (homogeneous innovation), producing a non-Gaussian conditional density

$$
f(y|x)\propto \big[h(z|x)\big]^2\,\phi(z)\,|R|^{-1}.
$$

EMM matches $\mathbb{E}_f[\partial_g\log f]$ under the auxiliary to the expectation under the structural ATSM (via long simulation). Because the auxiliary was selected by a sieve search, Gallant–Long efficiency results apply. The authors note swap data needed only low-order ARCH—unlike Andersen–Lund’s Treasury findings—so their rejection of BDFS/Chen is **not** an artifact of an over-rich auxiliary; the auxiliary is modest, and classical models still fail its scores.

---

## 17. Invariant Transforms: What “Maximal” Means Operationally

Two parameter vectors $c$ and $\tilde c$ are equivalent if there is an affine state transform $Y=L\tilde Y+\kappa$ (with linear short-rate preservation $\delta_0+\delta_y'Y=\tilde\delta_0+\tilde\delta_y'\tilde Y$) such that the law of $r$ and hence all bond prices coincide. Maximal means: after imposing admissibility-sufficient restrictions, one adds only the **minimal normalizations** that kill these invariances (e.g., $\Sigma=I$, pinning some $\alpha$ entries, triangularizing $K$ when $m=0$). Any further zero is overidentification.

This discipline prevents two common errors:

1. Estimating an unidentified affine setup and interpreting “significant” parameters that are pure gauge.  
2. Declaring a model “flexible” because it has many free entries, when most are not separately identified from yields.

---

## 18. Links to Later Literature (Post-2000 Context for Readers)

Without leaving the paper’s evidence, modern readers should know where this work sits:

- **Essentially affine MPRs** (Duffee 2002) relax $\Lambda=\sqrt{S}\lambda$ to improve risk-premium forecasting—motivated partly by the estimation fragility Dai–Singleton note.  
- **JSZ / AAC-style identification** literature tightens canonical forms for Gaussian and affine models.  
- **Unspanned stochastic volatility** work asks when bond options need factors beyond the yield curve—related to whether $m=1$ vs $m=2$ is enough for derivatives, a question Dai–Singleton flag as use-dependent.  
- **Shadow-rate / ZLB** models break affinity near zero; the 2000 swap sample largely predates that concern.

The classification by $m$ remains the right first cut even when MPR or ZLB extensions are added.

---

## 19. Decision Guide for Model Choice

**Choose $A_0(3)$** if closed-form Gaussian convenience dominates and stochastic vol is second-order for your application (some risk-neutral calibration desks).  

**Choose $A_1(3)_{\mathrm{DS}}$-like** for physical-measure yield dynamics / risk management on swaps or Treasuries when you need stochastic vol **and** negative corr—this is the paper’s preferred empirical compromise.  

**Choose $A_2(3)$** only if you have strong evidence that two variance factors are needed (e.g., options) **and** you can live with admissibility constraints on corr signs—or you move to non-canonical extensions carefully.  

**Avoid $A_3(3)$ CSR** for US data if negative factor corr is first-order—which the paper argues it is.

---

## 20. Detailed Intuition for the Smile of Specs Along $m$

Think of $m$ as a dial from “all Gaussian” to “all square-root.” Each click of the dial:

- adds a state that can enter $\sqrt{S}$;  
- removes a degree of freedom in instantaneous corr among the variance-driving Browns;  
- eventually (at $m=N$) freezes instantaneous corr at 0 and forces unconditional corr $\ge 0$.

US yield data historically show: (i) heteroskalasticity (want $m\ge 1$); (ii) negative co-movement between level and slope/butterfly factors (want free corr signs). The intersection of those desires is $m=1$ or maybe $m=2$ with care—not $m=0$ or $m=3$. That one-paragraph geometry is the paper’s conceptual core.

---

## 21. Pricing-Error AR(1) ≈ 0.95: What It Means

Table IV’s autocorrelations near 0.95 say omitted persistent factors or measurement microstructure remain even in DS models. For trading a model-implied butterfly, that persistence means pricing errors are **not** white—hedge ratios from the model need an error-state overlay (Kalman / include AR measurement errors), a practice consistent with later affine empirical work. Dai–Singleton’s EMM fit on three yields can still leave persistent errors on the other three; DS improves means but does not whiten errors completely.

---

## 22. Minimal Formula Card

$$
r=\delta_0+\delta_y'Y,\quad
dY=K(\Theta-Y)dt+\Sigma\sqrt{S(Y)}dW,\quad
S_{ii}=\alpha_i+\beta_i'Y,
$$

$$
P(t,\tau)=\exp\big(A(\tau)-B(\tau)'Y(t)\big),\quad
\Lambda=\sqrt{S}\lambda,
$$

$$
m=\mathrm{rank}(B)\in\{0,\ldots,N\},\quad
Y\in A_m(N)\ \text{canonical}.
$$

**Empirical slogan:** free negative corr in $A_1(3)$; do not expect $A_3(3)$ to fit US swaps.

---

## 23. Closing Synthesis

Dai and Singleton replace anecdote about “which affine model is best” with a classification theorem plus an EMM horse race on LIBOR/swap yields. The horse race rejects the most popular three-factor restricted specs (BDFS, Chen), rejects the idea that independent CIR is harmless, and elevates correlation flexibility—especially in the $m=1$ branch—as the ingredient that lets affine models match the volatility and non-normality of yield changes. Anyone specifying an affine curve model for research or risk should start from their $A_m(N)$ map and treat correlation admissibility as a first-class constraint, not an afterthought.


---

## 24. Glossary

| Term | Meaning |
|---|---|
| ATSM | Affine term structure model |
| Admissible | Conditional variances positive; bond ODEs well-defined |
| $m$ | Rank of $B$; number of variance-driving factors |
| $A_m(N)$ | Admissible $N$-factor family with given $m$ |
| Maximal / $AM_m(N)$ | Least-restricted identified model in the branch |
| CSR | Correlated square-root ($m=N$) subfamily |
| BDFS | Balduzzi–Das–Foresi–Sundaram three-factor model |
| EMM/SMM | Efficient / simulated method of moments via SNP scores |
| DS model | Authors’ preferred intermediate (corr freed, Max trimmed) |

---

## 25. Abstract for Database Entry

Dai and Singleton classify $N$-factor affine term structure models into $N+1$ non-nested admissible branches indexed by how many factors drive conditional variance, exposing a tradeoff between stochastic volatility and admissible correlations. On USD LIBOR/swap data, three-factor maximal and preferred models in the $m=1,2$ branches fit EMM moments, while BDFS and Chen restrictions are rejected; $m=3$ CSR models cannot generate the negative factor correlations required by the data. The preferred practical specification is an $A_1(3)$-style model with enriched correlations.


---

## 26. Teaching Notes: Three Questions to Put on a Problem Set

1. **Admissibility.** Give an example of a three-factor affine drift/diffusion that makes some $[S]_{ii}$ negative with positive probability. Which canonical restriction forbids it?  
2. **Nesting.** Write the parameter zeros that take $A_1(3)_{\mathrm{Max}}$ to BDFS. Which zero most directly kills negative $\mathrm{corr}(du,dr)$?  
3. **Identification.** In one-factor Gaussian Vasicek estimated on a single zero yield, show that $\lambda$ and $\delta_0$ are not separately identified. Explain how switching to a coupon yield restores identification.

These three exercises reproduce the paper’s theoretical spine without requiring a full EMM replication.


---

## 27. Final Word Count Note on Source Density

The JF article is ~16k words with heavy notation; this summary compresses the classification theorem, the four three-factor maximal models, the EMM design, and the headline empirical horse race into a practitioner-usable digest. Readers needing full Riccati expansions, Appendix A invariant-transform algebra, or complete parameter tables should return to the PDF’s Sections I and II and Tables I–IV. The numbers cited above (Sharpe-less yield moments, pricing-error means, mean-reversion triples, correlation examples $0.98$/$0.95$, factor corr $\approx -0.5$ from prior work) are taken from the text and tables as extracted by `pdftotext`.


---

## 28. One-Line Takeaway

**Affine ≠ one model:** pick $m$, respect admissibility, and free negative correlations—or the US yield curve will reject you, as it rejected BDFS and Chen.
